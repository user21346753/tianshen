#!/usr/bin/env bash
# 天神辅助 · 一键构建脚本
#
# 前置：装好 JDK 17 + Android SDK（Android Studio 里一键装即可）
# 用法：
#   chmod +x build.sh && ./build.sh          # 出 debug APK
#   ./build.sh release                       # 出 release APK（需先配签名）
set -e

cd "$(dirname "$0")/android"

export ANDROID_HOME=${ANDROID_HOME:-$HOME/Android/Sdk}
export ANDROID_SDK_ROOT=$ANDROID_HOME
export JAVA_HOME=${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-amd64}

echo "ANDROID_HOME = $ANDROID_HOME"
echo "JAVA_HOME    = $JAVA_HOME"

if [ ! -d "$ANDROID_HOME" ]; then
  echo "找不到 Android SDK。请先在 Android Studio → SDK Manager 安装，"
  echo "或手动指定： ANDROID_HOME=/path/to/sdk ./build.sh"
  exit 1
fi

chmod +x ./gradlew 2>/dev/null || true

# 有完整 wrapper 就用 wrapper，否则退回系统 gradle
if [ -x ./gradlew ] && [ -f gradle/wrapper/gradle-wrapper.jar ]; then
  GRADLE=./gradlew
else
  GRADLE=gradle
  command -v gradle >/dev/null || {
    echo "未找到 gradle。最简单的方式：用 Android Studio 打开 android/ 目录直接 Run。"
    echo "或先装 gradle 8.x 后重试。"
    exit 1
  }
fi

if [ "$1" == "release" ]; then
  $GRADLE assembleRelease
  APK=$(ls app/build/outputs/apk/release/*.apk | head -1)
else
  $GRADLE assembleDebug
  APK=$(ls app/build/outputs/apk/debug/*.apk | head -1)
fi

echo
echo "构建完成：$(pwd)/$APK"
echo "安装到手机： adb install -r $APK"
