package com.tianshen.hud;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;

import org.tensorflow.lite.Interpreter;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * YOLOv8 / YOLOv8-pose 的 TFLite 封装。
 *
 * assets/yolov8n.tflite       -> 目标检测（框 + 类别 + 距离）
 * assets/yolov8n-pose.tflite  -> 姿态（真实骨骼关键点，56 通道）
 *
 * assets 里没有模型时自动进入 MOCK 模式（合成移动目标），
 * 保证装上就能看到完整 HUD，之后补模型即可。
 */
public class Detector {

    private static final String TAG = "Detector";
    private static final int IN = 640;

    private Interpreter net = null;
    private Interpreter netPose = null;
    volatile boolean mockMode = true;
    volatile float confThr = 0.45f;
    private final float nmsThr = 0.50f;

    private float scale = 1f, padX = 0f, padY = 0f;
    private int mockFrame = 0;

    public Detector(Context ctx) {
        try {
            AssetManager am = ctx.getAssets();
            String[] fs = am.list("");
            boolean hasDet = false, hasPose = false;
            if (fs != null) {
                for (String f : fs) {
                    if ("yolov8n.tflite".equals(f)) hasDet = true;
                    if ("yolov8n-pose.tflite".equals(f)) hasPose = true;
                }
            }
            if (hasDet) {
                net = new Interpreter(load(am, "yolov8n.tflite"),
                        new Interpreter.Options().setNumThreads(4));
            }
            if (hasPose) {
                netPose = new Interpreter(load(am, "yolov8n-pose.tflite"),
                        new Interpreter.Options().setNumThreads(4));
            }
            mockMode = (net == null && netPose == null);
            Log.i(TAG, "mockMode=" + mockMode);
        } catch (Exception e) {
            Log.e(TAG, "初始化失败", e);
            mockMode = true;
        }
    }

    /**
     * 用 AssetManager.open() 把模型读进堆外 ByteBuffer。
     * 不用 openFd() —— 后者在模型被压缩时会直接抛异常。
     */
    private static ByteBuffer load(AssetManager am, String path) throws Exception {
        InputStream is = am.open(path);
        int n = is.available();
        byte[] bytes = new byte[Math.max(n, 1)];
        int read = 0, off = 0;
        while ((read = is.read(bytes, off, bytes.length - off)) > 0) {
            off += read;
            if (off >= bytes.length) break;
        }
        is.close();
        ByteBuffer buf = ByteBuffer.allocateDirect(bytes.length);
        buf.order(ByteOrder.nativeOrder());
        buf.put(bytes);
        return buf;
    }

    /** 输入原图，输出检测结果（坐标已还原到原图尺寸） */
    public List<MainActivity.Det> detect(Bitmap frame, boolean multiObject) {
        if (mockMode) return mock(frame, multiObject);

        int ow = frame.getWidth(), oh = frame.getHeight();
        Bitmap in = letterbox(frame);

        ByteBuffer buf = ByteBuffer.allocateDirect(4 * IN * IN * 3);
        buf.order(ByteOrder.nativeOrder());
        int[] px = new int[IN * IN];
        in.getPixels(px, 0, IN, 0, 0, IN, IN);
        for (int p : px) {
            buf.putFloat(((p >> 16) & 0xFF) / 255f);
            buf.putFloat(((p >> 8) & 0xFF) / 255f);
            buf.putFloat((p & 0xFF) / 255f);
        }

        Interpreter use = (net != null) ? net : netPose;
        int[] sh = use.getOutputTensor(0).shape();          // [1,C,N] 或 [1,N,C]
        int C = sh[1], N = sh[2];
        boolean tp = C < N;
        if (!tp) { C = sh[2]; N = sh[1]; }

        float[][][] res = new float[1][sh[1]][sh[2]];
        use.run(buf, res);
        boolean isPose = (C >= 56);

        List<MainActivity.Det> out = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            float bx = g(res, tp, 0, i), by = g(res, tp, 1, i);
            float bw = g(res, tp, 2, i), bh = g(res, tp, 3, i);
            int clsId = 0;
            float score;
            if (isPose) {
                score = g(res, tp, 4, i);
            } else {
                float best = -1f;
                for (int c = 4; c < C; c++) {
                    float v = g(res, tp, c, i);
                    if (v > best) { best = v; clsId = c - 4; }
                }
                score = best;
            }
            if (score < confThr) continue;
            if (!multiObject && clsId != 0) continue;

            float x1 = (bx - bw / 2f - padX) / scale;
            float y1 = (by - bh / 2f - padY) / scale;
            float x2 = (bx + bw / 2f - padX) / scale;
            float y2 = (by + bh / 2f - padY) / scale;
            x1 = clamp(x1, 0, ow); x2 = clamp(x2, 0, ow);
            y1 = clamp(y1, 0, oh); y2 = clamp(y2, 0, oh);
            if (x2 - x1 < 4 || y2 - y1 < 4) continue;

            MainActivity.Det d = new MainActivity.Det(x1, y1, x2, y2, score, clsId, zh(clsId));
            if (isPose) {
                d.kps = new float[51];
                for (int k = 0; k < 17; k++) {
                    d.kps[k * 3] = (g(res, tp, 5 + k * 3, i) - padX) / scale;
                    d.kps[k * 3 + 1] = (g(res, tp, 6 + k * 3, i) - padY) / scale;
                    d.kps[k * 3 + 2] = g(res, tp, 7 + k * 3, i);
                }
            }
            out.add(d);
        }
        return nms(out);
    }

    private static float g(float[][][] r, boolean tp, int c, int i) {
        return tp ? r[0][c][i] : r[0][i][c];
    }

    private Bitmap letterbox(Bitmap src) {
        int ow = src.getWidth(), oh = src.getHeight();
        scale = Math.min((float) IN / ow, (float) IN / oh);
        int nw = Math.round(ow * scale), nh = Math.round(oh * scale);
        padX = (IN - nw) / 2f;
        padY = (IN - nh) / 2f;
        Bitmap s = Bitmap.createScaledBitmap(src, nw, nh, true);
        Bitmap b = Bitmap.createBitmap(IN, IN, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.rgb(114, 114, 114));
        c.drawBitmap(s, padX, padY, null);
        return b;
    }

    private List<MainActivity.Det> nms(List<MainActivity.Det> dets) {
        dets.sort((a, b) -> Float.compare(b.conf, a.conf));
        List<MainActivity.Det> keep = new ArrayList<>();
        boolean[] dead = new boolean[dets.size()];
        for (int i = 0; i < dets.size(); i++) {
            if (dead[i]) continue;
            keep.add(dets.get(i));
            for (int j = i + 1; j < dets.size(); j++) {
                if (dead[j]) continue;
                if (iou(dets.get(i), dets.get(j)) > nmsThr) dead[j] = true;
            }
        }
        return keep;
    }

    private static float iou(MainActivity.Det a, MainActivity.Det b) {
        float ix1 = Math.max(a.x1, b.x1), iy1 = Math.max(a.y1, b.y1);
        float ix2 = Math.min(a.x2, b.x2), iy2 = Math.min(a.y2, b.y2);
        float iw = Math.max(0f, ix2 - ix1), ih = Math.max(0f, iy2 - iy1);
        float inter = iw * ih;
        if (inter <= 0) return 0f;
        float sa = a.w() * a.h(), sb = b.w() * b.h();
        return inter / (sa + sb - inter + 1e-6f);
    }

    /** 无模型时：合成几个横向移动目标，驱动整套 HUD */
    private List<MainActivity.Det> mock(Bitmap frame, boolean multiObject) {
        mockFrame++;
        int W = frame.getWidth(), H = frame.getHeight();
        List<MainActivity.Det> out = new ArrayList<>();
        float t = mockFrame / 60f;

        float hA = H * (0.30f + 0.10f * (float) Math.sin(t * 0.7));
        float xA = W * (0.30f + 0.22f * (float) Math.sin(t * 0.5));
        out.add(new MainActivity.Det(xA - hA * 0.17f, H * 0.82f - hA,
                xA + hA * 0.17f, H * 0.82f, 0.86f, 0, "行人"));

        float hB = H * (0.24f + 0.08f * (float) Math.cos(t * 0.9));
        float xB = W * (0.68f + 0.18f * (float) Math.cos(t * 0.6));
        out.add(new MainActivity.Det(xB - hB * 0.17f, H * 0.80f - hB,
                xB + hB * 0.17f, H * 0.80f, 0.82f, 0, "行人"));

        if (multiObject) {
            float hC = H * 0.20f;
            float xC = W * (0.50f + 0.30f * (float) Math.sin(t * 0.35 + 1.2));
            out.add(new MainActivity.Det(xC - hC * 0.38f, H * 0.88f - hC,
                    xC + hC * 0.38f, H * 0.88f, 0.80f, 3, "电动车"));
        }
        return out;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static String zh(int id) {
        switch (id) {
            case 0: return "行人";
            case 1: return "自行车";
            case 2: return "汽车";
            case 3: return "电动车";
            case 5: return "客车";
            case 7: return "货车";
            case 15: return "猫";
            case 16: return "狗";
            default: return "目标" + id;
        }
    }

    public String modelName() {
        if (mockMode) return "MOCK";
        if (net != null && netPose != null) return "YOLOv8n+pose";
        return net != null ? "YOLOv8n" : "YOLOv8n-pose";
    }

    public void close() {
        if (net != null) net.close();
        if (netPose != null) netPose.close();
    }
}
