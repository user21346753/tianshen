package com.tianshen.hud;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 天神辅助 · Android 单文件版
 *
 * 摄像头取帧 -> YOLOv8 检测 -> IoU 跟踪 -> 单目测距 -> HUD 绘制
 * 全部逻辑集中在本文件，方便在手机上维护。
 *
 * 注意：没有透视。只处理摄像头当前帧里本来就看得到的目标。
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "TianShen";
    private static final int AW = 640, AH = 480;

    private PreviewView previewView;
    private HudView hud;
    private TextView tvStat, tvSens;
    private ExecutorService exec;
    private ProcessCameraProvider provider;

    private Detector detector;
    private final Tracker tracker = new Tracker();
    private DistanceEstimator distEst = new DistanceEstimator(AH);

    private int lens = CameraSelector.LENS_FACING_BACK;
    private boolean multiObject = true;

    private final Handler ui = new Handler(Looper.getMainLooper());

    private final ActivityResultLauncher<String> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), ok -> {
                if (ok) startCamera();
                else Toast.makeText(this, "需要相机权限才能运行", Toast.LENGTH_LONG).show();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        exec = Executors.newSingleThreadExecutor();
        detector = new Detector(this);
        readCameraChars();

        buildUi();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            permLauncher.launch(Manifest.permission.CAMERA);
        }

        if (detector.mockMode) {
            Toast.makeText(this,
                    "assets 里没有模型，已进入 MOCK 演示模式（合成目标）",
                    Toast.LENGTH_LONG).show();
        }
        ui.postDelayed(statLoop, 500);
    }

    private final Runnable statLoop = new Runnable() {
        @Override
        public void run() {
            tvStat.setText("FPS " + Math.round(hud.fps)
                    + "  当前 0  累计 " + tracker.totalSeen
                    + "\n模型 " + detector.modelName());
            ui.postDelayed(this, 500);
        }
    };

    // ---------------------------------------------------------------- UI

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        root.addView(previewView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        hud = new HudView(this);
        hud.modelName = detector.modelName();
        root.addView(hud, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 右侧控制面板
        ScrollView scroller = new ScrollView(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (10 * getResources().getDisplayMetrics().density);
        panel.setPadding(pad, pad, pad, pad);
        panel.setBackgroundColor(Color.argb(190, 10, 12, 16));

        TextView title = new TextView(this);
        title.setText("天神辅助");
        title.setTextColor(Color.parseColor("#FF4CE07A"));
        title.setTextSize(16);
        title.setPadding(0, 0, 0, pad);
        panel.addView(title);

        addSwitch(panel, "绘制方框", true, v -> hud.showBox = v);
        addSwitch(panel, "绘制骨骼", false, v -> hud.showSkeleton = v);
        addSwitch(panel, "绘制雷达", true, v -> hud.showRadar = v);
        addSwitch(panel, "绘制射线", true, v -> hud.showRay = v);
        addSwitch(panel, "多物体绘制", true, v -> multiObject = v);

        tvSens = new TextView(this);
        tvSens.setTextColor(Color.parseColor("#FFD6E7DC"));
        tvSens.setTextSize(12);
        panel.addView(tvSens);

        SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        sb.setProgress(45);
        sb.setLayoutParams(new LinearLayout.LayoutParams((int) (170 * getResources()
                .getDisplayMetrics().density), ViewGroup.LayoutParams.WRAP_CONTENT));
        applyConf(45);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean f) { applyConf(p); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        panel.addView(sb);

        Button btn = new Button(this);
        btn.setText("切换镜头");
        btn.setTextSize(12);
        btn.setOnClickListener(v -> {
            lens = (lens == CameraSelector.LENS_FACING_BACK)
                    ? CameraSelector.LENS_FACING_FRONT : CameraSelector.LENS_FACING_BACK;
            tracker.reset();
            readCameraChars();
            bind();
        });
        panel.addView(btn);

        tvStat = new TextView(this);
        tvStat.setTextColor(Color.parseColor("#FF4CE07A"));
        tvStat.setTextSize(12);
        tvStat.setPadding(0, pad, 0, 0);
        panel.addView(tvStat);

        scroller.addView(panel);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END | Gravity.CENTER_VERTICAL);
        lp.rightMargin = pad;
        root.addView(scroller, lp);

        setContentView(root);
    }

    private interface BoolCb { void set(boolean v); }

    private void addSwitch(LinearLayout p, String text, boolean init, BoolCb cb) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        c.setTextColor(Color.parseColor("#FFD6E7DC"));
        c.setTextSize(12);
        c.setChecked(init);
        cb.set(init);
        c.setOnCheckedChangeListener((v, on) -> cb.set(on));
        p.addView(c);
    }

    private void applyConf(int progress) {
        float conf = 0.20f + (progress / 100f) * 0.60f;
        detector.confThr = conf;
        tvSens.setText("探测灵敏度 " + String.format("%.2f", conf));
    }

    // ---------------------------------------------------------------- 相机

    private void readCameraChars() {
        try {
            Object cm = getSystemService("camera");
            String id = (lens == CameraSelector.LENS_FACING_BACK) ? "0" : "1";
            java.lang.reflect.Method m = cm.getClass()
                    .getMethod("getCameraCharacteristics", String.class);
            Object cc = m.invoke(cm, id);
            distEst.setFromCamera(cc, AH);
        } catch (Throwable e) {
            Log.w(TAG, "相机参数读取失败，使用默认 FOV", e);
        }
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(this);
        f.addListener(() -> {
            try {
                provider = f.get();
                bind();
            } catch (Exception e) {
                Log.e(TAG, "相机启动失败", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bind() {
        if (provider == null) return;
        provider.unbindAll();

        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        ImageAnalysis analysis = new ImageAnalysis.Builder()
                .setTargetResolution(new Size(AW, AH))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build();
        analysis.setAnalyzer(exec, this::analyze);

        try {
            provider.bindToLifecycle(this,
                    new CameraSelector.Builder().requireLensFacing(lens).build(),
                    preview, analysis);
        } catch (Exception e) {
            Log.e(TAG, "绑定相机失败", e);
        }
    }

    private void analyze(ImageProxy img) {
        try {
            Bitmap bmp = img.toBitmap();
            int rot = img.getImageInfo().getRotationDegrees();
            if (rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                Bitmap r = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                bmp.recycle();
                bmp = r;
            }
            final int w = bmp.getWidth(), h = bmp.getHeight();

            List<Det> dets = detector.detect(bmp, multiObject);
            List<Target> targets = tracker.update(dets);
            for (Target t : targets) t.distM = distEst.estimate(t.h(), t.clsId);
            final int total = tracker.totalSeen;
            final int cur = targets.size();

            ui.post(() -> {
                hud.setTargets(targets, w, h, total);
                tvStat.setText("FPS " + Math.round(hud.fps) + "  当前 " + cur
                        + "  累计 " + total + "\n模型 " + detector.modelName());
            });
            if (bmp != null && !bmp.isRecycled()) bmp.recycle();
        } catch (Exception e) {
            Log.e(TAG, "分析帧失败", e);
        } finally {
            img.close();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacks(statLoop);
        exec.shutdown();
        detector.close();
        if (provider != null) provider.unbindAll();
    }

    // ================================================================ 数据结构

    static class Det {
        float x1, y1, x2, y2, conf;
        int clsId;
        String label = "目标";
        float[] kps = null;

        Det(float x1, float y1, float x2, float y2, float conf, int clsId, String label) {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
            this.conf = conf; this.clsId = clsId; this.label = label;
        }
        float w() { return Math.max(0f, x2 - x1); }
        float h() { return Math.max(0f, y2 - y1); }
        float cx() { return (x1 + x2) * 0.5f; }
        float cy() { return (y1 + y2) * 0.5f; }
    }

    static class Target {
        int id;
        float x1, y1, x2, y2, conf, distM;
        int clsId;
        String label = "目标";
        int age, lost;
        float[] kps;

        float cx() { return (x1 + x2) * 0.5f; }
        float cy() { return (y1 + y2) * 0.5f; }
        float h() { return Math.max(1f, y2 - y1); }
        float w() { return Math.max(1f, x2 - x1); }

        void update(Det d) {
            x1 = d.x1; y1 = d.y1; x2 = d.x2; y2 = d.y2;
            conf = d.conf; clsId = d.clsId; label = d.label; kps = d.kps;
            age++; lost = 0;
        }
    }

    // ================================================================ 跟踪器

    static class Tracker {
        private final float iouThr = 0.35f;
        private final int maxLost = 12, minHits = 2;
        private final List<Target> tracks = new ArrayList<>();
        private int nextId = 1;
        volatile int totalSeen = 0;

        private static float iou(Target t, Det d) {
            float ix1 = Math.max(t.x1, d.x1), iy1 = Math.max(t.y1, d.y1);
            float ix2 = Math.min(t.x2, d.x2), iy2 = Math.min(t.y2, d.y2);
            float iw = Math.max(0f, ix2 - ix1), ih = Math.max(0f, iy2 - iy1);
            float inter = iw * ih;
            if (inter <= 0) return 0f;
            float sa = Math.max(0f, t.x2 - t.x1) * Math.max(0f, t.y2 - t.y1);
            float sb = Math.max(0f, d.x2 - d.x1) * Math.max(0f, d.y2 - d.y1);
            return inter / (sa + sb - inter + 1e-6f);
        }

        List<Target> update(List<Det> dets) {
            List<float[]> pairs = new ArrayList<>();
            for (int ti = 0; ti < tracks.size(); ti++)
                for (int di = 0; di < dets.size(); di++) {
                    float v = iou(tracks.get(ti), dets.get(di));
                    if (v >= iouThr) pairs.add(new float[]{v, ti, di});
                }
            pairs.sort((a, b) -> Float.compare(b[0], a[0]));

            boolean[] ut = new boolean[tracks.size()], ud = new boolean[dets.size()];
            for (float[] p : pairs) {
                int ti = (int) p[1], di = (int) p[2];
                if (ut[ti] || ud[di]) continue;
                ut[ti] = true; ud[di] = true;
                tracks.get(ti).update(dets.get(di));
            }
            for (int di = 0; di < dets.size(); di++) {
                if (ud[di]) continue;
                Det d = dets.get(di);
                if (d.conf < 0.35f && !tracks.isEmpty()) continue;
                Target t = new Target();
                t.id = nextId++;
                t.update(d);
                t.age = 1;
                totalSeen++;
                tracks.add(t);
            }
            List<Target> alive = new ArrayList<>();
            for (int ti = 0; ti < tracks.size(); ti++) {
                Target t = tracks.get(ti);
                if (!ut[ti]) t.lost++;
                if (t.lost <= maxLost) alive.add(t);
            }
            tracks.clear();
            tracks.addAll(alive);

            List<Target> out = new ArrayList<>();
            for (Target t : tracks)
                if (t.age >= minHits && t.lost == 0) out.add(t);
            out.sort(Comparator.comparingDouble(o -> o.distM));
            return out;
        }

        void reset() {
            tracks.clear(); nextId = 1; totalSeen = 0;
        }
    }

    // ================================================================ 测距

    static class DistanceEstimator {
        private float fPx;
        private int imgH;
        float userScale = 1.0f;

        private static final float[] REAL_H = new float[81];
        static {
            for (int i = 0; i < REAL_H.length; i++) REAL_H[i] = 1.70f;
            REAL_H[0] = 1.70f;   // person
            REAL_H[1] = 1.20f;   // bicycle
            REAL_H[2] = 1.15f;   // car
            REAL_H[3] = 1.30f;   // motorbike
            REAL_H[5] = 3.20f;   // bus
            REAL_H[7] = 3.00f;   // truck
        }

        DistanceEstimator(int imgH) {
            this.imgH = imgH;
            setFov(49f);
        }

        void setFov(float fovV) {
            fPx = (float) ((imgH / 2.0) / Math.tan(Math.toRadians(fovV) / 2.0));
        }

        void setFromCamera(Object cc, int h) {
            imgH = h;
            try {
                Class<?> k = Class.forName("android.hardware.camera2.CameraCharacteristics");
                java.lang.reflect.Method get = cc.getClass().getMethod("get", Class.forName("android.hardware.camera2.CameraCharacteristics$Key"));
                Object focal = get.invoke(cc, k.getField("LENS_FOCAL_LENGTH").get(null));
                Object physical = get.invoke(cc, k.getField("SENSOR_INFO_PHYSICAL_SIZE").get(null));
                float fl = ((Float) focal);
                float phH = ((android.util.SizeF) physical).getHeight();
                if (fl > 0 && phH > 0) {
                    fPx = fl / phH * h;
                    return;
                }
            } catch (Throwable ignored) { }
            setFov(49f);
        }

        float estimate(float hPx, int clsId) {
            if (hPx <= 1f) return 0f;
            float H = (clsId >= 0 && clsId < REAL_H.length) ? REAL_H[clsId] : 1.70f;
            float d = fPx * H / hPx * userScale;
            return Math.min(Math.max(d, 0.3f), 200f);
        }
    }
}
