package com.tianshen.hud;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.util.List;

/**
 * HUD 叠加层：方框 / 骨骼 / 雷达 / 射线 / 准星 / 面板 / FPS / 计数。
 */
public class HudView extends View {

    volatile boolean showBox = true, showSkeleton = false, showRadar = true, showRay = true;
    volatile String modelName = "YOLOv8n";
    volatile float fps = 0f;

    private List<MainActivity.Target> targets = null;
    private int srcW = 1, srcH = 1, curCount = 0, totalCount = 0;
    private int frames = 0;
    private long winStart = 0;

    private final Paint pGreen, pCyan, pDim, pText;

    public HudView(Context c) {
        super(c);
        pGreen = new Paint(Paint.ANTI_ALIAS_FLAG);
        pGreen.setColor(Color.parseColor("#FF4CE07A"));
        pGreen.setStyle(Paint.Style.STROKE);
        pGreen.setStrokeWidth(2.5f);

        pCyan = new Paint(Paint.ANTI_ALIAS_FLAG);
        pCyan.setColor(Color.parseColor("#FF4CD8FF"));

        pDim = new Paint(Paint.ANTI_ALIAS_FLAG);
        pDim.setColor(Color.argb(180, 60, 160, 90));
        pDim.setStyle(Paint.Style.STROKE);
        pDim.setStrokeWidth(1.5f);

        pText = new Paint(Paint.ANTI_ALIAS_FLAG);
        pText.setColor(Color.parseColor("#FFD6E7DC"));
        pText.setTextSize(24f);
    }

    public synchronized void setTargets(List<MainActivity.Target> list, int w, int h, int total) {
        targets = list;
        srcW = Math.max(1, w);
        srcH = Math.max(1, h);
        curCount = (list == null) ? 0 : list.size();
        totalCount = total;

        long now = System.currentTimeMillis();
        frames++;
        if (winStart == 0) { winStart = now; }
        else {
            long dt = now - winStart;
            if (dt >= 500) { fps = frames * 1000f / dt; frames = 0; winStart = now; }
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (targets == null) return;
        float sx = getWidth() / (float) srcW;
        float sy = getHeight() / (float) srcH;

        if (showRay) drawRays(c, sx, sy);
        drawCrosshair(c);
        if (showBox) drawBoxes(c, sx, sy);
        if (showSkeleton) drawSkeletons(c, sx, sy);
        if (showRadar) drawRadar(c, sx, sy);
        drawPanel(c);
    }

    private void drawBoxes(Canvas c, float sx, float sy) {
        for (MainActivity.Target t : targets) {
            float x1 = t.x1 * sx, y1 = t.y1 * sy, x2 = t.x2 * sx, y2 = t.y2 * sy;
            c.drawRect(x1, y1, x2, y2, pGreen);

            float L = Math.min(22f, Math.min(x2 - x1, y2 - y1) / 3f);
            Paint th = new Paint(pGreen);
            th.setStrokeWidth(5f);
            c.drawLine(x1, y1, x1 + L, y1, th);
            c.drawLine(x1, y1, x1, y1 + L, th);
            c.drawLine(x2, y1, x2 - L, y1, th);
            c.drawLine(x2, y1, x2, y1 + L, th);
            c.drawLine(x1, y2, x1 + L, y2, th);
            c.drawLine(x1, y2, x1, y2 - L, th);
            c.drawLine(x2, y2, x2 - L, y2, th);
            c.drawLine(x2, y2, x2, y2 - L, th);

            String tag = "#" + t.id + " " + t.label + " " + String.format("%.1f", t.distM) + "m";
            float tw = pText.measureText(tag) + 14f;
            float ty = (y1 - 34f < 0) ? y2 : y1 - 34f;
            Paint bg = new Paint();
            bg.setColor(Color.argb(200, 8, 26, 14));
            c.drawRect(x1, ty, x1 + tw, ty + 30f, bg);
            Paint gp = new Paint(pText);
            gp.setColor(Color.parseColor("#FF4CE07A"));
            c.drawText(tag, x1 + 7f, ty + 22f, gp);
        }
    }

    private static final int[][] LIMBS = {
            {0, 5}, {0, 6}, {5, 6}, {5, 7}, {7, 9}, {6, 8}, {8, 10},
            {5, 11}, {6, 12}, {11, 12}, {11, 13}, {13, 15}, {12, 14}, {14, 16}
    };

    private void drawSkeletons(Canvas c, float sx, float sy) {
        for (MainActivity.Target t : targets) {
            float[] p = (t.kps != null && t.kps.length >= 51) ? real(t, sx, sy) : guess(t, sx, sy);
            Paint bone = new Paint(Paint.ANTI_ALIAS_FLAG);
            bone.setColor(Color.parseColor("#FF4CD8FF"));
            bone.setStrokeWidth(3f);
            for (int[] l : LIMBS) {
                float ax = p[l[0] * 2], ay = p[l[0] * 2 + 1];
                float bx = p[l[1] * 2], by = p[l[1] * 2 + 1];
                if (ax <= 0 || ay <= 0 || bx <= 0 || by <= 0) continue;
                c.drawLine(ax, ay, bx, by, bone);
            }
            Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
            dot.setColor(Color.parseColor("#FFFFA040"));
            for (int k = 0; k < 17; k++) {
                if (p[k * 2] <= 0 || p[k * 2 + 1] <= 0) continue;
                c.drawCircle(p[k * 2], p[k * 2 + 1], 4f, dot);
            }
        }
    }

    private float[] real(MainActivity.Target t, float sx, float sy) {
        float[] p = new float[34];
        for (int k = 0; k < 17; k++) {
            p[k * 2] = t.kps[k * 3] * sx;
            p[k * 2 + 1] = t.kps[k * 3 + 1] * sy;
        }
        return p;
    }

    /** 无 pose 模型：按人体比例在框内生成近似骨架（COCO 17 点顺序） */
    private float[] guess(MainActivity.Target t, float sx, float sy) {
        float x1 = t.x1 * sx, y1 = t.y1 * sy;
        float w = (t.x2 - t.x1) * sx, h = (t.y2 - t.y1) * sy;
        float[] p = new float[34];
        put(p, 0, x1 + .50f * w, y1 + .09f * h);   // 鼻
        put(p, 1, x1 + .44f * w, y1 + .075f * h);  // 左眼
        put(p, 2, x1 + .56f * w, y1 + .075f * h);  // 右眼
        put(p, 3, x1 + .38f * w, y1 + .085f * h);
        put(p, 4, x1 + .62f * w, y1 + .085f * h);
        put(p, 5, x1 + .34f * w, y1 + .26f * h);   // 左肩
        put(p, 6, x1 + .66f * w, y1 + .26f * h);   // 右肩
        put(p, 7, x1 + .25f * w, y1 + .42f * h);
        put(p, 8, x1 + .75f * w, y1 + .42f * h);
        put(p, 9, x1 + .19f * w, y1 + .56f * h);
        put(p, 10, x1 + .81f * w, y1 + .56f * h);
        put(p, 11, x1 + .41f * w, y1 + .56f * h);  // 左髋
        put(p, 12, x1 + .59f * w, y1 + .56f * h);  // 右髋
        put(p, 13, x1 + .40f * w, y1 + .75f * h);
        put(p, 14, x1 + .60f * w, y1 + .75f * h);
        put(p, 15, x1 + .39f * w, y1 + .95f * h);
        put(p, 16, x1 + .61f * w, y1 + .95f * h);
        return p;
    }

    private static void put(float[] p, int i, float x, float y) {
        p[i * 2] = x;
        p[i * 2 + 1] = y;
    }

    private void drawRays(Canvas c, float sx, float sy) {
        float cx = getWidth() / 2f, cy = getHeight() * 0.52f;
        Paint rp = new Paint(Paint.ANTI_ALIAS_FLAG);
        rp.setColor(Color.argb(190, 90, 230, 130));
        rp.setStrokeWidth(1.5f);
        for (MainActivity.Target t : targets) {
            c.drawLine(cx, cy, t.cx() * sx, t.cy() * sy, rp);
            c.drawCircle(t.cx() * sx, t.cy() * sy, 5f, rp);
        }
    }

    private void drawCrosshair(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() * 0.52f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#FF4CE07A"));
        p.setStrokeWidth(2.5f);
        c.drawLine(cx - 26, cy, cx - 10, cy, p);
        c.drawLine(cx + 10, cy, cx + 26, cy, p);
        c.drawLine(cx, cy - 26, cx, cy - 10, p);
        c.drawLine(cx, cy + 10, cx, cy + 26, p);
        c.drawCircle(cx, cy, 4f, p);
    }

    private void drawRadar(Canvas c, float sx, float sy) {
        float R = Math.min(120f, getHeight() * 0.22f);
        float cx = R + 30f, cy = getHeight() - R - 30f;

        c.drawCircle(cx, cy, R, pDim);
        c.drawCircle(cx, cy, R * 2f / 3f, pDim);
        c.drawCircle(cx, cy, R / 3f, pDim);
        c.drawLine(cx - R, cy, cx + R, cy, pDim);
        c.drawLine(cx, cy - R, cx, cy + R, pDim);

        Paint sweep = new Paint(Paint.ANTI_ALIAS_FLAG);
        sweep.setColor(Color.argb(60, 76, 224, 122));
        sweep.setStyle(Paint.Style.FILL);
        float ang = (System.currentTimeMillis() / 12) % 360;
        c.drawArc(new RectF(cx - R, cy - R, cx + R, cy + R), ang - 30, 60, true, sweep);

        for (MainActivity.Target t : targets) {
            double a = ((t.cx() * sx - getWidth() / 2f) / (getWidth() / 2f)) * (Math.PI / 4);
            float rr = R * Math.min(t.distM / 40f, 1f);
            float px = (float) (cx + rr * Math.sin(a));
            float py = (float) (cy - rr * Math.cos(a));
            Paint bl = new Paint(Paint.ANTI_ALIAS_FLAG);
            bl.setColor(Color.parseColor("#FF4CE07A"));
            c.drawCircle(px, py, 6f, bl);
            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setColor(Color.argb(150, 76, 224, 122));
            ring.setStyle(Paint.Style.STROKE);
            c.drawCircle(px, py, 11f, ring);
        }

        Paint lp = new Paint(pText);
        lp.setTextSize(20f);
        lp.setColor(Color.parseColor("#FF4CE07A"));
        c.drawText("RADAR 40m", cx - 42f, cy + R + 26f, lp);
    }

    private void drawPanel(Canvas c) {
        float x0 = 18f, y0 = 18f;
        Paint bg = new Paint();
        bg.setColor(Color.argb(170, 10, 12, 16));
        c.drawRoundRect(x0, y0, x0 + 340f, y0 + 106f, 10f, 10f, bg);

        Paint t1 = new Paint(pText);
        t1.setColor(Color.parseColor("#FF4CE07A"));
        t1.setTextSize(27f);
        t1.setFakeBoldText(true);
        c.drawText("天神辅助 · EarthOL", x0 + 14f, y0 + 33f, t1);

        Paint t2 = new Paint(pText);
        t2.setTextSize(23f);
        c.drawText("FPS " + String.format("%.0f", fps) + "   模型 " + modelName,
                x0 + 14f, y0 + 65f, t2);
        c.drawText("当前目标 " + curCount + "   累计计数 " + totalCount,
                x0 + 14f, y0 + 94f, t2);

        float ly = getHeight() - 28f;
        Paint t3 = new Paint(pText);
        t3.setTextSize(23f);
        t3.setColor(Color.parseColor("#FF9CFFC0"));
        int n = 0;
        for (MainActivity.Target t : targets) {
            if (n++ >= 5) break;
            c.drawText("目标" + t.id + " " + t.label + " " + String.format("%.1f", t.distM) + "m",
                    20f, ly, t3);
            ly -= 27f;
        }
    }
}
