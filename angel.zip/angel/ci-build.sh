#!/usr/bin/env bash
# 天使辅助 · 完整构建脚本
# 所有逻辑都在这里，workflow 只负责调用它。
# 以后只需更新 zip 里的这个文件，不用再改 workflow。
set +e

ROOT="$(pwd)"
OUT="$ROOT/out"
mkdir -p "$OUT"

log () { echo ""; echo "########## $1 ##########"; }

# ---------------------------------------------------------------- 1. 定位工程
log "LOCATE PROJECT"
for d in angel tianshen; do
  if [ -d "$ROOT/$d/android" ]; then
    rm -rf "$ROOT/android"
    cp -r "$ROOT/$d/android" "$ROOT/android"
    echo "using project dir: $d"
    break
  fi
done
if [ ! -f "$ROOT/android/settings.gradle" ]; then
  echo "::error::PROJECT_NOT_FOUND"
  ls -la "$ROOT"
  exit 1
fi
echo "sdk.dir=$ANDROID_HOME" > "$ROOT/android/local.properties"
ls "$ROOT/android"

# ---------------------------------------------------------------- 2. Android SDK
log "ANDROID SDK"
SM=""
for c in "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" \
         "$ANDROID_HOME/cmdline-tools/bin/sdkmanager" \
         "$ANDROID_HOME/tools/bin/sdkmanager" \
         "$(command -v sdkmanager)"; do
  [ -x "$c" ] && { SM="$c"; break; }
done
echo "sdkmanager=[$SM]"
if [ -n "$SM" ]; then
  yes 2>/dev/null | "$SM" --licenses >/dev/null 2>&1
  "$SM" "platform-tools" >/dev/null 2>&1
  "$SM" "platforms;android-34" >/dev/null 2>&1
  "$SM" "build-tools;34.0.0" >/dev/null 2>&1
fi
echo "--- platforms ---"; ls "$ANDROID_HOME/platforms" || echo "none"
echo "--- build-tools ---"; ls "$ANDROID_HOME/build-tools" || echo "none"

# ---------------------------------------------------------------- 3. 模型
log "MAKE MODEL"
ASSETS="$ROOT/android/app/src/main/assets"
mkdir -p "$ASSETS"
cd "$ASSETS" || exit 1

ok () { [ -s "$1" ] && [ "$(stat -c%s "$1")" -gt 1000000 ]; }

echo "=== ROUTE A: export standard ultralytics tflite ==="
if ! ok yolov8_det.tflite; then
  curl -sL --max-time 180 -o yolov8n.pt \
    https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n.pt
  curl -sL --max-time 300 -o yolov8s.pt \
    https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8s.pt
  echo "pt sizes: n=$(stat -c%s yolov8n.pt 2>/dev/null || echo 0) s=$(stat -c%s yolov8s.pt 2>/dev/null || echo 0)"

  python3 -m pip install --upgrade pip
  # 必须先锁 torch：新版 torch 导出时会报
  # AttributeError: '_OpNamespace' 'aten' object has no attribute 'cholesky'
  echo "--- installing torch==2.0.1 ---"
  python3 -m pip install "torch==2.0.1" "torchvision==0.15.2"
  echo "--- installing tensorflow-cpu ---"
  python3 -m pip install "tensorflow-cpu==2.15.0"
  echo "--- installing ultralytics ---"
  python3 -m pip install "ultralytics==8.0.196"
  python3 -c "import torch;print('torch',torch.__version__)" 2>&1 | tail -2
  python3 -c "import tensorflow as tf;print('tf',tf.__version__)" 2>&1 | tail -2
  python3 -c "import ultralytics;print('ultralytics',ultralytics.__version__)" 2>&1 | tail -2

  echo "--- exporting tflite imgsz=320 (s -> n) ---"
  python3 - <<'PYEOF'
import os, shutil, traceback
# 精度优先：yolov8s 明显优于 yolov8n；失败则回退 n
for tag in ["yolov8s", "yolov8n"]:
    if not os.path.exists(tag + ".pt"):
        print("skip", tag, "(no pt file)", flush=True)
        continue
    try:
        print("TRY", tag, flush=True)
        from ultralytics import YOLO
        p = YOLO(tag + ".pt").export(format="tflite", imgsz=320)
        print("exported:", p, flush=True)
        shutil.copy(p, "yolov8_det.tflite")
        print("EXPORT_OK", tag, os.path.getsize("yolov8_det.tflite"), flush=True)
        break
    except Exception:
        traceback.print_exc()
PYEOF
fi

echo "=== ROUTE B: download prebuilt tflite (fallback) ==="
if ! ok yolov8_det.tflite; then
  for u in \
    "https://huggingface.co/opencv/opencv_contribution/resolve/main/yolov8n/yolov8n.tflite" \
    "https://huggingface.co/opencv/opencv_contribution/resolve/main/yolov8n/yolov8n_float32.tflite" \
    "https://huggingface.co/Ultralytics/yolov8n/resolve/main/yolov8n.tflite" \
    "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n.tflite" \
    "https://huggingface.co/opencv/opencv_contribution/resolve/main/yolov8n/yolov8n_float16.tflite"
  do
    rm -f tmp.tflite
    curl -sL --max-time 90 -o tmp.tflite "$u"
    echo "  $(stat -c%s tmp.tflite 2>/dev/null || echo 0) bytes  <- $u"
    if ok tmp.tflite; then mv tmp.tflite yolov8_det.tflite; echo "  ROUTE B OK"; break; fi
  done
  rm -f tmp.tflite
fi

echo "=== assets ==="
ls -la
if ok yolov8_det.tflite; then
  echo "::notice::DET_OK size=$(stat -c%s yolov8_det.tflite)"
else
  echo "::error::DET_MISSING - app will run in MOCK mode"
fi
cd "$ROOT" || exit 1

# ---------------------------------------------------------------- 4. Gradle
log "GRADLE"
curl -sSL -o /tmp/g.zip https://services.gradle.org/distributions/gradle-8.5-bin.zip
sudo unzip -q -o /tmp/g.zip -d /opt
sudo chmod +x /opt/gradle-8.5/bin/gradle
/opt/gradle-8.5/bin/gradle --version 2>&1 | head -6

# ---------------------------------------------------------------- 5. 编译
log "BUILD APK"
cd "$ROOT/android" || exit 1
/opt/gradle-8.5/bin/gradle assembleDebug --no-daemon \
  -Dorg.gradle.jvmargs=-Xmx3g > /tmp/g.log 2>&1
EXIT=$?
cd "$ROOT" || exit 1
echo "GRADLE_EXIT=$EXIT"
if [ "$EXIT" -ne 0 ]; then
  echo "== WHAT WENT WRONG =="
  sed -n '/What went wrong:/,/^\* Try:/p' /tmp/g.log
  echo "== ERRORS =="
  grep -m8 "error:" /tmp/g.log
  echo "== CAUSED BY =="
  grep -m4 -A3 "Caused by:" /tmp/g.log
fi

cp -v "$ROOT"/android/app/build/outputs/apk/debug/*.apk "$OUT"/ 2>/dev/null
find "$ROOT" -name "*.apk" -exec cp {} "$OUT"/ \; 2>/dev/null

# ---------------------------------------------------------------- 6. 拆包验证
log "VERIFY APK"
APK=$(ls -1 "$OUT"/*.apk 2>/dev/null | head -1)
if [ -z "$APK" ]; then
  echo "::error::NO_APK"
  echo "== gradle log tail =="; tail -60 /tmp/g.log
  exit 1
fi
echo "== APK =="
ls -la "$APK"
echo "== tflite inside APK =="
unzip -l "$APK" | grep -i "\.tflite" || echo "(none)"
if unzip -l "$APK" | grep -qi "\.tflite"; then
  echo "::notice::MODEL_INSIDE_APK"
else
  echo "::error::MODEL_NOT_IN_APK - app will run in MOCK mode"
fi

log "DONE"
ls -la "$OUT"
exit 0
