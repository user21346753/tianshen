#!/usr/bin/env bash
# ============================================================================
#  天使辅助 · 完整构建脚本（平台无关）
#
#  特点：
#   1. 自己装 JDK 17 和 Android SDK —— 不要求 CI 平台预装
#   2. 国内镜像优先（Gradle / pip / Android SDK），国外源兜底
#   3. 任何能跑 Linux + bash 的 CI 都能用：
#        GitHub Actions / CODING(Jenkinsfile) / GitLab CI / Gitee Go / 自建机器
#
#  产物：out/*.apk
# ============================================================================
set +e

ROOT="$(pwd)"
OUT="$ROOT/out"
mkdir -p "$OUT"

log () { echo ""; echo "########## $1 ##########"; }

# 在有镜像的情况下用镜像，否则走官方源
mirrored_curl () {
  # $1=输出文件  $2..=候选 URL（按顺序尝试）
  local out="$1"; shift
  for u in "$@"; do
    rm -f "$out"
    curl -sL --max-time 180 -o "$out" "$u"
    local sz
    sz=$(stat -c%s "$out" 2>/dev/null || echo 0)
    if [ "$sz" -gt 1000 ]; then
      echo "  OK  $sz bytes  <- $u"
      return 0
    fi
    echo "  --  $sz bytes  <- $u"
  done
  return 1
}

# ---------------------------------------------------------------- 1. 定位工程
log "LOCATE PROJECT"
for d in angel tianshen; do
  if [ -d "$ROOT/$d/android" ]; then
    rm -rf "$ROOT/android"
    cp -r "$ROOT/$d/android" "$ROOT/android"
    echo "using project dir: $d"
    break
  fi
done
if [ ! -f "$ROOT/android/settings.gradle" ]; then
  echo "::error::PROJECT_NOT_FOUND"
  ls -la "$ROOT"
  exit 1
fi

# ---------------------------------------------------------------- 2. JDK 17
log "JDK 17"
if ! java -version 2>&1 | grep -q 'version "17'; then
  echo "installing Temurin JDK 17..."
  mkdir -p /opt/jdk
  if mirrored_curl /tmp/jdk.tgz \
      "https://mirrors.tuna.tsinghua.edu.cn/Adoptium/17/jdk/x64/linux/OpenJDK17U-jdk_x64_linux_hotspot_17.0.9_9.tar.gz" \
      "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse" ; then
    tar -xzf /tmp/jdk.tgz -C /opt/jdk --strip-components=1
    export JAVA_HOME=/opt/jdk
    export PATH="$JAVA_HOME/bin:$PATH"
  fi
fi
java -version 2>&1 | head -2
echo "JAVA_HOME=${JAVA_HOME:-（系统自带）}"

# ---------------------------------------------------------------- 3. Android SDK
log "ANDROID SDK"
if [ -z "$ANDROID_HOME" ] || [ ! -d "$ANDROID_HOME/platforms/android-34" ]; then
  export ANDROID_HOME=/opt/android-sdk
  export ANDROID_SDK_ROOT=/opt/android-sdk
  mkdir -p "$ANDROID_HOME"

  echo "installing commandline-tools..."
  mkdir -p /opt/cmdtools/latest
  if mirrored_curl /tmp/cmdtools.zip \
      "https://mirrors.cloud.tencent.com/AndroidSDK/commandlinetools-linux-9477386_latest.zip" \
      "https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip" ; then
    unzip -q -o /tmp/cmdtools.zip -d /opt/cmdtools_tmp
    mv /opt/cmdtools_tmp/cmdline-tools/* /opt/cmdtools/latest/ 2>/dev/null
  fi
  export PATH="/opt/cmdtools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
fi

SM=""
for c in "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" \
         "/opt/cmdtools/latest/bin/sdkmanager" \
         "$ANDROID_HOME/tools/bin/sdkmanager" \
         "$(command -v sdkmanager)"; do
  [ -x "$c" ] && { SM="$c"; break; }
done
echo "sdkmanager=[$SM]"

if [ -n "$SM" ]; then
  mkdir -p "$ANDROID_HOME/licenses"
  printf '\n24333f8a63b6825ea9c5514f83c2829b004d1fee\n' > "$ANDROID_HOME/licenses/android-sdk-license"
  printf '\n84831b9409646a918e30573bab4c9c91346d8abd\n' > "$ANDROID_HOME/licenses/android-sdk-preview-license"
  yes 2>/dev/null | "$SM" --licenses >/dev/null 2>&1
  echo "--- installing platform-tools / platform-34 / build-tools-34 ---"
  "$SM" "platform-tools" 2>&1 | tail -2
  "$SM" "platforms;android-34" 2>&1 | tail -2
  "$SM" "build-tools;34.0.0" 2>&1 | tail -2
fi
echo "--- platforms ---"; ls "$ANDROID_HOME/platforms" 2>/dev/null || echo "none"
echo "--- build-tools ---"; ls "$ANDROID_HOME/build-tools" 2>/dev/null || echo "none"
echo "sdk.dir=$ANDROID_HOME" > "$ROOT/android/local.properties"

# ---------------------------------------------------------------- 4. 模型
log "MAKE MODEL"
ASSETS="$ROOT/android/app/src/main/assets"
mkdir -p "$ASSETS"
cd "$ASSETS" || exit 1

# 清掉历史残留，避免把上一轮下载的旧模型又打进 APK
rm -f yolov8_det.tflite yolov8_pose.tflite yolov8n.pt yolov8s.pt

ok () { [ -s "$1" ] && [ "$(stat -c%s "$1")" -gt 1000000 ]; }

PIP_ARGS="-i https://pypi.tuna.tsinghua.edu.cn/simple"
echo "using Tsinghua pip mirror"
export PIP_BREAK_SYSTEM_PACKAGES=1

echo "=== ROUTE A: export standard ultralytics tflite ==="
if ! ok yolov8_det.tflite; then
  mirrored_curl yolov8n.pt \
    "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n.pt"
  mirrored_curl yolov8s.pt \
    "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8s.pt"
  echo "pt sizes: n=$(stat -c%s yolov8n.pt 2>/dev/null || echo 0) s=$(stat -c%s yolov8s.pt 2>/dev/null || echo 0)"

  python3 -m pip install --upgrade pip $PIP_ARGS 2>&1 | tail -2
  # torch 太新会在导出时报 cholesky 错误；CPU 版又快又小
  echo "--- installing torch==2.0.1 (cpu) ---"
  python3 -m pip install "torch==2.0.1" "torchvision==0.15.2" \
    --index-url https://download.pytorch.org/whl/cpu $PIP_ARGS 2>&1 | tail -3
  echo "--- installing tensorflow-cpu ---"
  python3 -m pip install "tensorflow-cpu==2.15.0" $PIP_ARGS 2>&1 | tail -3
  echo "--- installing ultralytics ---"
  python3 -m pip install "ultralytics==8.0.196" $PIP_ARGS 2>&1 | tail -3
  # 关键：numpy 必须最后装。tensorflow/ultralytics 会把 numpy 拉回 2.x，
  # 而 numpy 2.x 会让 tf 导入失败（numpy.core.umath failed to import）。
  echo "--- re-pinning numpy==1.26.4 (must be last) ---"
  python3 -m pip install "numpy==1.26.4" $PIP_ARGS 2>&1 | tail -3
  python3 -c "import numpy;print('numpy',numpy.__version__)" 2>&1 | tail -2

  python3 -c "import torch;print('torch',torch.__version__)" 2>&1 | tail -2
  python3 -c "import tensorflow as tf;print('tf',tf.__version__)" 2>&1 | tail -2
  python3 -c "import ultralytics;print('ultralytics',ultralytics.__version__)" 2>&1 | tail -2

  echo "--- exporting tflite imgsz=320 (s -> n) ---"
  python3 - <<'PYEOF'
import os, shutil, traceback
# 精度优先：s 明显优于 n（n 常把人认成猫狗）。s 失败才退 n。
for tag in ["yolov8s", "yolov8n"]:
    if not os.path.exists(tag + ".pt"):
        print("skip", tag, "(no pt file)", flush=True)
        continue
    try:
        print("TRY", tag, flush=True)
        from ultralytics import YOLO
        p = YOLO(tag + ".pt").export(format="tflite", imgsz=320)
        print("exported:", p, flush=True)
        shutil.copy(p, "yolov8_det.tflite")
        print("EXPORT_OK", tag, os.path.getsize("yolov8_det.tflite"), flush=True)
        break
    except Exception:
        traceback.print_exc()
PYEOF
fi

echo "=== ROUTE B: download prebuilt tflite (fallback) ==="
if ! ok yolov8_det.tflite; then
  for u in \
    "https://huggingface.co/opencv/opencv_contribution/resolve/main/yolov8n/yolov8n.tflite" \
    "https://huggingface.co/opencv/opencv_contribution/resolve/main/yolov8n/yolov8n_float32.tflite" \
    "https://huggingface.co/Ultralytics/yolov8n/resolve/main/yolov8n.tflite" \
    "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n.tflite"
  do
    rm -f tmp.tflite
    curl -sL --max-time 120 -o tmp.tflite "$u"
    echo "  $(stat -c%s tmp.tflite 2>/dev/null || echo 0) bytes  <- $u"
    if ok tmp.tflite; then mv tmp.tflite yolov8_det.tflite; echo "  ROUTE B OK"; break; fi
  done
  rm -f tmp.tflite
fi

echo "=== assets ==="
ls -la
if ok yolov8_det.tflite; then
  echo "::notice::DET_OK size=$(stat -c%s yolov8_det.tflite)"
else
  echo "::error::DET_MISSING - app will run in MOCK mode"
fi
cd "$ROOT" || exit 1

# ---------------------------------------------------------------- 5. Gradle
log "GRADLE"
# 关键：不能用 runner 自带的 Gradle（现在镜像预装的是 Gradle 9），
# AGP 8.1.4 与 Gradle 9 不兼容，会直接构建失败。必须固定用 8.5。
GRADLE_BIN=""
if command -v gradle >/dev/null 2>&1; then
  echo "runner 自带 gradle（不使用）: $(gradle --version 2>/dev/null | grep '^Gradle' | head -1)"
fi
if [ -z "$GRADLE_BIN" ]; then
  for u in \
      "https://mirrors.cloud.tencent.com/gradle/gradle-8.5-bin.zip" \
      "https://services.gradle.org/distributions/gradle-8.5-bin.zip" ; do
    echo "downloading gradle from $u"
    if curl -sSL --max-time 300 -o /tmp/g.zip "$u" && [ -s /tmp/g.zip ]; then
      sudo unzip -q -o /tmp/g.zip -d /opt
      chmod +x /opt/gradle-8.5/bin/gradle
      if [ -x /opt/gradle-8.5/bin/gradle ]; then
        GRADLE_BIN=/opt/gradle-8.5/bin/gradle
        break
      fi
    fi
  done
fi
if [ -z "$GRADLE_BIN" ]; then
  echo "::error::GRADLE_DOWNLOAD_FAILED"
  exit 1
fi
echo "=== using gradle ==="
$GRADLE_BIN --version 2>&1 | head -8
echo "GRADLE_VERSION=$($GRADLE_BIN --version 2>/dev/null | grep '^Gradle' | head -1)"

# ---------------------------------------------------------------- 6. 编译
log "BUILD APK"
cd "$ROOT/android" || exit 1
$GRADLE_BIN assembleDebug --no-daemon \
  -Dorg.gradle.jvmargs=-Xmx3g > /tmp/g.log 2>&1
EXIT=$?
cd "$ROOT" || exit 1
echo "GRADLE_EXIT=$EXIT"
if [ "$EXIT" -ne 0 ]; then
  echo "== WHAT WENT WRONG =="
  sed -n '/What went wrong:/,/^\* Try:/p' /tmp/g.log
  echo "== ERRORS =="
  grep -m8 "error:" /tmp/g.log
  echo "== CAUSED BY =="
  grep -m4 -A3 "Caused by:" /tmp/g.log
fi

cp -v "$ROOT"/android/app/build/outputs/apk/debug/*.apk "$OUT"/ 2>/dev/null
find "$ROOT" -name "*.apk" -exec cp {} "$OUT"/ \; 2>/dev/null

# ---------------------------------------------------------------- 7. 拆包验证
log "VERIFY APK"
APK=$(ls -1 "$OUT"/*.apk 2>/dev/null | head -1)
if [ -z "$APK" ]; then
  echo "::error::NO_APK"
  echo "== gradle log tail =="; tail -80 /tmp/g.log
  exit 1
fi
echo "== APK =="
ls -la "$APK"
echo "== tflite inside APK =="
unzip -l "$APK" | grep -i "\.tflite" || echo "(none)"
if unzip -l "$APK" | grep -qi "\.tflite"; then
  echo "::notice::MODEL_INSIDE_APK"
else
  echo "::error::MODEL_NOT_IN_APK - app will run in MOCK mode"
fi

log "DONE"
ls -la "$OUT"
exit 0
