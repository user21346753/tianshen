#!/usr/bin/env bash
# 天使辅助 · 完整构建脚本
# 所有逻辑都在这里，workflow 只负责解压并调用它。
set +e

ROOT="$(pwd)"
OUT="$ROOT/out"
mkdir -p "$OUT"

# 常规镜像源不通时的备选前缀
MIRRORS=("" "https://ghfast.top/" "https://gh-proxy.com/" "https://ghproxy.net/")

mirrored_curl () {
  local out="$1"; shift
  for m in "${MIRRORS[@]}"; do
    for u in "$@"; do
      rm -f "$out"
      if curl -sL --max-time 240 -o "$out" "${m}${u}" && [ -s "$out" ]; then
        echo "downloaded via ${m:-direct}: $u ($(stat -c%s "$out") bytes)"
        return 0
      fi
    done
  done
  echo "download failed: $out"
  return 1
}

log () { echo ""; echo "########## $1 ##########"; }

# ---------------------------------------------------------------- 1. 定位工程
log "LOCATE PROJECT"
for d in angel tianshen; do
  if [ -d "$ROOT/$d/android" ]; then
    rm -rf "$ROOT/android"
    cp -r "$ROOT/$d/android" "$ROOT/android"
    echo "using project dir: $d"
    break
  fi
done
if [ ! -f "$ROOT/android/settings.gradle" ]; then
  echo "::error::PROJECT_NOT_FOUND"
  ls -la "$ROOT"
  exit 1
fi
echo "sdk.dir=$ANDROID_HOME" > "$ROOT/android/local.properties"
ls "$ROOT/android"

# ---------------------------------------------------------------- 2. Android SDK
log "ANDROID SDK"
SM=""
for c in "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" \
         "$ANDROID_HOME/cmdline-tools/bin/sdkmanager" \
         "$ANDROID_HOME/tools/bin/sdkmanager" \
         "$(command -v sdkmanager)"; do
  [ -x "$c" ] && { SM="$c"; break; }
done
echo "sdkmanager=[$SM]"
if [ -n "$SM" ]; then
  yes 2>/dev/null | "$SM" --licenses >/dev/null 2>&1
  "$SM" "platform-tools" >/dev/null 2>&1
  "$SM" "platforms;android-34" >/dev/null 2>&1
  "$SM" "build-tools;34.0.0" >/dev/null 2>&1
fi
echo "--- platforms ---"; ls "$ANDROID_HOME/platforms" || echo "none"
echo "--- build-tools ---"; ls "$ANDROID_HOME/build-tools" || echo "none"

# ---------------------------------------------------------------- 3. 模型
log "MAKE MODEL (ONNX) - N VERSION (FLUENT)"
ASSETS="$ROOT/android/app/src/main/assets"
mkdir -p "$ASSETS"
cd "$ASSETS" || exit 1
rm -f yolov8n.onnx yolov8n-pose.onnx

ok () { [ -s "$1" ] && [ "$(stat -c%s "$1")" -gt 1000000 ]; }

echo "=== ROUTE A0: try download pose onnx directly (fastest) ==="
if ! ok yolov8n-pose.onnx; then
  for u in \
    "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n-pose.onnx" ; do
    rm -f tmp.onnx
    curl -sL --max-time 300 -o tmp.onnx "$u"
    echo "  $(stat -c%s tmp.onnx 2>/dev/null || echo 0) bytes  <- $u"
    if ok tmp.onnx; then mv tmp.onnx yolov8n-pose.onnx; echo "  POSE_DOWNLOAD_OK"; break; fi
  done
  rm -f tmp.onnx
fi
if ok yolov8n-pose.onnx; then
  echo "::notice::POSE_READY size=$(stat -c%s yolov8n-pose.onnx)"
else
  echo "::warning::POSE_ONNX_NOT_DOWNLOADED - will try export from pt"
fi

echo "=== ROUTE A: download .pt ==="
# 精度优先：先试 yolov8s（明显比 n 准，误判少），失败再退 n
mirrored_curl yolov8n.pt \
  "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n.pt"
# 姿态权重：只保留实测可用的 GitHub 源（其它源返回 404/HTML，会污染文件）
for pu in \
  "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n-pose.pt" ; do
  [ -s yolov8n-pose.pt ] && [ "$(stat -c%s yolov8n-pose.pt)" -gt 1000000 ] && break
  rm -f yolov8n-pose.pt
  curl -sL --max-time 300 -o yolov8n-pose.pt "$pu"
  echo "  pose.pt $(stat -c%s yolov8n-pose.pt 2>/dev/null || echo 0) bytes <- $pu"
done
echo "pt sizes: s=$(stat -c%s yolov8s.pt 2>/dev/null || echo 0) n=$(stat -c%s yolov8n.pt 2>/dev/null || echo 0) pose=$(stat -c%s yolov8n-pose.pt 2>/dev/null || echo 0)"

if [ -s yolov8s.pt ] || [ -s yolov8n.pt ] || [ -s yolov8n-pose.pt ]; then
  echo "--- installing python deps ---"
  python3 -m pip install --upgrade pip 2>&1 | tail -2
  # torch 太新会在导出时报 cholesky 错误，CPU 版又快又小
  echo "--- torch==2.0.1 (cpu) ---"
  python3 -m pip install "torch==2.0.1" "torchvision==0.15.2" \
    --index-url https://download.pytorch.org/whl/cpu 2>&1 | tail -3
  echo "--- ultralytics ---"
  python3 -m pip install "ultralytics==8.0.196" 2>&1 | tail -3
  echo "--- onnx / onnxsim ---"
  python3 -m pip install "onnx==1.15.0" "onnxsim==0.4.36" 2>&1 | tail -3
  # numpy 必须最后装：其它包会把它拉回 2.x
  echo "--- numpy==1.26.4 (must be last) ---"
  python3 -m pip install "numpy==1.26.4" 2>&1 | tail -3

  python3 -c "import torch;print('torch',torch.__version__)" 2>&1 | tail -2
  python3 -c "import ultralytics;print('ultralytics',ultralytics.__version__)" 2>&1 | tail -2
  python3 -c "import onnx;print('onnx',onnx.__version__)" 2>&1 | tail -2
  python3 -c "import numpy;print('numpy',numpy.__version__)" 2>&1 | tail -2

  echo "--- exporting ONNX imgsz=320 ---"
  python3 - <<'PYEOF'
import os, shutil, traceback

def safe_copy(src, dst):
    """导出路径常常就是目标文件名，shutil.copy 会抛 SameFileError，
    导致明明导出成功却被判成失败。相同就跳过，不同才复制。"""
    try:
        if os.path.abspath(src) == os.path.abspath(dst):
            print("skip copy (same file):", src, flush=True)
            return True
        if os.path.exists(src) and os.path.getsize(src) > 0:
            shutil.copy(src, dst)
            return True
    except Exception:
        traceback.print_exc()
    return False

def exp(pt, tag):
    if not os.path.exists(pt):
        print("skip", pt, "(not downloaded)", flush=True)
        return None
    for simp in (True, False):
        try:
            print("TRY", tag, "simplify=", simp, flush=True)
            from ultralytics import YOLO
            p = YOLO(pt).export(format="onnx", imgsz=320, simplify=simp)
            print("exported:", p, flush=True)
            return p
        except Exception:
            traceback.print_exc()
    return None

# 按精度优先顺序导出，成功一个就停
# ===== N 版：流畅优先，只导出 yolov8n =====
for pt, tag in (("yolov8n.pt", "yolov8n"),):
    p = exp(pt, tag)
    if p and os.path.exists(p):
        # 保留型号名，界面右下角会显示 yolov8s / yolov8n，一眼可辨
        if safe_copy(p, tag + ".onnx"):
            print("DET_OK", tag, os.path.getsize(tag + ".onnx"), flush=True)
            break

# 姿态模型：只有下载失败时才导出。
# 关键修复：之前这里只试 simplify=True 一次就换尺寸，
# 而 det 那边是 simplify 两个值都试。pose 算子更多，simplify 更容易失败，
# 所以 pose 一直导出不出来。这里改成和 det 完全一样的重试策略。
def pose_ready():
    return os.path.exists("yolov8n-pose.onnx") and os.path.getsize("yolov8n-pose.onnx") > 1000000

print("pose.pt exists:", os.path.exists("yolov8n-pose.pt"),
      os.path.getsize("yolov8n-pose.pt") if os.path.exists("yolov8n-pose.pt") else 0,
      flush=True)

if pose_ready():
    print("pose already downloaded, skip export", flush=True)
else:
    for sz in (320, 256):
        done = False
        # simplify=False 优先：直接 torch.onnx.export，不依赖 onnxsim，
        # pose 算子多，simplify 极易失败，这是之前一直导不出的主因
        for simp in (False, True):
            try:
                print("TRY pose imgsz=" + str(sz) + " simplify=" + str(simp), flush=True)
                from ultralytics import YOLO
                p = YOLO("yolov8n-pose.pt").export(format="onnx", imgsz=sz,
                                                   simplify=simp, opset=12)
                if p and os.path.exists(p):
                    if safe_copy(p, "yolov8n-pose.onnx"):
                        print("POSE_OK", sz, "simplify=" + str(simp),
                              os.path.getsize("yolov8n-pose.onnx"), flush=True)
                        done = True
                        break
                elif os.path.exists("yolov8n-pose.onnx") \
                        and os.path.getsize("yolov8n-pose.onnx") > 1000000:
                    # 导出器可能已直接写到了目标文件名，只是返回值异常
                    print("POSE_OK (file already at target)", sz,
                          os.path.getsize("yolov8n-pose.onnx"), flush=True)
                    done = True
                    break
            except Exception:
                traceback.print_exc()
                print("pose export failed imgsz=" + str(sz) + " simplify=" + str(simp),
                      flush=True)
        if done:
            break

# ultralytics 导出全失败时，用 torch 原生导出再试一次
if not pose_ready():
    try:
        print("TRY raw torch.onnx.export for pose", flush=True)
        import torch
        from ultralytics.nn.tasks import attempt_load_one_weight
        model, _ = attempt_load_one_weight("yolov8n-pose.pt", None)
        model.eval()
        dummy = torch.zeros(1, 3, 320, 320)
        torch.onnx.export(model, dummy, "yolov8n-pose.onnx",
                          input_names=["images"], output_names=["output0"],
                          opset=12, do_constant_folding=True)
        print("POSE_TORCH_OK", os.path.getsize("yolov8n-pose.onnx"), flush=True)
    except Exception:
        traceback.print_exc()
        print("raw torch pose export failed", flush=True)

# 最后兜底：目录里任何带 pose 的 onnx 都认
import glob
if not pose_ready():
    for f in glob.glob("*pose*.onnx"):
        if os.path.getsize(f) > 1000000:
            if safe_copy(f, "yolov8n-pose.onnx"):
                print("POSE_RECOVERED from", f, os.path.getsize(f), flush=True)
                break
print("POSE_FINAL:", pose_ready(), flush=True)
print("DIR ONNX:", sorted(glob.glob("*.onnx")), flush=True)
for f in sorted(glob.glob("*.onnx")):
    print("  ", f, os.path.getsize(f), flush=True)
PYEOF
fi

echo "=== ROUTE B2: pose fallback ==="
if ! ok yolov8n-pose.onnx; then
  for u in \
    "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n-pose.onnx" ; do
    rm -f tmp.onnx
    curl -sL --max-time 240 -o tmp.onnx "$u"
    echo "  $(stat -c%s tmp.onnx 2>/dev/null || echo 0) bytes  <- $u"
    if ok tmp.onnx; then mv tmp.onnx yolov8n-pose.onnx; echo "  POSE DOWNLOAD OK"; break; fi
  done
  rm -f tmp.onnx
fi

echo "=== ROUTE B: download prebuilt onnx (fallback) ==="
if ! ls yolov8*.onnx >/dev/null 2>&1 || ! ok "$(ls -S yolov8s.onnx yolov8n.onnx yolov8m.onnx 2>/dev/null | head -1)"; then
  for u in \
    "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n.onnx" \
    "https://huggingface.co/Ultralytics/yolov8n/resolve/main/yolov8n.onnx" ; do
    rm -f tmp.onnx
    curl -sL --max-time 180 -o tmp.onnx "$u"
    echo "  $(stat -c%s tmp.onnx 2>/dev/null || echo 0) bytes  <- $u"
    if ok tmp.onnx; then mv tmp.onnx yolov8n.onnx; echo "  ROUTE B OK"; break; fi
  done
  rm -f tmp.onnx
fi

echo "=== model status ==="
rm -f yolov8s.onnx yolov8m.onnx
DET_FILE=$(ls -S yolov8n.onnx 2>/dev/null | head -1)
if [ -n "$DET_FILE" ] && ok "$DET_FILE"; then
  echo "::notice::DET_OK $DET_FILE size=$(stat -c%s "$DET_FILE")"
  echo "SELECTED_DET_MODEL=$DET_FILE"
else
  echo "::error::DET_MISSING - app will run in MOCK mode"
fi
if ok yolov8n-pose.onnx; then
  echo "::notice::POSE_OK size=$(stat -c%s yolov8n-pose.onnx)"
else
  echo "::notice::POSE_MISSING - skeleton will use heuristic"
fi

echo "=== cleanup assets ==="
find . -maxdepth 1 -type d -name "*_saved_model" -exec rm -rf {} + 2>/dev/null
find . -maxdepth 1 -type f \( -name "*.pt" -o -name "*.tflite" -o -name "README.txt" \
     -o -name "*.torchscript" -o -name "*.engine" -o -name "*.mlmodel" \
     -o -name "*.onnx.tmp" -o -name "tmp.onnx" \) -exec rm -f {} + 2>/dev/null
# 只保留选中的检测模型（按 s > m > n 精度优先），删掉其余型号，避免 APK 里塞多个模型
rm -f yolov8s.onnx yolov8m.onnx
DET_FILE=$(ls -S yolov8n.onnx 2>/dev/null | head -1)
for f in yolov8s.onnx yolov8m.onnx yolov8n.onnx; do
  if [ "$f" != "$DET_FILE" ]; then rm -f "$f"; fi
done
rm -f yolov8s-pose.onnx yolov8m-pose.onnx
# 姿态模型必须保住，否则骨骼功能直接失效
if [ -s yolov8n-pose.onnx ]; then
  echo "POSE_KEPT size=$(stat -c%s yolov8n-pose.onnx)"
else
  echo "::warning::POSE_STILL_MISSING"
fi

echo "=== assets ==="
ls -la
cd "$ROOT" || exit 1

# ---------------------------------------------------------------- 4. Gradle
log "GRADLE"
# 关键：不能用 runner 自带的 Gradle（镜像已预装 Gradle 9），
# AGP 8.1.4 与 Gradle 9 不兼容会直接构建失败，必须固定 8.5。
GRADLE_BIN=""
if command -v gradle >/dev/null 2>&1; then
  echo "runner gradle (NOT used): $(gradle --version 2>/dev/null | grep '^Gradle' | head -1)"
fi
if [ -z "$GRADLE_BIN" ]; then
  for u in \
    "https://mirrors.cloud.tencent.com/gradle/gradle-8.5-bin.zip" \
    "https://services.gradle.org/distributions/gradle-8.5-bin.zip" ; do
    echo "downloading gradle from $u"
    if curl -sSL --max-time 300 -o /tmp/g.zip "$u" && [ -s /tmp/g.zip ]; then
      sudo unzip -q -o /tmp/g.zip -d /opt
      chmod +x /opt/gradle-8.5/bin/gradle
      if [ -x /opt/gradle-8.5/bin/gradle ]; then
        GRADLE_BIN=/opt/gradle-8.5/bin/gradle
        break
      fi
    fi
  done
fi
if [ -z "$GRADLE_BIN" ]; then
  echo "::error::GRADLE_DOWNLOAD_FAILED"
  exit 1
fi
echo "=== using gradle ==="
$GRADLE_BIN --version 2>&1 | head -8
echo "GRADLE_VERSION=$($GRADLE_BIN --version 2>/dev/null | grep '^Gradle' | head -1)"

# ---------------------------------------------------------------- 5. 编译
log "BUILD APK"
cd "$ROOT/android" || exit 1
$GRADLE_BIN assembleDebug --no-daemon \
  -Dorg.gradle.jvmargs=-Xmx3g > /tmp/g.log 2>&1
EXIT=$?
cd "$ROOT" || exit 1
echo "GRADLE_EXIT=$EXIT"
if [ "$EXIT" -ne 0 ]; then
  echo "== WHAT WENT WRONG =="
  sed -n '/What went wrong:/,/^\* Try:/p' /tmp/g.log
  echo "== ERRORS =="
  grep -m8 "error:" /tmp/g.log
  echo "== CAUSED BY =="
  grep -m4 -A3 "Caused by:" /tmp/g.log
fi

cp -v "$ROOT"/android/app/build/outputs/apk/debug/*.apk "$OUT"/ 2>/dev/null
find "$ROOT" -name "*.apk" -exec cp {} "$OUT"/ \; 2>/dev/null

# ---------------------------------------------------------------- 6. 拆包验证
log "VERIFY APK"
APK=$(ls -1 "$OUT"/*.apk 2>/dev/null | head -1)
if [ -z "$APK" ]; then
  echo "::error::NO_APK"
  echo "== gradle log tail =="; tail -80 /tmp/g.log
  exit 1
fi
echo "== APK =="
ls -la "$APK"
echo "== models inside APK =="
unzip -l "$APK" | grep -iE "\.onnx|\.tflite" || echo "(none)"

INSIDE_DET=$(unzip -l "$APK" | grep -iE "\.onnx" | grep -vi "pose" | head -1)
INSIDE_POSE=$(unzip -l "$APK" | grep -iE "\.onnx" | grep -i "pose" | head -1)

if [ -n "$INSIDE_DET" ]; then
  echo "::notice::DET_IN_APK: $INSIDE_DET"
else
  echo "::error::DET_NOT_IN_APK"
fi
if [ -n "$INSIDE_POSE" ]; then
  echo "::notice::POSE_IN_APK: $INSIDE_POSE"
else
  echo "::error::POSE_NOT_IN_APK - 骨骼将使用老版按框绘制（无真实关键点）"
fi
echo "APK_ONNX_LIST:"; unzip -l "$APK" | grep -iE "\.onnx" || echo "(empty)"

log "DONE"
ls -la "$OUT"
exit 0
