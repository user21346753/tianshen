# 天使辅助 · 安卓版（只有手机也能装）

摄像头取当前帧 → YOLOv8 检测 → 跨帧跟踪 → 单目测距 → 游戏外挂风格 HUD。

**先说清楚它能做什么、不能做什么：**

- 处理的是**摄像头当前这一帧**。画面里本来就看得到的人，会被加框、加骨骼、上雷达。
- 被墙挡住的、镜头外的，一个都画不出来 —— **没有透视**。
- 雷达上的远近是**估算值**（像素高度 + 焦距反推），不是激光测距。
- 骨骼默认按人体比例在框内生成；导入 pose 模型后才是真实关键点。

---

## 只有手机？走云编译（推荐）

手机上没 Gradle，装不了 Android Studio。**让 GitHub 的服务器帮你编译**，你只负责上传和下载。

### 第 1 步：准备一个 GitHub 账号
浏览器打开 `github.com` → Sign up（免费）。已有账号直接登录。

### 第 2 步：新建仓库
右上角 `+` → **New repository**
- 名字随便，比如 `angel`
- 选 **Public**（公开仓库才能免费用 Actions）
- 勾上 **Add a README file**
- 点 Create repository

### 第 3 步：上传压缩包
进仓库 → 点 **Add file** → **Upload files**
→ 选择你拿到的 `angel.zip`（只有一个文件，不用解压）→ 绿色按钮 **Commit changes**

### 第 4 步：创建自动编译脚本
仓库页面点顶部 **Actions** → 如果看到 "set up a workflow yourself"，点它；
否则点 **New workflow** → **set up a workflow yourself**

把**文件名**改成（注意不能错，这个路径会自动建目录）：

```
.github/workflows/build-apk.yml
```

内容粘贴 `build-apk.yml` 这个文件里的全部文字（压缩包里也有一份）。
然后右上角 **Commit changes**。

### 第 5 步：等编译，下 APK
提交后 Actions 会自动开跑（约 5–10 分钟）。
跑完在仓库右侧 **Releases** 里能看到 `天使辅助 APK`，
点开附件 `app-debug.apk` 下载 → 手机上安装（会提示"允许安装未知应用"，允许即可）。

> 如果下载慢或打不开，试试用流量、或换浏览器。
> 装完首次打开要允许相机权限。

---

## 编译完想看代码在哪

```
angel/
├── android/                      # 安卓工程
│   └── app/src/main/java/com/angel/hud/
│       ├── MainActivity.java     # 相机 + 控制面板 + 跟踪 + 测距
│       ├── Detector.java         # YOLOv8 TFLite（无模型自动 MOCK）
│       └── HudView.java          # HUD 绘制：框/骨骼/雷达/射线
├── python/                       # 电脑端的 Python 参考实现
├── tools/export_yolov8n_tflite.py
└── build-apk.yml                 # 云编译脚本
```

## 有电脑时（可选）

```bash
pip install ultralytics
python tools/export_yolov8n_tflite.py     # 导出模型到 assets
# 用 Android Studio 打开 android/ 目录 → Run
```

## 界面开关

| 开关 | 作用 |
|---|---|
| 绘制方框 | 检测框 + `#ID 类别 距离` |
| 绘制骨骼 | 骨架连线 |
| 绘制雷达 | 左下雷达盘，方位 + 距离 |
| 绘制射线 | 准星到目标的连线 |
| 多物体绘制 | 车、自行车等一并检测 |
| 探测灵敏度滑块 | 置信度阈值，调低框变多但乱框也变多 |
| 切换镜头 | 前后摄像头 |

## 关键实现

- **跟踪**：IoU 贪心匹配，丢失 12 帧剔除；`totalSeen` 累计唯一目标数 = 计数统计
- **测距**：`D = f_px × H_real / h_px`，优先读真机焦距与传感器尺寸，读不到用默认 49° 视场角
- **模型**：assets 放 `yolov8n.tflite`（检测）、`yolov8n-pose.tflite`（姿态）即自动启用；
  没有就进 **MOCK 模式**，用合成目标驱动整套 HUD，装上就能看效果
- **性能**：分析分辨率 640×480，KEEP_ONLY_LATEST 丢帧保实时。
  掉帧就降分辨率、换 fp16/int8 模型

## 隐私与合规（务必看）

- 应用**只在本地推理，不联网、不上传画面**。
- 但摄像头对准的是真实的人，请注意：
  - 不要对着他人录制、保存画面；
  - 不要拿它接人脸识别库去识别、跟踪特定个人；
  - 偷拍涉《治安管理处罚法》，采集人脸等生物识别信息涉《个人信息保护法》，
    情节严重可能构成非法使用窃听、窃照专用器材罪。
- 建议只在私有场景调试，或对着空旷街景、物体使用。
