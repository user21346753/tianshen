"""
天使辅助 · 现实版 HUD 核心引擎（Python 参考实现）

模块划分与 Android 端一一对应，方便对照移植：
    Target            -> Target.java
    IoUTracker        -> Tracker.java
    DistanceEstimator -> DistanceEstimator.java
    HudRenderer       -> HudView.java  (Canvas 绘制)

坐标系约定：(x1,y1) 左上, (x2,y2) 右下，单位像素。
"""

from __future__ import annotations
import math
import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np
import cv2

# ---------------------------------------------------------------- 目标定义

# 类别真实物理高度（米），用于单目测距
REAL_HEIGHT = {
    "person": 1.70,
    "bicycle": 1.20,
    "motorbike": 1.30,
    "car": 1.50,
    "bus": 3.20,
    "truck": 3.00,
    "default": 1.70,
}

CLS_ZH = {
    "person": "行人", "bicycle": "自行车", "motorbike": "电动车",
    "car": "汽车", "bus": "客车", "truck": "货车", "default": "目标",
}


@dataclass
class Det:
    """一帧里检测器出来的原始结果"""
    x1: float
    y1: float
    x2: float
    y2: float
    conf: float
    cls: str = "person"
    kps: Optional[np.ndarray] = None   # (17,3) 姿态关键点，没有则为 None


@dataclass
class Target:
    """跨帧跟踪后的目标"""
    tid: int
    box: Tuple[float, float, float, float]
    cls: str
    conf: float
    dist: float = 0.0
    age: int = 0            # 已跟踪帧数
    lost: int = 0           # 连续丢失帧数
    kps: Optional[np.ndarray] = None
    cx: float = 0.0
    cy: float = 0.0

    def update_box(self, b):
        self.box = b
        self.cx = (b[0] + b[2]) / 2
        self.cy = (b[1] + b[3]) / 2


# ---------------------------------------------------------------- 跟踪器

def iou(a: Tuple, b: Tuple) -> float:
    ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
    ix2, iy2 = min(a[2], b[2]), min(a[3], b[3])
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    if inter <= 0:
        return 0.0
    sa = max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])
    sb = max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])
    return inter / (sa + sb - inter + 1e-6)


class IoUTracker:
    """
    轻量 IoU 跟踪器：贪心匹配 + 命中计数。
    Android 端用同样的逻辑（见 Tracker.java）。
    """

    def __init__(self, iou_thr=0.35, max_lost=12, min_hits=2):
        self.iou_thr = iou_thr
        self.max_lost = max_lost
        self.min_hits = min_hits
        self.tracks: List[Target] = []
        self._next_id = 1
        self.total_seen = 0        # 累计出现的唯一目标数（计数统计）

    def update(self, dets: List[Det]) -> List[Target]:
        # 1) 建立代价矩阵并贪心匹配
        pairs = []
        for ti, t in enumerate(self.tracks):
            for di, d in enumerate(dets):
                v = iou(t.box, (d.x1, d.y1, d.x2, d.y2))
                if v >= self.iou_thr:
                    pairs.append((v, ti, di))
        pairs.sort(reverse=True, key=lambda p: p[0])

        used_t, used_d, matched = set(), set(), []
        for v, ti, di in pairs:
            if ti in used_t or di in used_d:
                continue
            used_t.add(ti)
            used_d.add(di)
            matched.append((ti, di))

        # 2) 更新命中的
        for ti, di in matched:
            d = dets[di]
            t = self.tracks[ti]
            t.update_box((d.x1, d.y1, d.x2, d.y2))
            t.conf = d.conf
            t.cls = d.cls
            t.kps = d.kps
            t.age += 1
            t.lost = 0

        # 3) 新建未匹配的检测
        for di, d in enumerate(dets):
            if di in used_d:
                continue
            if d.conf < 0.35 and len(self.tracks) > 0:
                continue
            t = Target(tid=self._next_id, box=(d.x1, d.y1, d.x2, d.y2),
                       cls=d.cls, conf=d.conf, kps=d.kps)
            t.update_box(t.box)
            self._next_id += 1
            self.total_seen += 1
            self.tracks.append(t)

        # 4) 未命中的老化/剔除
        alive = []
        for ti, t in enumerate(self.tracks):
            if ti not in used_t:
                t.lost += 1
            if t.lost <= self.max_lost:
                alive.append(t)
        self.tracks = alive
        return [t for t in self.tracks if t.age >= self.min_hits and t.lost == 0]


# ---------------------------------------------------------------- 单目测距

class DistanceEstimator:
    """
    相似三角形测距： D = f_px * H_real / h_px
    f_px 由相机竖直视场角推出： f_px = (img_h/2) / tan(fov_v/2)

    手机默认 fov_v ≈ 49°（等效 26mm），可在设置里按真机标定。
    Android 端会从 CameraCharacteristics 读真实焦距（见 DistanceEstimator.java）。
    """

    def __init__(self, img_h: int, fov_v_deg: float = 49.0, user_scale: float = 1.0):
        self.user_scale = user_scale
        self.set_fov(img_h, fov_v_deg)

    def set_fov(self, img_h: int, fov_v_deg: float):
        self.f_px = (img_h / 2.0) / math.tan(math.radians(fov_v_deg) / 2.0)

    def __call__(self, h_px: float, cls: str = "person") -> float:
        H = REAL_HEIGHT.get(cls, REAL_HEIGHT["default"])
        if h_px <= 1:
            return 0.0
        d = self.f_px * H / h_px * self.user_scale
        return float(min(max(d, 0.3), 200.0))


# ---------------------------------------------------------------- HUD 绘制

GREEN = (120, 255, 140)      # BGR 绿
CYAN = (255, 235, 90)
PANEL = (14, 16, 18)


def _skeleton_from_box(b, kps=None):
    """
    返回骨架关键点（归一化到框内）。
    有 pose 模型时用真关键点；没有时用人体比例先验近似。
    """
    x1, y1, x2, y2 = b
    w, h = x2 - x1, y2 - y1
    cx = (x1 + x2) / 2
    if kps is not None:
        return [(float(k[0]), float(k[1]), float(k[2])) for k in kps]

    # 人体比例先验（相对框高）
    def P(fx, fy):
        return (x1 + fx * w, y1 + fy * h, 1.0)
    pts = {
        "nose":     P(0.50, 0.10),
        "neck":     P(0.50, 0.20),
        "l_sh":     P(0.34, 0.26), "r_sh": P(0.66, 0.26),
        "l_elb":    P(0.26, 0.42), "r_elb": P(0.74, 0.42),
        "l_wri":    P(0.20, 0.56), "r_wri": P(0.80, 0.56),
        "hip":      P(0.50, 0.55),
        "l_hip":    P(0.40, 0.55), "r_hip": P(0.60, 0.55),
        "l_knee":   P(0.40, 0.74), "r_knee": P(0.60, 0.74),
        "l_ank":    P(0.39, 0.95), "r_ank": P(0.61, 0.95),
    }
    order = ["nose", "neck", "l_sh", "r_sh", "neck", "hip",
             "l_sh", "l_elb", "l_wri", "r_sh", "r_elb", "r_wri",
             "hip", "l_hip", "l_knee", "l_ank", "hip", "r_hip", "r_knee", "r_ank"]
    return pts, order


class HudRenderer:
    """对应 Android 的 HudView.onDraw()"""

    def __init__(self, W, H):
        self.W, self.H = W, H
        self.fps = 0.0
        self._t = time.time()
        self._acc = 0.0
        self._n = 0

    def tick_fps(self):
        now = time.time()
        dt = now - self._t
        self._t = now
        if dt > 0:
            self._acc += 1.0 / dt
            self._n += 1
            if self._n >= 10:
                self.fps = self._acc / self._n
                self._acc, self._n = 0.0, 0
        return self.fps

    # --- 方框 + 标签 ---
    def draw_boxes(self, img, targets, show=True):
        if not show:
            return
        for t in targets:
            x1, y1, x2, y2 = [int(v) for v in t.box]
            cv2.rectangle(img, (x1, y1), (x2, y2), GREEN, 2)
            # 四角加粗（外挂味）
            L = min(18, (x2 - x1) // 3, (y2 - y1) // 3)
            for (px, py, dx, dy) in [(x1, y1, 1, 1), (x2, y1, -1, 1),
                                     (x1, y2, 1, -1), (x2, y2, -1, -1)]:
                cv2.line(img, (px, py), (px + dx * L, py), GREEN, 4)
                cv2.line(img, (px, py), (px, py + dy * L), GREEN, 4)

            label = f"#{t.tid} {CLS_ZH.get(t.cls, t.cls)} {t.dist:.1f}m"
            self._tag(img, label, x1, y1)

    def _tag(self, img, text, x, y):
        (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.45, 1)
        y0 = max(0, y - th - 10)
        cv2.rectangle(img, (x, y0), (x + tw + 10, y0 + th + 8), (10, 30, 14), -1)
        cv2.rectangle(img, (x, y0), (x + tw + 10, y0 + th + 8), GREEN, 1)
        cv2.putText(img, text, (x + 5, y0 + th + 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, GREEN, 1, cv2.LINE_AA)

    # --- 骨骼 ---
    def draw_skeleton(self, img, targets, show=True):
        if not show:
            return
        for t in targets:
            if t.cls != "person":
                continue
            res = _skeleton_from_box(t.box, None if t.kps is None else t.kps)
            if isinstance(res, tuple):
                pts, order = res
                for i in range(0, len(order) - 1):
                    a, b = pts[order[i]], pts[order[i + 1]]
                    if a[2] > 0.2 and b[2] > 0.2:
                        cv2.line(img, (int(a[0]), int(a[1])), (int(b[0]), int(b[1])),
                                 CYAN, 2, cv2.LINE_AA)
                for k, p in pts.items():
                    if p[2] > 0.2:
                        cv2.circle(img, (int(p[0]), int(p[1])), 3, (60, 200, 255), -1)

    # --- 射线：准星 -> 目标 ---
    def draw_rays(self, img, targets, show=True):
        if not show:
            return
        cx, cy = self.W // 2, int(self.H * 0.52)
        for t in targets:
            tx, ty = int(t.cx), int(t.cy)
            cv2.line(img, (cx, cy), (tx, ty), (90, 220, 120), 1, cv2.LINE_AA)
            cv2.circle(img, (tx, ty), 4, (90, 220, 120), -1)

    # --- 准星 ---
    def draw_crosshair(self, img):
        cx, cy = self.W // 2, int(self.H * 0.52)
        cv2.line(img, (cx - 22, cy), (cx - 8, cy), GREEN, 2)
        cv2.line(img, (cx + 8, cy), (cx + 22, cy), GREEN, 2)
        cv2.line(img, (cx, cy - 22), (cx, cy - 8), GREEN, 2)
        cv2.line(img, (cx, cy + 8), (cx, cy + 22), GREEN, 2)
        cv2.circle(img, (cx, cy), 3, GREEN, -1)

    # --- 雷达 ---
    def draw_radar(self, img, targets, est: DistanceEstimator, show=True, R=95):
        if not show:
            return
        cx, cy = self.W // 2, int(self.H * 0.52)
        cv2.circle(img, (cx, cy), R, (40, 120, 60), 2)
        for r in (R // 3, 2 * R // 3):
            cv2.circle(img, (cx, cy), r, (35, 90, 50), 1)
        cv2.line(img, (cx - R, cy), (cx + R, cy), (35, 90, 50), 1)
        cv2.line(img, (cx, cy - R), (cx, cy + R), (35, 90, 50), 1)

        cx_img, cy_img = self.W / 2, self.H / 2
        for t in targets:
            # 目标相对画面中心的水平偏移 -> 方位角
            ang = math.atan2(t.cx - cx_img, self.f_px_of(est)) if est else 0.0
            ang = (t.cx - cx_img) / (self.W / 2) * (math.pi / 4)   # ±45° 映射
            d = t.dist if t.dist > 0 else 15.0
            rr = R * min(d / 40.0, 1.0)          # 40m 为雷达满量程
            px = int(cx + rr * math.sin(ang))
            py = int(cy - rr * math.cos(ang))
            cv2.circle(img, (px, py), 5, GREEN, -1)
            cv2.circle(img, (px, py), 8, (60, 160, 90), 1)

    def f_px_of(self, est):
        return getattr(est, "f_px", 1000.0)

    # --- 信息面板 ---
    def draw_panel(self, img, targets, tracker, fps, model_name="YOLOv8n"):
        x0, y0 = 16, 16
        lines = [
            f"天使辅助  EarthOL",
            f"FPS {fps:.0f}   模型 {model_name}",
            f"当前目标 {len(targets)}   累计计数 {tracker.total_seen}",
        ]
        h = 26 * len(lines) + 20
        ov = img.copy()
        cv2.rectangle(ov, (x0, y0), (x0 + 300, y0 + h), PANEL, -1)
        cv2.addWeighted(ov, 0.72, img, 0.28, 0, img)
        cv2.rectangle(img, (x0, y0), (x0 + 300, y0 + h), (60, 200, 100), 1)
        for i, s in enumerate(lines):
            col = GREEN if i == 0 else (200, 220, 210)
            cv2.putText(img, s, (x0 + 12, y0 + 28 + i * 26),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.52, col, 1, cv2.LINE_AA)

        # 右下角目标列表
        if targets:
            ly = self.H - 20
            for t in sorted(targets, key=lambda z: z.dist)[:5]:
                s = f"目标{t.tid} {CLS_ZH.get(t.cls, t.cls)} {t.dist:.1f}m"
                cv2.putText(img, s, (18, ly), cv2.FONT_HERSHEY_SIMPLEX,
                            0.5, (150, 255, 180), 1, cv2.LINE_AA)
                ly -= 22

    def render(self, img, targets, tracker, est, cfg):
        self.draw_boxes(img, targets, cfg.get("box", True))
        self.draw_skeleton(img, targets, cfg.get("skeleton", False))
        self.draw_rays(img, targets, cfg.get("ray", True))
        self.draw_crosshair(img)
        self.draw_radar(img, targets, est, cfg.get("radar", True))
        f = self.tick_fps()
        self.draw_panel(img, targets, tracker, f, cfg.get("model", "YOLOv8n"))
        return img
