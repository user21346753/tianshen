"""
演示脚本：合成一段街景，模拟检测器输出，跑通 tracker -> 测距 -> HUD 渲染 全链路。

注意：沙盒无法下载 YOLO 权重，也没有摄像头，
所以这里用"模拟检测器"（按真实目标的运动规律出框）来验证下游逻辑。
真实设备上把 simulate_detector() 换成 YOLOv8 / OpenCV HOG 即可（接口完全一致）。
"""

import math
import os
import numpy as np
import cv2

from hud_core import (Det, IoUTracker, DistanceEstimator, HudRenderer,
                      CLS_ZH)

W, H = 1280, 720
OUT = os.path.dirname(os.path.abspath(__file__))


# ------------------------------------------------------------ 合成街景

def make_street(frame_i: int) -> np.ndarray:
    """程序化画一条街道：路面、车道线、两侧店铺、招牌"""
    img = np.full((H, W, 3), (150, 158, 165), np.uint8)   # 天空/远景灰
    # 远景建筑
    rng = np.random.RandomState(7)
    x = 0
    while x < W:
        bw = rng.randint(90, 190)
        bh = rng.randint(150, 300)
        col = (int(rng.randint(90, 140)), int(rng.randint(95, 145)), int(rng.randint(100, 150)))
        cv2.rectangle(img, (x, 240 - bh), (x + bw, 430), col, -1)
        # 窗户
        for wy in range(240 - bh + 20, 410, 34):
            for wx in range(x + 12, x + bw - 14, 28):
                c = (int(rng.randint(60, 110)),) * 1
                cv2.rectangle(img, (wx, wy), (wx + 16, wy + 20),
                              (int(rng.randint(70, 130)), int(rng.randint(70, 130)), int(rng.randint(70, 130))), -1)
        x += bw
    # 路面
    cv2.rectangle(img, (0, 430), (W, H), (88, 92, 96), -1)
    # 车道线（透视收敛）
    for k in range(5):
        xx = int(W / 2 + (k - 2) * 150)
        cv2.line(img, (int(W / 2 + (k - 2) * 22), 430), (xx, H), (205, 208, 210), 2)
    # 右侧店铺招牌
    cv2.rectangle(img, (W - 300, 250), (W - 20, 360), (30, 34, 38), -1)
    cv2.rectangle(img, (W - 290, 258), (W - 30, 352), (200, 110, 40), -1)
    cv2.putText(img, "GUIMING PHARMACY", (W - 275, 310), cv2.FONT_HERSHEY_SIMPLEX,
                0.7, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(img, "138-0000-0000", (W - 270, 338), cv2.FONT_HERSHEY_SIMPLEX,
                0.5, (40, 40, 40), 1, cv2.LINE_AA)
    # 左侧招牌
    cv2.rectangle(img, (40, 260), (330, 340), (40, 60, 120), -1)
    cv2.putText(img, "MARKET", (70, 310), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (235, 240, 245), 2, cv2.LINE_AA)
    # 停放的两轮车
    for px, ph in [(60, 120), (150, 110), (W - 120, 130), (W - 220, 115)]:
        draw_motorbike(img, px, 470, ph)
    # 路面轻微噪声
    noise = rng.normal(0, 6, (H - 430, W, 3)).astype(np.int16)
    img[430:] = np.clip(img[430:].astype(np.int16) + noise, 0, 255).astype(np.uint8)
    return img


def draw_motorbike(img, cx, base_y, h):
    """画一辆简易电动车剪影，返回其包围盒"""
    w = int(h * 0.75)
    top = base_y - h
    cv2.rectangle(img, (cx - w // 2, base_y - int(h * 0.35)), (cx + w // 2, base_y - int(h * 0.18)), (60, 62, 66), -1)
    cv2.circle(img, (cx - w // 3, base_y - int(h * 0.12)), int(h * 0.13), (35, 35, 38), -1)
    cv2.circle(img, (cx + w // 3, base_y - int(h * 0.12)), int(h * 0.13), (35, 35, 38), -1)
    cv2.rectangle(img, (cx - w // 4, top + int(h * 0.28)), (cx + w // 4, base_y - int(h * 0.35)), (70, 72, 76), -1)
    return (cx - w // 2, top, cx + w // 2, base_y)


def draw_person(img, cx, base_y, h, color=(70, 75, 82)):
    """画一个人形剪影，返回包围盒"""
    w = int(h * 0.32)
    top = base_y - h
    # 头
    cv2.circle(img, (cx, top + int(h * 0.09)), int(h * 0.075), color, -1)
    # 躯干
    cv2.rectangle(img, (cx - w // 2, top + int(h * 0.17)), (cx + w // 2, top + int(h * 0.55)), color, -1)
    # 腿
    cv2.rectangle(img, (cx - w // 2, top + int(h * 0.55)), (cx - int(w * 0.08), base_y), color, -1)
    cv2.rectangle(img, (cx + int(w * 0.08), top + int(h * 0.55)), (cx + w // 2, base_y), color, -1)
    return (cx - w // 2 - 4, top, cx + w // 2 + 4, base_y)


# ------------------------------------------------------------ 模拟检测器

class SimScene:
    """定义若干真实目标及其运动，供"检测器"采样"""

    def __init__(self):
        # name, cls, 起始 x, 基准 y, 高度(px,近处大), 每帧位移
        self.actors = [
            ("rider1", "motorbike", 520, 560, 210, 9),
            ("walk1", "person", 760, 545, 195, -6),
            ("walk2", "person", 300, 520, 165, 5),
            ("car1", "car", 980, 600, 260, -13),
        ]

    def frame(self, i: int):
        img = make_street(i)
        dets = []
        for (name, cls, x0, by, h, vx) in self.actors:
            x = x0 + vx * i
            if x < -50 or x > W + 50:
                continue
            if cls == "person":
                box = draw_person(img, int(x), by, h)
            elif cls == "motorbike":
                box = draw_motorbike(img, int(x), by, h)
            else:
                box = (int(x) - 150, by - h, int(x) + 150, by)
                cv2.rectangle(img, (box[0], box[1]), (box[2], box[3]), (80, 85, 90), -1)
                cv2.rectangle(img, (box[0] + 20, box[1] + 30), (box[2] - 20, box[1] + int(h * 0.55)), (120, 130, 140), -1)
            # 模拟检测噪声
            j = 3.0
            dets.append(Det(box[0] + np.random.uniform(-j, j), box[1] + np.random.uniform(-j, j),
                            box[2] + np.random.uniform(-j, j), box[3] + np.random.uniform(-j, j),
                            float(np.random.uniform(0.72, 0.96)), cls))
        return img, dets


# ------------------------------------------------------------ 主流程

def run():
    scene = SimScene()
    tracker = IoUTracker()
    est = DistanceEstimator(H, fov_v_deg=49.0)
    hud = HudRenderer(W, H)

    cfg_all = dict(box=True, skeleton=False, ray=True, radar=True, model="YOLOv8n")
    cfg_skel = dict(cfg_all, skeleton=True)

    frames = []
    best = None          # 挑目标最多的一帧做主图
    best_n = -1
    for i in range(9):
        img, dets = scene.frame(i)
        targets = tracker.update(dets)
        for t in targets:
            h_px = t.box[3] - t.box[1]
            t.dist = est(h_px, t.cls)
        out = hud.render(img.copy(), targets, tracker, est, cfg_all)
        frames.append(out)
        if len(targets) >= best_n:
            best_n = len(targets)
            best = (img.copy(), targets, tracker.total_seen)

    # 主图：开全部开关（含骨骼）
    img, targets, total = best
    a = hud.render(img.copy(), targets, tracker, est, cfg_skel)
    cv2.putText(a, f"累计计数 {total}", (16, H - 150), cv2.FONT_HERSHEY_SIMPLEX,
                0.55, (180, 255, 200), 1, cv2.LINE_AA)
    p1 = os.path.join(OUT, "demo_hud.jpg")
    cv2.imwrite(p1, a)

    # 对比图：原始画面 vs HUD
    raw = best[0].copy()
    cv2.putText(raw, "RAW CAMERA", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
    b = np.vstack([raw, a])
    b = cv2.resize(b, (W // 2, H))
    p2 = os.path.join(OUT, "demo_compare.jpg")
    cv2.imwrite(p2, b)

    print("targets in main frame:", len(targets))
    for t in targets:
        print(f"  #{t.tid} {CLS_ZH.get(t.cls,t.cls):4s} conf={t.conf:.2f} dist={t.dist:.1f}m")
    print("累计唯一目标计数:", tracker.total_seen)
    print("saved:", p1, p2)
    return p1, p2


if __name__ == "__main__":
    run()
