package com.angel.hud;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.GradientDrawable;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.MotionEvent;
import android.view.View.MeasureSpec;
import android.view.View.OnTouchListener;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Size;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 天使辅助 · Android 单文件版
 * 摄像头取帧 -> YOLOv8 检测 -> IoU 跟踪 -> 单目测距 -> HUD 绘制
 *
 * 没有透视：只处理摄像头当前帧里本来就看得到的目标。
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AngelHud";
    private static final int AW = 640, AH = 480;

    /**
     * 置信度滑块默认位置。滑块值就是阈值，越高越严格。
     * 之前默认 0.47、又被拖到 0.80，而 YOLOv8n 对很多人只给 0.3~0.6 的分数，
     * 会直接被过滤掉 —— 表现就是「模型在跑但一个都识别不到」。
     * 默认给 0.25 保证出框，要更准再往上调。
     */
    // 0.25：兼顾人物与书本等物品的识别
    private static final int DEFAULT_CONF_PROGRESS = 20;

    private PreviewView previewView;
    private HudView hud;
    private TextView tvStat, tvSens, tvModel, tvDiag;
    private View catPanelHost = null;   // 左侧「识别类别过滤」弹出面板
    private View catChipsHost = null;   // 类别 chip 容器
    private int[] ALL_CLASS_IDS = new int[0];
    private FloatingPanel panelShell;
    private volatile int lastCount = 0;

    /**
     * 帧节流：限制推理频率，避免把 CPU 打满导致界面卡顿。
     * 相机可能是 30fps，但推理一次要上百毫秒，全量处理会让 UI 掉帧。
     * 这里限制最快 ~15fps 处理一次，其余帧直接丢弃。
     */
    private static final long MIN_FRAME_INTERVAL_MS = 66L;
    private volatile long lastInferAt = 0L;
    private ExecutorService exec;
    private androidx.camera.core.Camera camera = null;
    private volatile boolean wideAngle = false;
    private ProcessCameraProvider provider;

    private Detector detector;
    private final Tracker tracker = new Tracker();
    private DistanceEstimator distEst = new DistanceEstimator(AH);

    private int lens = CameraSelector.LENS_FACING_BACK;
    private boolean multiObject = true;

    private final Handler ui = new Handler(Looper.getMainLooper());

    private final ActivityResultLauncher<String> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), ok -> {
                if (ok) startCamera();
                else Toast.makeText(this, "需要相机权限才能运行", Toast.LENGTH_LONG).show();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        exec = Executors.newSingleThreadExecutor();
        detector = new Detector(this);
        readCameraChars();

        buildUi();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            permLauncher.launch(Manifest.permission.CAMERA);
        }

        if (detector.mockMode) {
            Toast.makeText(this, "assets 里没有模型，已进入 MOCK 演示模式", Toast.LENGTH_LONG).show();
        }
    }

    // ---------------------------------------------------------------- UI

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        // 必须和 HUD 的 fit-center 变换一致，否则画面被裁剪而框还在原位，看起来就是歪的
        // 全屏：填满屏幕（边缘会被裁掉一点），HUD 用同样的 cover 变换保证框位对齐
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(previewView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        hud = new HudView(this);
        hud.modelName = detector.modelName();
        hud.mock = detector.mockMode;
        root.addView(hud, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- 面板：折叠=胶囊，展开=竖排窄方块（对齐天神辅助），可上下滑动 ----
        panelShell = new FloatingPanel(this);
        LinearLayout panel = panelShell.body;

        // 绘制设置（竖排）
        panel.addView(section("绘制设置"));
        panel.addView(new ToggleRow(this, "绘制方框", true, v -> hud.showBox = v));
        panel.addView(new ToggleRow(this, "绘制骨骼", true, v -> hud.showSkeleton = v));
        panel.addView(new ToggleRow(this, "绘制雷达", true, v -> hud.showRadar = v));
        panel.addView(new ToggleRow(this, "绘制射线", true, v -> hud.showRay = v));

        // 绘制模式（竖排，互斥）
        panel.addView(section("绘制模式"));
        ToggleRow multi = new ToggleRow(this, "多物体绘制", true, v -> multiObject = v);
        ToggleRow solo = new ToggleRow(this, "单人物绘制", false, v -> multiObject = !v);
        panel.addView(multi);
        panel.addView(solo);
        multi.link(solo);

        // 识别类别过滤（对齐天神辅助）

        // 探测灵敏度（文字 + 滑块，竖排）
        tvSens = new TextView(this);
        tvSens.setTextColor(Color.parseColor("#FFD8EDE2"));
        tvSens.setTextSize(13);
        tvSens.setPadding(0, dp(6), 0, 0);
        panel.addView(tvSens);

        SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        sb.setProgress(DEFAULT_CONF_PROGRESS);
        sb.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        applyConf(DEFAULT_CONF_PROGRESS);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean f) { applyConf(p); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        panel.addView(sb);

        // ---- 识别类别过滤：主面板内只放一个入口，点开后在左侧弹出菜单 ----
        TextView catEntry = new TextView(this);
        catEntry.setText("识别类别过滤（点击设置）");
        catEntry.setTextColor(Color.parseColor("#FF7FBDFF"));
        catEntry.setTextSize(13);
        catEntry.setTypeface(null, android.graphics.Typeface.BOLD);
        catEntry.setPadding(0, dp(8), 0, dp(4));
        catEntry.setOnClickListener(v -> toggleCategoryPanel());
        panel.addView(catEntry);

        // 面板只保留：绘制设置 / 绘制模式 / 探测灵敏度（与天神辅助一致）
        // 屏幕中间上部，不可移动
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        plp.topMargin = dp(4);
        root.addView(panelShell, plp);

        // ---- 右上角：切换镜头 / 广角 / 诊断（竖排，对齐天神辅助）----
        LinearLayout rightBtns = new LinearLayout(this);
        rightBtns.setOrientation(LinearLayout.VERTICAL);
        rightBtns.setPadding(0, dp(4), 0, dp(4));

        TextView btnSwitch = chipButton("切换镜头");
        btnSwitch.setOnClickListener(v -> {
            lens = (lens == CameraSelector.LENS_FACING_BACK)
                    ? CameraSelector.LENS_FACING_FRONT : CameraSelector.LENS_FACING_BACK;
            tracker.reset();
            readCameraChars();
            bind();
            toast(lens == CameraSelector.LENS_FACING_BACK ? "已切至后置镜头" : "已切至前置镜头");
        });

        final TextView btnWide = chipButton("广角");
        btnWide.setOnClickListener(v -> {
            if (camera == null) return;
            try {
                wideAngle = !wideAngle;
                camera.getCameraControl().setZoomRatio(wideAngle ? 0.5f : 1.0f);
                btnWide.setText(wideAngle ? "标准" : "广角");
            } catch (Exception e) {
                wideAngle = false;
                toast("此设备不支持变焦");
            }
        });

        TextView btnDiag = chipButton("诊断");
        btnDiag.setOnClickListener(v -> {
            if (tvDiag == null) return;
            boolean show = tvDiag.getVisibility() != View.VISIBLE;
            tvDiag.setVisibility(show ? View.VISIBLE : View.GONE);
            if (show) tvDiag.setText("诊断 " + detector.diagLine());
        });

        rightBtns.addView(btnSwitch);
        rightBtns.addView(btnWide);
        rightBtns.addView(btnDiag);

        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        rlp.topMargin = dp(8);
        rlp.rightMargin = dp(4);
        root.addView(rightBtns, rlp);

        // ---- 左上角「隐藏」：收起/展开主面板 ----
        TextView btnHide = chipButton("隐藏");
        btnHide.setOnClickListener(v -> {
            boolean hide = panelShell.getVisibility() == View.VISIBLE;
            panelShell.setVisibility(hide ? View.GONE : View.VISIBLE);
            if (catPanelHost != null) catPanelHost.setVisibility(View.GONE);
            btnHide.setText(hide ? "显示" : "隐藏");
        });
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.START);
        hlp.topMargin = dp(64);     // 正好在左上角铭牌下方
        hlp.leftMargin = dp(6);     // 与铭牌左边对齐
        root.addView(btnHide, hlp);

        // ---- 诊断行（默认隐藏，点「诊断」显示）----
        tvDiag = new TextView(this);
        tvDiag.setTextSize(12);
        tvDiag.setTextColor(Color.parseColor("#FF9FE8BC"));
        tvDiag.setPadding(dp(10), dp(4), dp(10), dp(4));
        tvDiag.setBackground(panelBg());
        tvDiag.setSingleLine(true);
        tvDiag.setVisibility(View.GONE);
        tvDiag.setText("诊断 -");
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        dlp.bottomMargin = dp(52);
        dlp.leftMargin = dp(12);
        root.addView(tvDiag, dlp);

        // ---- 左侧「识别类别过滤」弹出面板（默认隐藏）----
        catPanelHost = buildCategoryPanel();
        catPanelHost.setVisibility(View.GONE);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                dp(150), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_VERTICAL | Gravity.START);
        clp.leftMargin = dp(8);
        root.addView(catPanelHost, clp);




        setContentView(root);
        ui.postDelayed(statLoop, 500);
    }

    /**
     * 顶部固定面板（不可移动）：
     *   - 折叠后是一个「胶囊」：圆角拉满、只显示 ● 天使辅助
     *   - 点胶囊任意位置都能展开
     */
    private class FloatingPanel extends LinearLayout {

        final LinearLayout body = new LinearLayout(getContext());
        private final LinearLayout header = new LinearLayout(getContext());
        private final TextView title = new TextView(getContext());
        private final TextView count = new TextView(getContext());
        private final View dot = new View(getContext());
        private boolean collapsed = false;
        private final int EXPAND_W = dp(215);

        FloatingPanel(android.content.Context ctx) {
            super(ctx);
            setOrientation(VERTICAL);
            setBackground(capsuleBg(true));
            setPadding(dp(12), dp(5), dp(12), dp(5));

            // ---- 折叠后显示的就是这个胶囊：● 天使辅助  人数 ----
            header.setOrientation(HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);

            dot.setLayoutParams(new LinearLayout.LayoutParams(dp(8), dp(8)));
            ((LinearLayout.LayoutParams) dot.getLayoutParams()).setMargins(0, 0, dp(7), 0);
            dot.setBackground(dotBg());
            header.addView(dot);

            title.setText("天使辅助");
            title.setTextColor(Color.parseColor("#FF4CE07A"));
            title.setTextSize(14);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            header.addView(title);

            count.setText("0");
            count.setTextColor(Color.parseColor("#FFE8FFF2"));
            count.setTextSize(13);
            count.setTypeface(null, android.graphics.Typeface.BOLD);
            count.setPadding(dp(8), 0, 0, 0);
            header.addView(count);

            // 点胶囊任意处 -> 展开/折叠
            header.setOnClickListener(v -> setCollapsed(!collapsed, true));

            addView(header);

            body.setOrientation(LinearLayout.VERTICAL);
            body.setPadding(0, dp(8), 0, 0);
            body.setVisibility(GONE);

            // 内容超出时可上下滑动，面板高度封顶，不会顶到屏幕底部
            android.widget.ScrollView sv = new android.widget.ScrollView(ctx);
            sv.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(body);
            addView(sv);
            // 必须显式调用一次，否则宽度还是外层的 MATCH_PARENT，胶囊会被拉成长条
            setCollapsed(true, false);
        }

        /** 胶囊上的人数 */
        void setCount(int n) {
            if (count != null) count.setText(String.valueOf(n));
        }

        private int capsuleWidth() {
            header.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),
                           MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
            return header.getMeasuredWidth() + dp(24);
        }

        /**
         * 展开/折叠。带宽度动画，做出「灵动岛」那种变长效果。
         */
        private void setCollapsed(boolean v, boolean animate) {
            collapsed = v;
            body.setVisibility(v ? GONE : VISIBLE);
            setBackground(capsuleBg(v));
            setPadding(dp(12), v ? dp(5) : dp(9), dp(12), v ? dp(5) : dp(10));

            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
            if (lp == null) return;

            int targetW = v ? capsuleWidth() : EXPAND_W;
            // 展开时高度封顶（屏幕 62%），内容超出即可上下滑动
            lp.height = v ? ViewGroup.LayoutParams.WRAP_CONTENT
                    : (int) (getResources().getDisplayMetrics().heightPixels * 0.62f);

            if (!animate) {
                lp.width = targetW;
                setLayoutParams(lp);
                return;
            }

            int startW = (getWidth() > 0) ? getWidth() : targetW;
            ValueAnimator va = ValueAnimator.ofInt(startW, targetW);
            va.setDuration(260);
            va.setInterpolator(new DecelerateInterpolator());
            va.addUpdateListener(a -> {
                lp.width = (Integer) a.getAnimatedValue();
                requestLayout();
            });
            va.start();
        }

        /** 折叠=胶囊（圆角拉满），展开=圆角矩形 */
        private GradientDrawable capsuleBg(boolean capsule) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xE8000000);
            g.setCornerRadius(capsule ? dp(24) : dp(10));
            g.setStroke(1, 0x994CE07A);
            return g;
        }

        private GradientDrawable dotBg() {
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFF4CE07A);
            g.setCornerRadius(dp(5));
            return g;
        }
    }

    private void refreshModelLabel() {
        // HUD 上的模型标识始终同步（面板里已不再放这行文字）
        if (hud != null) {
            hud.mock = detector.mockMode;
            hud.modelName = detector.modelName();
        }
        if (tvModel == null) return;
        if (detector.mockMode) {
            tvModel.setTextColor(Color.parseColor("#FFFF5555"));
            tvModel.setText("MOCK 演示模式：未加载模型，画面中的框不是真实识别");
        } else {
            tvModel.setTextColor(Color.parseColor("#FF3DA5FF"));
            tvModel.setText("模型 " + detector.modelName() + "：真实识别");
        }
    }

    private final Runnable statLoop = new Runnable() {
        @Override public void run() {
            refreshModelLabel();

            // 胶囊上的人数
            if (panelShell != null) panelShell.setCount(lastCount);

            // 诊断行可见时实时刷新
            if (tvDiag != null && tvDiag.getVisibility() == View.VISIBLE) {
                tvDiag.setText("诊断 " + detector.diagLine());
            }

            ui.postDelayed(this, 500);
        }
    };

    /** 右上角/左上角那种小胶囊按钮 */
    private TextView chipButton(String text) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(Color.parseColor("#FFE8FFF2"));
        b.setTextSize(13);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setBackground(buttonBg());
        // 统一宽度：否则每个按钮按文字长度各自 WRAP_CONTENT，右边对不齐
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                dp(78), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(6));
        b.setLayoutParams(lp);
        return b;
    }

    private void toast(String msg) {
        try { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { }
    }

    /** 点主面板里的入口 -> 左侧弹出/收起类别菜单 */
    private void toggleCategoryPanel() {
        if (catPanelHost == null) return;
        boolean show = catPanelHost.getVisibility() != View.VISIBLE;
        catPanelHost.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            AlphaAnimation a = new AlphaAnimation(0f, 1f);
            a.setDuration(180);
            catPanelHost.startAnimation(a);
        }
    }

    /** 左侧类别面板：标题 + 全部开启/关闭 + 自适应流式类别 + 关闭按钮 */
    private View buildCategoryPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(panelBg());
        box.setPadding(dp(10), dp(8), dp(10), dp(8));

        // 标题行：左边标题，右边一个叉号关闭
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("识别类别过滤");
        title.setTextColor(Color.parseColor("#FF4CE07A"));
        title.setTextSize(13);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        titleRow.addView(title);

        TextView closeX = new TextView(this);
        closeX.setText("✕");
        closeX.setTextColor(Color.parseColor("#FFE8FFF2"));
        closeX.setTextSize(16);
        closeX.setTypeface(null, android.graphics.Typeface.BOLD);
        closeX.setPadding(dp(8), dp(2), dp(2), dp(2));
        closeX.setOnClickListener(v -> {
            if (catPanelHost != null) catPanelHost.setVisibility(View.GONE);
        });
        titleRow.addView(closeX);

        box.addView(titleRow);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        TextView bAll = chipButton("全部开启");
        TextView bNone = chipButton("全部关闭");
        bAll.setOnClickListener(v -> setAllClasses(true));
        bNone.setOnClickListener(v -> setAllClasses(false));
        bar.addView(bAll);
        bar.addView(bNone);
        box.addView(bar);

        catChipsHost = categoryFilter();
        box.addView(catChipsHost);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(box);
        return sv;
    }

    /** 全部开启/关闭，并同步所有 chip 的显示状态 */
    private void setAllClasses(boolean on) {
        enabledCls.clear();
        if (on) for (int id : ALL_CLASS_IDS) enabledCls.add(id);
        applyClassFilter();
        refreshCategoryChips();
    }

    private void refreshCategoryChips() {
        if (catChipsHost instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) catChipsHost;
            for (int i = 0; i < g.getChildCount(); i++) {
                View ch = g.getChildAt(i);
                Object tag = ch.getTag();
                if (tag instanceof Integer) {
                    boolean on = enabledCls.contains((Integer) tag);
                    ch.setBackground(chipBg(on));
                    if (ch instanceof TextView) {
                        ((TextView) ch).setTextColor(on ? Color.parseColor("#FFE8F4FF")
                                : Color.parseColor("#FF9AA6B2"));
                    }
                }
            }
        }
    }

    private GradientDrawable panelBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xE8000000);
        g.setCornerRadius(dp(8));
        g.setStroke(1, 0x804CE07A);
        return g;
    }

    private GradientDrawable buttonBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xEE14324A);
        g.setCornerRadius(dp(6));
        g.setStroke(1, 0xFF3DA5FF);
        return g;
    }

    private View divider() {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1));
        v.setBackgroundColor(0x444CE07A);
        ((LinearLayout.LayoutParams) v.getLayoutParams()).setMargins(0, dp(6), 0, dp(6));
        return v;
    }

    private TextView section(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.parseColor("#FF7FCFA0"));
        t.setTextSize(12);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    /** 蓝色开关行：小方块指示灯 + 文字，点击切换 */
    private class ToggleRow extends LinearLayout {
        private boolean on;
        private final View indicator;
        private final TextView label;
        private final OnToggle cb;
        private ToggleRow opposite;

        ToggleRow(Context ctx, String text, boolean init, OnToggle cb) {
            super(ctx);
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(0, dp(5), 0, dp(5));
            on = init;
            this.cb = cb;

            indicator = new View(ctx);
            indicator.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
            ((LinearLayout.LayoutParams) indicator.getLayoutParams()).setMargins(0, 0, dp(10), 0);
            addView(indicator);

            label = new TextView(ctx);
            label.setText(text);
            label.setTextSize(13);
            addView(label);

            paint();
            setOnClickListener(v -> toggle());
            cb.apply(on);
        }

        /** 切换自身；若与另一项互斥，则把对方置为相反状态 */
        private void toggle() {
            boolean next = !on;
            setOn(next);
            cb.apply(next);
            if (opposite != null) {
                opposite.setOn(!next);
                opposite.cb.apply(!next);
            }
        }

        void link(ToggleRow other) { this.opposite = other; other.opposite = this; }

        void setOn(boolean v) {
            on = v;
            paint();
        }

        private void paint() {
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(3));
            if (on) {
                g.setColor(0xFF2E8BFF);
                g.setStroke(1, 0xFF7FBDFF);
                label.setTextColor(Color.parseColor("#FFE8F4FF"));
            } else {
                g.setColor(0xFF1A2028);
                g.setStroke(1, 0xFF556070);
                label.setTextColor(Color.parseColor("#FF9AA6B2"));
            }
            indicator.setBackground(g);
        }
    }

    private interface OnToggle { void apply(boolean v); }

    /**
     * 自动换行的流式布局。
     * 之前按「每行固定 3 个」排，面板一窄按钮就挤成一团互相遮挡看不清。
     * 这个按实际可用宽度自动折行，类别再多也不会挤。
     */
    private static class FlowLayout extends ViewGroup {
        private final int hSpace, vSpace;

        FlowLayout(Context c, int hSpace, int vSpace) {
            super(c);
            this.hSpace = hSpace;
            this.vSpace = vSpace;
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int width = Math.max(1, MeasureSpec.getSize(wSpec));
            int x = getPaddingLeft();
            int y = getPaddingTop();
            int rowH = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View ch = getChildAt(i);
                if (ch.getVisibility() == GONE) continue;
                measureChild(ch, wSpec, hSpec);
                int cw = ch.getMeasuredWidth();
                int chh = ch.getMeasuredHeight();
                if (x + cw > width - getPaddingRight() && x > getPaddingLeft()) {
                    x = getPaddingLeft();
                    y += rowH + vSpace;
                    rowH = 0;
                }
                x += cw + hSpace;
                rowH = Math.max(rowH, chh);
            }
            setMeasuredDimension(
                    resolveSize(width, wSpec),
                    resolveSize(y + rowH + getPaddingBottom(), hSpec));
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int width = Math.max(1, r - l);
            int x = getPaddingLeft();
            int y = getPaddingTop();
            int rowH = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View ch = getChildAt(i);
                if (ch.getVisibility() == GONE) continue;
                int cw = ch.getMeasuredWidth();
                int chh = ch.getMeasuredHeight();
                if (x + cw > width - getPaddingRight() && x > getPaddingLeft()) {
                    x = getPaddingLeft();
                    y += rowH + vSpace;
                    rowH = 0;
                }
                ch.layout(x, y, x + cw, y + chh);
                x += cw + hSpace;
                rowH = Math.max(rowH, chh);
            }
        }
    }

    /** 识别类别过滤：蓝色=启用，灰色=不显示。默认全部开启，勾选会被记住 */
    private final java.util.Set<Integer> enabledCls = new java.util.HashSet<>();

    private View categoryFilter() {
        // COCO 类别 id：人物 + 常见动物 + 车辆，默认全部开启
        // COCO 常用类别：人物 + 动物 + 车辆 + 日常物品（书本等）
        Object[][] items = {
                {0, "人"},
                {15, "猫"}, {16, "狗"}, {14, "鸟"}, {17, "马"}, {18, "羊"},
                {19, "牛"}, {20, "大象"}, {21, "熊"}, {22, "斑马"}, {23, "长颈鹿"},
                {2, "汽车"}, {7, "卡车"}, {5, "公交车"}, {1, "自行车"},
                {3, "摩托车"}, {8, "船"}, {4, "飞机"}, {6, "火车"},
                // 常用物品
                {73, "书"}, {67, "手机"}, {63, "笔记本"}, {62, "电视"},
                {41, "杯子"}, {39, "瓶子"}, {40, "酒杯"}, {45, "碗"},
                {24, "背包"}, {26, "手提包"}, {28, "行李箱"}, {25, "雨伞"},
                {56, "椅子"}, {57, "沙发"}, {59, "床"}, {60, "餐桌"},
                {64, "鼠标"}, {66, "键盘"}, {65, "遥控器"}, {74, "时钟"},
                {72, "冰箱"}, {68, "微波炉"}, {58, "盆栽"}
        };
        ALL_CLASS_IDS = new int[items.length];
        for (int i = 0; i < items.length; i++) {
            ALL_CLASS_IDS[i] = (Integer) items[i][0];
        }
        // 每次启动都重置为「只开启人」，其余类别需要手动点开。
        // 全开会让杯子、椅子等杂物铺满画面，干扰识别。
        enabledCls.clear();
        enabledCls.add(0);


        // 自适应换行：按实际宽度自动折行，不会再挤成一团
        FlowLayout wrap = new FlowLayout(this, dp(6), dp(6));
        wrap.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        for (int i = 0; i < items.length; i++) {
            final int clsId = (Integer) items[i][0];
            final String name = (String) items[i][1];

            TextView b = new TextView(this);
            b.setText(name);
            b.setTextSize(12);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(8), dp(4), dp(8), dp(4));
            b.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            b.setTag(clsId);
            b.setBackground(chipBg(enabledCls.contains(clsId)));

            b.setOnClickListener(v -> {
                if (enabledCls.contains(clsId)) enabledCls.remove(clsId);
                else enabledCls.add(clsId);
                boolean on = enabledCls.contains(clsId);
                b.setBackground(chipBg(on));
                b.setTextColor(on ? Color.parseColor("#FFE8F4FF")
                                  : Color.parseColor("#FF9AA6B2"));
                applyClassFilter();
            });
            b.setTextColor(enabledCls.contains(clsId)
                    ? Color.parseColor("#FFE8F4FF") : Color.parseColor("#FF9AA6B2"));
            wrap.addView(b);
        }
        applyClassFilter();
        return wrap;
    }

    private GradientDrawable chipBg(boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? 0xFF2E8BFF : 0xFF1A2028);
        g.setCornerRadius(dp(4));
        g.setStroke(1, on ? 0xFF7FBDFF : 0xFF556070);
        return g;
    }

    private void applyClassFilter() {
        if (detector != null) detector.enabledCls = enabledCls;
    }


    private void applyConf(int progress) {
        // 滑块就是置信度阈值：0.10 ~ 0.85，值越小框越多（也越容易误检）
        float conf = 0.10f + (progress / 100f) * 0.75f;
        detector.confThr = conf;
        tvSens.setText("探测灵敏度 " + String.format("%.2f", conf) + "（越小框越多）");
    }

    // ---------------------------------------------------------------- 相机

    private void readCameraChars() {
        try {
            Object cm = getSystemService("camera");
            String id = (lens == CameraSelector.LENS_FACING_BACK) ? "0" : "1";
            java.lang.reflect.Method m = cm.getClass()
                    .getMethod("getCameraCharacteristics", String.class);
            Object cc = m.invoke(cm, id);
            distEst.setFromCamera(cc, AH);
        } catch (Throwable e) {
            Log.w(TAG, "相机参数读取失败，使用默认 FOV", e);
        }
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(this);
        f.addListener(() -> {
            try {
                provider = f.get();
                bind();
            } catch (Exception e) {
                Log.e(TAG, "相机启动失败", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bind() {
        if (provider == null) return;
        provider.unbindAll();

        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        // 模型输入只有 320，取 640x480 足够，分辨率越高只是白白增加取帧开销
        ImageAnalysis analysis = new ImageAnalysis.Builder()
                .setTargetResolution(new Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build();
        analysis.setAnalyzer(exec, this::analyze);

        try {
            camera = provider.bindToLifecycle(this,
                    new CameraSelector.Builder().requireLensFacing(lens).build(),
                    preview, analysis);
        } catch (Exception e) {
            Log.e(TAG, "绑定相机失败", e);
        }
    }

    private void analyze(ImageProxy img) {
        // 节流：距上次推理太近就丢帧，保证 UI 流畅
        long now = System.currentTimeMillis();
        if (now - lastInferAt < MIN_FRAME_INTERVAL_MS) {
            img.close();
            return;
        }
        lastInferAt = now;
        try {
            Bitmap bmp = img.toBitmap();
            int rot = img.getImageInfo().getRotationDegrees();
            if (rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                Bitmap r = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                bmp.recycle();
                bmp = r;
            }
            // 前置摄像头：预览是镜像显示的，但 ImageAnalysis 给的是非镜像帧。
            // 不翻转的话检测框会左右颠倒（框在人身上却显示在另一边）。
            if (lens == CameraSelector.LENS_FACING_FRONT) {
                Matrix fm = new Matrix();
                fm.postScale(-1f, 1f);
                Bitmap f = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), fm, true);
                bmp.recycle();
                bmp = f;
            }
            final int w = bmp.getWidth(), h = bmp.getHeight();

            List<Det> dets = detector.detect(bmp, multiObject);
            List<Target> targets = tracker.update(dets);
            for (Target t : targets) {
                float raw = distEst.estimate(t.h(), t.clsId);
                // 距离 EMA 平滑，避免数值疯狂跳动
                t.distM = (t.age <= 2) ? raw : t.distM + (raw - t.distM) * 0.35f;
            }
            final int total = tracker.totalSeen;
            final int cur = targets.size();
            lastCount = cur;


            ui.post(() -> hud.setTargets(targets, w, h, total));
            if (bmp != null && !bmp.isRecycled()) bmp.recycle();
        } catch (Exception e) {
            Log.e(TAG, "分析帧失败", e);
        } finally {
            img.close();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacks(statLoop);
        exec.shutdown();
        detector.close();
        if (provider != null) provider.unbindAll();
    }

    // ================================================================ 数据结构

    static class Det {
        float x1, y1, x2, y2, conf;
        int clsId;
        String label = "目标";
        float[] kps = null;

        Det(float x1, float y1, float x2, float y2, float conf, int clsId, String label) {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
            this.conf = conf; this.clsId = clsId; this.label = label;
        }
        float w() { return Math.max(0f, x2 - x1); }
        float h() { return Math.max(0f, y2 - y1); }
        float cx() { return (x1 + x2) * 0.5f; }
        float cy() { return (y1 + y2) * 0.5f; }
    }

    static class Target {
        int id;
        float x1, y1, x2, y2, conf, distM;
        int clsId;
        String label = "目标";
        int age, lost;
        float[] kps;

        float cx() { return (x1 + x2) * 0.5f; }
        float cy() { return (y1 + y2) * 0.5f; }
        float h() { return Math.max(1f, y2 - y1); }
        float w() { return Math.max(1f, x2 - x1); }

        void update(Det d) {
            if (age == 0) {
                // 首次出现，直接采用
                x1 = d.x1; y1 = d.y1; x2 = d.x2; y2 = d.y2;
            } else {
                // EMA 平滑：抑制逐帧抖动，又不至于跟不上运动
                float a = 0.55f;
                x1 += (d.x1 - x1) * a;
                y1 += (d.y1 - y1) * a;
                x2 += (d.x2 - x2) * a;
                y2 += (d.y2 - y2) * a;
            }
            conf = d.conf; clsId = d.clsId; label = d.label; kps = d.kps;
            age++; lost = 0;
        }
    }

    // ================================================================ 跟踪器

    static class Tracker {
        private final float iouThr = 0.30f;
        // maxLost 调大 + persist：短暂丢失也继续画框，避免"闪一下就没"
        private final int maxLost = 20, minHits = 1, persist = 3;
        private final List<Target> tracks = new ArrayList<>();
        private int nextId = 1;
        volatile int totalSeen = 0;

        List<Target> update(List<Det> dets) {
            List<float[]> pairs = new ArrayList<>();
            for (int ti = 0; ti < tracks.size(); ti++)
                for (int di = 0; di < dets.size(); di++) {
                    float v = iou(tracks.get(ti), dets.get(di));
                    if (v >= iouThr) pairs.add(new float[]{v, ti, di});
                }
            pairs.sort((a, b) -> Float.compare(b[0], a[0]));

            boolean[] ut = new boolean[tracks.size()], ud = new boolean[dets.size()];
            for (float[] p : pairs) {
                int ti = (int) p[1], di = (int) p[2];
                if (ut[ti] || ud[di]) continue;
                ut[ti] = true; ud[di] = true;
                tracks.get(ti).update(dets.get(di));
            }
            for (int di = 0; di < dets.size(); di++) {
                if (ud[di]) continue;
                Det d = dets.get(di);
                if (d.conf < 0.25f && !tracks.isEmpty()) continue;
                // 与已有 track 高度重叠就不新建，避免同一个人出现两个框
                boolean dup = false;
                for (Target ex : tracks) {
                    if (iou(ex, d) > 0.5f) { dup = true; break; }
                }
                if (dup) continue;
                Target t = new Target();
                t.id = nextId++;
                t.update(d);
                t.age = 1;
                totalSeen++;
                tracks.add(t);
            }
            List<Target> alive = new ArrayList<>();
            for (int ti = 0; ti < tracks.size(); ti++) {
                Target t = tracks.get(ti);
                if (!ut[ti]) t.lost++;
                if (t.lost <= maxLost) alive.add(t);
            }
            tracks.clear();
            tracks.addAll(alive);

            List<Target> out = new ArrayList<>();
            for (Target t : tracks)
                // 允许 persist 帧的短暂丢失，框不会一闪就消失
                if (t.age >= minHits && t.lost <= persist) out.add(t);
            out.sort((a, b) -> Float.compare(a.distM, b.distM));
            return out;
        }

        private static float iou(Target t, Det d) {
            float ix1 = Math.max(t.x1, d.x1), iy1 = Math.max(t.y1, d.y1);
            float ix2 = Math.min(t.x2, d.x2), iy2 = Math.min(t.y2, d.y2);
            float iw = Math.max(0f, ix2 - ix1), ih = Math.max(0f, iy2 - iy1);
            float inter = iw * ih;
            if (inter <= 0) return 0f;
            float sa = Math.max(0f, t.x2 - t.x1) * Math.max(0f, t.y2 - t.y1);
            float sb = Math.max(0f, d.x2 - d.x1) * Math.max(0f, d.y2 - d.y1);
            return inter / (sa + sb - inter + 1e-6f);
        }

        void reset() {
            tracks.clear(); nextId = 1; totalSeen = 0;
        }
    }

    // ================================================================ 测距

    static class DistanceEstimator {
        private float fPx;
        private int imgH;
        float userScale = 1.0f;

        private static final float[] REAL_H = new float[81];
        static {
            for (int i = 0; i < REAL_H.length; i++) REAL_H[i] = 1.70f;
            REAL_H[0] = 1.70f;   // person
            REAL_H[1] = 1.20f;   // bicycle
            REAL_H[2] = 1.15f;   // car
            REAL_H[3] = 1.30f;   // motorbike
            REAL_H[5] = 3.20f;   // bus
            REAL_H[7] = 3.00f;   // truck
        }

        DistanceEstimator(int imgH) {
            this.imgH = imgH;
            setFov(49f);
        }

        void setFov(float fovV) {
            fPx = (float) ((imgH / 2.0) / Math.tan(Math.toRadians(fovV) / 2.0));
        }

        void setFromCamera(Object cc, int h) {
            imgH = h;
            try {
                Class<?> k = Class.forName("android.hardware.camera2.CameraCharacteristics");
                java.lang.reflect.Method get = cc.getClass().getMethod("get",
                        Class.forName("android.hardware.camera2.CameraCharacteristics$Key"));
                float fl = ((Float) get.invoke(cc, k.getField("LENS_FOCAL_LENGTH").get(null)));
                float phH = ((android.util.SizeF) get.invoke(cc,
                        k.getField("SENSOR_INFO_PHYSICAL_SIZE").get(null))).getHeight();
                if (fl > 0 && phH > 0) {
                    fPx = fl / phH * h;
                    return;
                }
            } catch (Throwable ignored) { }
            setFov(49f);
        }

        float estimate(float hPx, int clsId) {
            if (hPx <= 1f) return 0f;
            float H = (clsId >= 0 && clsId < REAL_H.length) ? REAL_H[clsId] : 1.70f;
            float d = fPx * H / hPx * userScale;
            return Math.min(Math.max(d, 0.3f), 200f);
        }
    }
}
