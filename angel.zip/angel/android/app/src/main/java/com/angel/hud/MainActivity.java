package com.angel.hud;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View.OnTouchListener;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Size;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 天使辅助 · Android 单文件版
 * 摄像头取帧 -> YOLOv8 检测 -> IoU 跟踪 -> 单目测距 -> HUD 绘制
 *
 * 没有透视：只处理摄像头当前帧里本来就看得到的目标。
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AngelHud";
    private static final int AW = 640, AH = 480;

    private PreviewView previewView;
    private HudView hud;
    private TextView tvStat, tvSens, tvModel, tvDiag;
    private FloatingPanel panelShell;
    private volatile int lastCount = 0;
    private ExecutorService exec;
    private ProcessCameraProvider provider;

    private Detector detector;
    private final Tracker tracker = new Tracker();
    private DistanceEstimator distEst = new DistanceEstimator(AH);

    private int lens = CameraSelector.LENS_FACING_BACK;
    private boolean multiObject = true;

    private final Handler ui = new Handler(Looper.getMainLooper());

    private final ActivityResultLauncher<String> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), ok -> {
                if (ok) startCamera();
                else Toast.makeText(this, "需要相机权限才能运行", Toast.LENGTH_LONG).show();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        exec = Executors.newSingleThreadExecutor();
        detector = new Detector(this);
        readCameraChars();

        buildUi();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            permLauncher.launch(Manifest.permission.CAMERA);
        }

        if (detector.mockMode) {
            Toast.makeText(this, "assets 里没有模型，已进入 MOCK 演示模式", Toast.LENGTH_LONG).show();
        }
    }

    // ---------------------------------------------------------------- UI

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        root.addView(previewView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        hud = new HudView(this);
        hud.modelName = detector.modelName();
        hud.mock = detector.mockMode;
        root.addView(hud, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- 顶部固定横向面板：不可移动、可折叠、三档缩放 ----
        panelShell = new FloatingPanel(this);
        LinearLayout panel = panelShell.body;

        // 第一行：绘制设置（横排）
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER_VERTICAL);
        row1.addView(section("绘制设置"));
        row1.addView(new ToggleRow(this, "绘制方框", true, v -> hud.showBox = v));
        row1.addView(new ToggleRow(this, "绘制骨骼", true, v -> hud.showSkeleton = v));
        row1.addView(new ToggleRow(this, "绘制雷达", true, v -> hud.showRadar = v));
        row1.addView(new ToggleRow(this, "绘制射线", true, v -> hud.showRay = v));
        panel.addView(row1);

        // 第二行：绘制模式（横排）+ 右侧切换镜头
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER_VERTICAL);
        row2.addView(section("绘制模式"));

        ToggleRow multi = new ToggleRow(this, "多物体绘制", true, v -> multiObject = v);
        ToggleRow solo = new ToggleRow(this, "单人物绘制", false, v -> multiObject = !v);
        row2.addView(multi);
        row2.addView(solo);
        multi.link(solo);

        View spacer = new View(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(0, 0, 1f));
        row2.addView(spacer);

        TextView btnSwitch = new TextView(this);
        btnSwitch.setText("切换镜头");
        btnSwitch.setTextColor(Color.parseColor("#FFE8FFF2"));
        btnSwitch.setTextSize(13);
        btnSwitch.setTypeface(null, android.graphics.Typeface.BOLD);
        btnSwitch.setPadding(dp(12), dp(6), dp(12), dp(6));
        btnSwitch.setBackground(buttonBg());
        btnSwitch.setOnClickListener(v -> {
            lens = (lens == CameraSelector.LENS_FACING_BACK)
                    ? CameraSelector.LENS_FACING_FRONT : CameraSelector.LENS_FACING_BACK;
            tracker.reset();
            readCameraChars();
            bind();
        });
        row2.addView(btnSwitch);
        panel.addView(row2);

        // 第三行：探测灵敏度（横排）
        tvSens = new TextView(this);
        tvSens.setTextColor(Color.parseColor("#FFD8EDE2"));
        tvSens.setTextSize(13);
        tvSens.setPadding(0, dp(6), dp(10), 0);

        SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        sb.setProgress(45);
        sb.setLayoutParams(new LinearLayout.LayoutParams(dp(160), ViewGroup.LayoutParams.WRAP_CONTENT));
        applyConf(45);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean f) { applyConf(p); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        row3.setGravity(Gravity.CENTER_VERTICAL);
        row3.addView(tvSens);
        row3.addView(sb);
        panel.addView(row3);

        // 底部状态：字号加大 + 可左右滑动查看
        tvStat = new TextView(this);
        tvStat.setTextColor(Color.parseColor("#FFA8FFC8"));
        tvStat.setTextSize(14);
        tvStat.setTypeface(null, android.graphics.Typeface.BOLD);
        tvStat.setPadding(0, dp(8), dp(18), dp(4));
        tvStat.setSingleLine(true);

        tvModel = new TextView(this);
        tvModel.setTextSize(14);
        tvModel.setTypeface(null, android.graphics.Typeface.BOLD);
        tvModel.setPadding(0, dp(8), dp(10), dp(4));
        tvModel.setSingleLine(true);
        refreshModelLabel();

        LinearLayout statusBox = new LinearLayout(this);
        statusBox.setOrientation(LinearLayout.HORIZONTAL);
        statusBox.setGravity(Gravity.CENTER_VERTICAL);
        tvDiag = new TextView(this);
        tvDiag.setTextSize(13);
        tvDiag.setTextColor(Color.parseColor("#FF9FE8BC"));
        tvDiag.setPadding(dp(18), dp(4), dp(18), dp(4));
        tvDiag.setSingleLine(true);

        statusBox.addView(tvStat);
        statusBox.addView(tvModel);
        statusBox.addView(tvDiag);

        HorizontalScrollView statusScroll = new HorizontalScrollView(this);
        statusScroll.setHorizontalScrollBarEnabled(false);
        statusScroll.addView(statusBox);
        panel.addView(statusScroll);

        // 固定在顶部，横向铺满，不可移动
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        plp.leftMargin = dp(10);
        plp.rightMargin = dp(10);
        plp.topMargin = dp(10);
        root.addView(panelShell, plp);

        setContentView(root);
        ui.postDelayed(statLoop, 500);
    }

    /**
     * 顶部固定面板（不可移动）：
     *   - 折叠后是一个「胶囊」：圆角拉满、只显示 ● 天使辅助
     *   - 点胶囊任意位置都能展开
     */
    private class FloatingPanel extends LinearLayout {

        final LinearLayout body = new LinearLayout(getContext());
        private final LinearLayout header = new LinearLayout(getContext());
        private final TextView title = new TextView(getContext());
        private final View dot = new View(getContext());
        private boolean collapsed = false;

        FloatingPanel(android.content.Context ctx) {
            super(ctx);
            setOrientation(VERTICAL);
            setBackground(capsuleBg(true));
            setPadding(dp(12), dp(5), dp(12), dp(5));

            // ---- 折叠后显示的就是这个胶囊 ----
            header.setOrientation(HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);

            dot.setLayoutParams(new LinearLayout.LayoutParams(dp(8), dp(8)));
            ((LinearLayout.LayoutParams) dot.getLayoutParams()).setMargins(0, 0, dp(7), 0);
            dot.setBackground(dotBg());
            header.addView(dot);

            title.setText("天使辅助");
            title.setTextColor(Color.parseColor("#FF4CE07A"));
            title.setTextSize(14);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            header.addView(title);

            // 点胶囊任意处 -> 展开/折叠
            header.setOnClickListener(v -> setCollapsed(!collapsed));

            addView(header);

            body.setOrientation(LinearLayout.VERTICAL);
            body.setPadding(0, dp(8), 0, 0);
            body.setVisibility(GONE);
            addView(body);
            // 必须显式调用一次，否则宽度还是外层的 MATCH_PARENT，胶囊会被拉成一条
            setCollapsed(true);
        }

        private void setCollapsed(boolean v) {
            collapsed = v;
            body.setVisibility(v ? GONE : VISIBLE);
            setBackground(capsuleBg(v));
            setPadding(dp(12), v ? dp(5) : dp(9), dp(12), v ? dp(5) : dp(10));

            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
            if (lp != null) {
                lp.width = v ? ViewGroup.LayoutParams.WRAP_CONTENT
                             : ViewGroup.LayoutParams.MATCH_PARENT;
                setLayoutParams(lp);
            }
        }

        /** 折叠=胶囊（圆角拉满），展开=圆角矩形 */
        private GradientDrawable capsuleBg(boolean capsule) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xE8000000);
            g.setCornerRadius(capsule ? dp(24) : dp(10));
            g.setStroke(1, 0x994CE07A);
            return g;
        }

        private GradientDrawable dotBg() {
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFF4CE07A);
            g.setCornerRadius(dp(5));
            return g;
        }
    }

    private void refreshModelLabel() {
        if (tvModel == null) return;
        if (detector.mockMode) {
            tvModel.setTextColor(Color.parseColor("#FFFF5555"));
            tvModel.setText("MOCK 演示模式：未加载模型，画面中的框不是真实识别");
        } else {
            tvModel.setTextColor(Color.parseColor("#FF3DA5FF"));
            tvModel.setText("模型 " + detector.modelName() + "：真实识别");
        }
        if (hud != null) {
            hud.mock = detector.mockMode;
            hud.modelName = detector.modelName();
        }
    }

    private final Runnable statLoop = new Runnable() {
        @Override public void run() {
            tvStat.setText("FPS " + String.format("%.1f", hud.fps)
                    + "  当前 " + lastCount + "  累计 " + tracker.totalSeen);
            refreshModelLabel();
            if (tvDiag != null) tvDiag.setText("诊断 " + detector.diagLine());
            ui.postDelayed(this, 500);
        }
    };

    private GradientDrawable panelBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xE8000000);
        g.setCornerRadius(dp(8));
        g.setStroke(1, 0x804CE07A);
        return g;
    }

    private GradientDrawable buttonBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xEE14324A);
        g.setCornerRadius(dp(6));
        g.setStroke(1, 0xFF3DA5FF);
        return g;
    }

    private View divider() {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1));
        v.setBackgroundColor(0x444CE07A);
        ((LinearLayout.LayoutParams) v.getLayoutParams()).setMargins(0, dp(6), 0, dp(6));
        return v;
    }

    private TextView section(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.parseColor("#FF7FCFA0"));
        t.setTextSize(12);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    /** 蓝色开关行：小方块指示灯 + 文字，点击切换 */
    private class ToggleRow extends LinearLayout {
        private boolean on;
        private final View indicator;
        private final TextView label;
        private final OnToggle cb;
        private ToggleRow opposite;

        ToggleRow(Context ctx, String text, boolean init, OnToggle cb) {
            super(ctx);
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(0, dp(5), 0, dp(5));
            on = init;
            this.cb = cb;

            indicator = new View(ctx);
            indicator.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
            ((LinearLayout.LayoutParams) indicator.getLayoutParams()).setMargins(0, 0, dp(10), 0);
            addView(indicator);

            label = new TextView(ctx);
            label.setText(text);
            label.setTextSize(13);
            addView(label);

            paint();
            setOnClickListener(v -> toggle());
            cb.apply(on);
        }

        /** 切换自身；若与另一项互斥，则把对方置为相反状态 */
        private void toggle() {
            boolean next = !on;
            setOn(next);
            cb.apply(next);
            if (opposite != null) {
                opposite.setOn(!next);
                opposite.cb.apply(!next);
            }
        }

        void link(ToggleRow other) { this.opposite = other; other.opposite = this; }

        void setOn(boolean v) {
            on = v;
            paint();
        }

        private void paint() {
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(3));
            if (on) {
                g.setColor(0xFF2E8BFF);
                g.setStroke(1, 0xFF7FBDFF);
                label.setTextColor(Color.parseColor("#FFE8F4FF"));
            } else {
                g.setColor(0xFF1A2028);
                g.setStroke(1, 0xFF556070);
                label.setTextColor(Color.parseColor("#FF9AA6B2"));
            }
            indicator.setBackground(g);
        }
    }

    private interface OnToggle { void apply(boolean v); }

    private void applyConf(int progress) {
        float conf = 0.20f + (progress / 100f) * 0.60f;
        detector.confThr = conf;
        tvSens.setText("探测灵敏度  " + String.format("%.2f", conf));
    }

    // ---------------------------------------------------------------- 相机

    private void readCameraChars() {
        try {
            Object cm = getSystemService("camera");
            String id = (lens == CameraSelector.LENS_FACING_BACK) ? "0" : "1";
            java.lang.reflect.Method m = cm.getClass()
                    .getMethod("getCameraCharacteristics", String.class);
            Object cc = m.invoke(cm, id);
            distEst.setFromCamera(cc, AH);
        } catch (Throwable e) {
            Log.w(TAG, "相机参数读取失败，使用默认 FOV", e);
        }
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(this);
        f.addListener(() -> {
            try {
                provider = f.get();
                bind();
            } catch (Exception e) {
                Log.e(TAG, "相机启动失败", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bind() {
        if (provider == null) return;
        provider.unbindAll();

        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        // 模型输入只有 320，取 640x480 足够，分辨率越高只是白白增加取帧开销
        ImageAnalysis analysis = new ImageAnalysis.Builder()
                .setTargetResolution(new Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build();
        analysis.setAnalyzer(exec, this::analyze);

        try {
            provider.bindToLifecycle(this,
                    new CameraSelector.Builder().requireLensFacing(lens).build(),
                    preview, analysis);
        } catch (Exception e) {
            Log.e(TAG, "绑定相机失败", e);
        }
    }

    private void analyze(ImageProxy img) {
        try {
            Bitmap bmp = img.toBitmap();
            int rot = img.getImageInfo().getRotationDegrees();
            if (rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                Bitmap r = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                bmp.recycle();
                bmp = r;
            }
            final int w = bmp.getWidth(), h = bmp.getHeight();

            List<Det> dets = detector.detect(bmp, multiObject);
            List<Target> targets = tracker.update(dets);
            for (Target t : targets) {
                float raw = distEst.estimate(t.h(), t.clsId);
                // 距离 EMA 平滑，避免数值疯狂跳动
                t.distM = (t.age <= 2) ? raw : t.distM + (raw - t.distM) * 0.35f;
            }
            final int total = tracker.totalSeen;
            final int cur = targets.size();
            lastCount = cur;

            ui.post(() -> {
                hud.setTargets(targets, w, h, total);
                tvStat.setText("FPS " + Math.round(hud.fps) + "  当前 " + cur
                        + "  累计 " + total);
            });
            if (bmp != null && !bmp.isRecycled()) bmp.recycle();
        } catch (Exception e) {
            Log.e(TAG, "分析帧失败", e);
        } finally {
            img.close();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacks(statLoop);
        exec.shutdown();
        detector.close();
        if (provider != null) provider.unbindAll();
    }

    // ================================================================ 数据结构

    static class Det {
        float x1, y1, x2, y2, conf;
        int clsId;
        String label = "目标";
        float[] kps = null;

        Det(float x1, float y1, float x2, float y2, float conf, int clsId, String label) {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
            this.conf = conf; this.clsId = clsId; this.label = label;
        }
        float w() { return Math.max(0f, x2 - x1); }
        float h() { return Math.max(0f, y2 - y1); }
        float cx() { return (x1 + x2) * 0.5f; }
        float cy() { return (y1 + y2) * 0.5f; }
    }

    static class Target {
        int id;
        float x1, y1, x2, y2, conf, distM;
        int clsId;
        String label = "目标";
        int age, lost;
        float[] kps;

        float cx() { return (x1 + x2) * 0.5f; }
        float cy() { return (y1 + y2) * 0.5f; }
        float h() { return Math.max(1f, y2 - y1); }
        float w() { return Math.max(1f, x2 - x1); }

        void update(Det d) {
            if (age == 0) {
                // 首次出现，直接采用
                x1 = d.x1; y1 = d.y1; x2 = d.x2; y2 = d.y2;
            } else {
                // EMA 平滑：抑制逐帧抖动，又不至于跟不上运动
                float a = 0.55f;
                x1 += (d.x1 - x1) * a;
                y1 += (d.y1 - y1) * a;
                x2 += (d.x2 - x2) * a;
                y2 += (d.y2 - y2) * a;
            }
            conf = d.conf; clsId = d.clsId; label = d.label; kps = d.kps;
            age++; lost = 0;
        }
    }

    // ================================================================ 跟踪器

    static class Tracker {
        private final float iouThr = 0.35f;
        private final int maxLost = 12, minHits = 2;
        private final List<Target> tracks = new ArrayList<>();
        private int nextId = 1;
        volatile int totalSeen = 0;

        List<Target> update(List<Det> dets) {
            List<float[]> pairs = new ArrayList<>();
            for (int ti = 0; ti < tracks.size(); ti++)
                for (int di = 0; di < dets.size(); di++) {
                    float v = iou(tracks.get(ti), dets.get(di));
                    if (v >= iouThr) pairs.add(new float[]{v, ti, di});
                }
            pairs.sort((a, b) -> Float.compare(b[0], a[0]));

            boolean[] ut = new boolean[tracks.size()], ud = new boolean[dets.size()];
            for (float[] p : pairs) {
                int ti = (int) p[1], di = (int) p[2];
                if (ut[ti] || ud[di]) continue;
                ut[ti] = true; ud[di] = true;
                tracks.get(ti).update(dets.get(di));
            }
            for (int di = 0; di < dets.size(); di++) {
                if (ud[di]) continue;
                Det d = dets.get(di);
                if (d.conf < 0.35f && !tracks.isEmpty()) continue;
                Target t = new Target();
                t.id = nextId++;
                t.update(d);
                t.age = 1;
                totalSeen++;
                tracks.add(t);
            }
            List<Target> alive = new ArrayList<>();
            for (int ti = 0; ti < tracks.size(); ti++) {
                Target t = tracks.get(ti);
                if (!ut[ti]) t.lost++;
                if (t.lost <= maxLost) alive.add(t);
            }
            tracks.clear();
            tracks.addAll(alive);

            List<Target> out = new ArrayList<>();
            for (Target t : tracks)
                if (t.age >= minHits && t.lost == 0) out.add(t);
            out.sort((a, b) -> Float.compare(a.distM, b.distM));
            return out;
        }

        private static float iou(Target t, Det d) {
            float ix1 = Math.max(t.x1, d.x1), iy1 = Math.max(t.y1, d.y1);
            float ix2 = Math.min(t.x2, d.x2), iy2 = Math.min(t.y2, d.y2);
            float iw = Math.max(0f, ix2 - ix1), ih = Math.max(0f, iy2 - iy1);
            float inter = iw * ih;
            if (inter <= 0) return 0f;
            float sa = Math.max(0f, t.x2 - t.x1) * Math.max(0f, t.y2 - t.y1);
            float sb = Math.max(0f, d.x2 - d.x1) * Math.max(0f, d.y2 - d.y1);
            return inter / (sa + sb - inter + 1e-6f);
        }

        void reset() {
            tracks.clear(); nextId = 1; totalSeen = 0;
        }
    }

    // ================================================================ 测距

    static class DistanceEstimator {
        private float fPx;
        private int imgH;
        float userScale = 1.0f;

        private static final float[] REAL_H = new float[81];
        static {
            for (int i = 0; i < REAL_H.length; i++) REAL_H[i] = 1.70f;
            REAL_H[0] = 1.70f;   // person
            REAL_H[1] = 1.20f;   // bicycle
            REAL_H[2] = 1.15f;   // car
            REAL_H[3] = 1.30f;   // motorbike
            REAL_H[5] = 3.20f;   // bus
            REAL_H[7] = 3.00f;   // truck
        }

        DistanceEstimator(int imgH) {
            this.imgH = imgH;
            setFov(49f);
        }

        void setFov(float fovV) {
            fPx = (float) ((imgH / 2.0) / Math.tan(Math.toRadians(fovV) / 2.0));
        }

        void setFromCamera(Object cc, int h) {
            imgH = h;
            try {
                Class<?> k = Class.forName("android.hardware.camera2.CameraCharacteristics");
                java.lang.reflect.Method get = cc.getClass().getMethod("get",
                        Class.forName("android.hardware.camera2.CameraCharacteristics$Key"));
                float fl = ((Float) get.invoke(cc, k.getField("LENS_FOCAL_LENGTH").get(null)));
                float phH = ((android.util.SizeF) get.invoke(cc,
                        k.getField("SENSOR_INFO_PHYSICAL_SIZE").get(null))).getHeight();
                if (fl > 0 && phH > 0) {
                    fPx = fl / phH * h;
                    return;
                }
            } catch (Throwable ignored) { }
            setFov(49f);
        }

        float estimate(float hPx, int clsId) {
            if (hPx <= 1f) return 0f;
            float H = (clsId >= 0 && clsId < REAL_H.length) ? REAL_H[clsId] : 1.70f;
            float d = fPx * H / hPx * userScale;
            return Math.min(Math.max(d, 0.3f), 200f);
        }
    }
}
