package com.angel.hud;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.method.ScrollingMovementMethod;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Random;

/**
 * 启动流程（对齐常见辅助工具的开屏体验）：
 *   1) 使用须知：公告 + 条款，点「我已知晓」
 *   2) 加载页：旋转圆环 + 「正在探寻天眼...」+ 左下角滚动代码日志
 *   3) 加载完成 -> 进入 MainActivity
 */
public class SplashActivity extends Activity {

    private static final String[] BOOT_LOGS = {
            "[INFO] boot sequence start",
            "[NET] connecting to local runtime ...",
            "[INFO] loading vision module",
            "[OK] onnxruntime initialized",
            "[INFO] warming up detector",
            "[WARN] latency spike 42ms",
            "[INFO] binding camera provider",
            "[OK] pipeline ready",
            "requestAnimationFrame(renderLoop);",
            "[INFO] awaiting first frame"
    };

    private final Handler ui = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private TextView tvLog = null;
    private boolean logVisible = false;
    private final Random rnd = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF05070A);
        setContentView(root);

        // 须知页竖屏阅读，加载页与主界面横屏
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        showNotice();
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    // ============================================================ 1. 使用须知

    private void showNotice() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF05070A);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(24), dp(22), dp(20));

        TextView title = new TextView(this);
        title.setText("天使辅助");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView sub = new TextView(this);
        sub.setText("使 用 须 知");
        sub.setTextColor(0xFF3DA5FF);
        sub.setTextSize(15);
        sub.setTypeface(null, android.graphics.Typeface.BOLD);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(16));
        box.addView(sub);

        TextView intro = new TextView(this);
        intro.setText("本软件是一款基于摄像头的本地 AI 视觉识别工具，"
                + "可实时识别画面中的人、动物、车辆及常见物品，并以悬浮窗方式标注。");
        intro.setTextColor(0xFFC6D2DC);
        intro.setTextSize(13);
        intro.setLineSpacing(dp(2), 1.2f);
        intro.setPadding(0, 0, 0, dp(14));
        box.addView(intro);

        box.addView(noticeBox());

        box.addView(clause("相机权限",
                "本软件需要调用摄像头权限，仅用于获取实时画面进行本地识别，"
                        + "不会拍照、不会录像、不会截取任何画面。"));
        box.addView(clause("数据与隐私",
                "全部识别计算均在设备本地完成，画面数据不采集、不上传、不保存，"
                        + "软件不请求任何与识别无关的权限。"));
        box.addView(clause("结果说明",
                "识别结果由 AI 模型实时推断，受光线、角度、遮挡等因素影响，"
                        + "存在误判与漏判的可能，仅供参考，请以实际画面为准。"));
        box.addView(clause("合规使用",
                "请严格遵守所在地区的法律法规合理使用，"
                        + "严禁用于任何违法违规或侵犯他人权益的用途。"));
        box.addView(clause("免责声明",
                "因使用本软件产生的任何直接或间接后果，均由使用者自行承担，"
                        + "开发者不承担相关责任。"));

        TextView tip = new TextView(this);
        tip.setText("继续使用即表示你已阅读并同意上述条款");
        tip.setTextColor(0xFF7A8896);
        tip.setTextSize(12);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, dp(14), 0, dp(10));
        box.addView(tip);

        final TextView btn = new TextView(this);
        btn.setText("我已知晓");
        btn.setTextColor(0xFFE8FFF2);
        btn.setTextSize(16);
        btn.setTypeface(null, android.graphics.Typeface.BOLD);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(20), dp(12), dp(20), dp(12));
        btn.setBackground(blueButton());
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.setMargins(dp(10), 0, dp(10), dp(6));
        btn.setLayoutParams(blp);
        btn.setOnClickListener(v -> showLoading());
        box.addView(btn);

        sv.addView(box);
        root.removeAllViews();
        root.addView(sv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** 公告框：标题「公告」+ 内容 */
    private View noticeBox() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackground(borderedBg(0xFF4CE07A));
        wrap.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(14));
        wrap.setLayoutParams(lp);

        TextView h = new TextView(this);
        h.setText("公告");
        h.setTextColor(0xFF4CE07A);
        h.setTextSize(14);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        h.setPadding(0, 0, 0, dp(6));
        wrap.addView(h);

        TextView c = new TextView(this);
        c.setText("官方Q群895915080");
        c.setTextColor(0xFFDCEEE3);
        c.setTextSize(14);
        wrap.addView(c);

        return wrap;
    }

    private View clause(String head, String body) {
        LinearLayout w = new LinearLayout(this);
        w.setOrientation(LinearLayout.VERTICAL);
        w.setPadding(0, 0, 0, dp(10));

        TextView h = new TextView(this);
        h.setText(head);
        h.setTextColor(0xFFDCEEE3);
        h.setTextSize(14);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        w.addView(h);

        TextView b = new TextView(this);
        b.setText(body);
        b.setTextColor(0xFFC6D2DC);
        b.setTextSize(13);
        b.setPadding(0, dp(3), 0, 0);
        b.setLineSpacing(dp(2), 1.15f);
        w.addView(b);
        return w;
    }

    // ============================================================ 2. 加载页

    private void showLoading() {
        // 点「我已知晓」后切到横屏，与主界面方向一致，避免进入时再翻转一次
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        FrameLayout page = new FrameLayout(this);
        page.setBackgroundColor(0xFF05070A);

        // 中间：旋转圆环 + 文字
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER_HORIZONTAL);

        RingView ring = new RingView(this);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(72), dp(72));
        rlp.gravity = Gravity.CENTER_HORIZONTAL;
        ring.setLayoutParams(rlp);
        center.addView(ring);
        ring.start();

        TextView name = new TextView(this);
        name.setText("天使辅助");
        name.setTextColor(0xFF4CE07A);
        name.setTextSize(20);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        name.setPadding(0, dp(16), 0, 0);
        center.addView(name);

        TextView status = new TextView(this);
        status.setText("正在探寻天眼...");
        status.setTextColor(0xFF9FE8BC);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(6), 0, 0);
        center.addView(status);

        // 必须 MATCH_PARENT：用 WRAP_CONTENT 时，子 TextView 的 MATCH_PARENT
        // 与父容器 WRAP_CONTENT 互相依赖，测量宽度被算小，文字会被截断
        //（表现为「天使辅」「正在探寻天」少一个字）。
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        page.addView(center, clp);

        // 左下角：滚动代码日志
        tvLog = new TextView(this);
        tvLog.setTextColor(0xFF4CE07A);
        tvLog.setTextSize(11);
        tvLog.setTypeface(android.graphics.Typeface.MONOSPACE);
        tvLog.setMovementMethod(new ScrollingMovementMethod());
        tvLog.setPadding(dp(10), dp(6), dp(10), dp(6));
        FrameLayout.LayoutParams llp = new FrameLayout.LayoutParams(
                dp(280), dp(150), Gravity.BOTTOM | Gravity.START);
        llp.leftMargin = dp(10);
        llp.bottomMargin = dp(10);
        page.addView(tvLog, llp);

        // 右下：诊断日志开关
        final TextView btnLog = new TextView(this);
        btnLog.setText("诊断日志");
        btnLog.setTextColor(0xFFE8FFF2);
        btnLog.setTextSize(13);
        btnLog.setTypeface(null, android.graphics.Typeface.BOLD);
        btnLog.setPadding(dp(12), dp(6), dp(12), dp(6));
        btnLog.setBackground(blueButton());
        btnLog.setOnClickListener(v -> {
            logVisible = !logVisible;
            if (tvLog != null) tvLog.setVisibility(logVisible ? View.VISIBLE : View.INVISIBLE);
            btnLog.setText(logVisible ? "隐藏日志" : "诊断日志");
        });
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        dlp.bottomMargin = dp(14);
        dlp.rightMargin = dp(14);
        page.addView(btnLog, dlp);

        root.removeAllViews();
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        startLogScroll();
        ui.postDelayed(this::enterMain, 2600);
    }

    /** 左下角代码一行行往上弹 */
    private void startLogScroll() {
        final StringBuilder sb = new StringBuilder();
        final int[] idx = {0};
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (tvLog == null) return;
                String line = BOOT_LOGS[idx[0] % BOOT_LOGS.length];
                if (rnd.nextInt(100) < 25) {
                    line = line + "  " + Integer.toHexString(rnd.nextInt(0xFFFF));
                }
                sb.append(line).append("\n");
                // 只保留最后 10 行，形成持续滚动的效果
                String[] lines = sb.toString().split("\n");
                int from = Math.max(0, lines.length - 10);
                StringBuilder show = new StringBuilder();
                for (int i = from; i < lines.length; i++) show.append(lines[i]).append("\n");
                tvLog.setText(show.toString());
                idx[0]++;
                ui.postDelayed(this, 260);
            }
        }, 120);
    }

    // ============================================================ 3. 进入主界面

    private void enterMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
    }

    // ============================================================ 绘制辅助

    /** 旋转的圆环加载动画 */
    private static class RingView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval = new RectF();
        private float angle = 0f;
        private android.animation.ValueAnimator anim = null;
        private final int accent = 0xFF4CE07A;

        RingView(android.content.Context c) {
            super(c);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
        }

        void start() {
            anim = android.animation.ValueAnimator.ofFloat(0f, 360f);
            anim.setDuration(1100);
            anim.setRepeatCount(android.animation.ValueAnimator.INFINITE);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(a -> {
                angle = (Float) a.getAnimatedValue();
                invalidate();
            });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float r = Math.min(w, h) / 2f - 6f;
            oval.set(w / 2f - r, h / 2f - r, w / 2f + r, h / 2f + r);

            p.setColor(0x223DA5FF);
            p.setStrokeWidth(4f);
            c.drawCircle(w / 2f, h / 2f, r, p);

            p.setColor(accent);
            p.setStrokeWidth(5f);
            c.drawArc(oval, angle, 100f, false, p);

            p.setColor(0xAA4CE07A);
            p.setStrokeWidth(3f);
            c.drawArc(oval, angle + 180f, 40f, false, p);
        }

        @Override
        protected void onDetachedFromWindow() {
            if (anim != null) anim.cancel();
            super.onDetachedFromWindow();
        }
    }

    private android.graphics.drawable.GradientDrawable blueButton() {
        android.graphics.drawable.GradientDrawable g =
                new android.graphics.drawable.GradientDrawable();
        g.setColor(0xFF1E6FD9);
        g.setCornerRadius(dp(8));
        return g;
    }

    private android.graphics.drawable.GradientDrawable borderedBg(int border) {
        android.graphics.drawable.GradientDrawable g =
                new android.graphics.drawable.GradientDrawable();
        g.setColor(0x14000000);
        g.setCornerRadius(dp(8));
        g.setStroke(1, border);
        return g;
    }
}
