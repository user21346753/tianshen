package com.angel.hud;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OnnxValue;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * YOLOv8 检测 / 姿态 的 ONNX Runtime 封装。
 *
 * 为什么用 ONNX Runtime 而不是 TFLite：
 *   1) CPU 推理快（XNNPACK/MLAS），同模型帧率可差数倍
 *   2) 导出 ONNX 不需要 tensorflow，避开 TFLite 导出的一堆坑
 *   3) YOLOv8 的 ONNX 输出是标准的 [1,84,8400] / [1,56,8400]，
 *      不像 tflite 有 NCHW/NHWC/量化/紧凑格式那么多分支
 *
 * 这里只使用 ONNX Runtime Java API 中最基础、最稳定的一部分，
 * 不依赖 getInputInfo()/TensorInfo/ByteBuffer 等容易因版本而异的接口。
 *
 * assets:
 *   det.onnx   -> 检测模型
 *   pose.onnx  -> 姿态模型（输出真实 17 关键点）
 */
public class Detector {

    private static final String TAG = "Detector";

    /** 模型输入尺寸。导出脚本固定 imgsz=320，故这里保持一致 */
    private static final int IN = 320;

    private OrtEnvironment env = null;
    private OrtSession det = null;      // 检测
    private OrtSession pose = null;     // 姿态

    private String detInName = "images";
    private String detOutName = null;
    private String poseInName = "images";
    private String poseOutName = null;

    /** 界面「识别类别过滤」勾选的类别；由 MainActivity 赋值 */
    static volatile java.util.Set<Integer> enabledCls = null;

    volatile boolean mockMode = true;
    volatile String detName = null;
    volatile String poseName = null;
    volatile long detBytes = 0;
    volatile float confThr = 0.45f;
    private final float nmsThr = 0.48f;

    // 诊断
    volatile int rawCount = 0;
    volatile float maxScore = 0f;
    volatile String shapeInfo = "-";
    volatile String firstBox = "-";
    volatile String lastError = "-";

    private float scale = 1f, padX = 0f, padY = 0f;
    private int mockFrame = 0;

    public Detector(Context ctx) {
        try {
            env = OrtEnvironment.getEnvironment();

            AssetManager am = ctx.getAssets();
            String[] fs = am.list("");
            List<String> names = new ArrayList<>();
            if (fs != null) Collections.addAll(names, fs);

            String detFile = null, poseFile = null;
            // 构建脚本已把选中的模型统一命名为 det.onnx / pose.onnx
            if (names.contains("det.onnx")) {
                detFile = "det.onnx";
            } else {
                // 兜底：按精度顺序 s > m > n 挑，避免拿到最弱的那一个
                for (String pref : new String[]{"yolov8s", "yolov8m", "yolov8n"}) {
                    for (String f : names) {
                        if (f.endsWith(".onnx") && f.startsWith(pref) && !f.contains("pose")) {
                            detFile = f;
                            break;
                        }
                    }
                    if (detFile != null) break;
                }
            }
            if (names.contains("pose.onnx")) {
                poseFile = "pose.onnx";
            } else {
                for (String f : names) {
                    if (f.endsWith(".onnx") && f.contains("pose")) { poseFile = f; break; }
                }
            }
            detName = detFile;
            poseName = poseFile;
            Log.i(TAG, "det=" + detFile + " pose=" + poseFile);

            OrtSession.SessionOptions o = new OrtSession.SessionOptions();
            o.setIntraOpNumThreads(4);

            if (detFile != null) {
                det = env.createSession(readAll(am, detFile), o);
                detInName = pickName(det.getInputNames(), "images");
                detOutName = pickName(det.getOutputNames(), "output0");
                detBytes = sizeOf(am, detFile);
                Log.i(TAG, "det ready in=" + detInName + " out=" + detOutName);
            }
            if (poseFile != null) {
                pose = env.createSession(readAll(am, poseFile), o);
                poseInName = pickName(pose.getInputNames(), "images");
                poseOutName = pickName(pose.getOutputNames(), "output0");
                Log.i(TAG, "pose ready in=" + poseInName + " out=" + poseOutName);
            }
            mockMode = (det == null && pose == null);
            Log.i(TAG, "mockMode=" + mockMode);
        } catch (Throwable e) {
            Log.e(TAG, "初始化失败", e);
            lastError = "init:" + e;
            mockMode = true;
        }
    }

    /** 取第一个可用名字，空则用默认值 */
    private static String pickName(Set<String> s, String fallback) {
        try {
            if (s != null && !s.isEmpty()) return s.iterator().next();
        } catch (Throwable ignored) { }
        return fallback;
    }

    private static byte[] readAll(AssetManager am, String path) throws Exception {
        InputStream is = am.open(path);
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        return bos.toByteArray();
    }

    private static long sizeOf(AssetManager am, String path) {
        try {
            return am.openFd(path).getLength();
        } catch (Throwable t) {
            return 0;
        }
    }

    /** 输入原图，输出检测结果（坐标已还原到原图尺寸） */
    public List<MainActivity.Det> detect(Bitmap frame, boolean multi) {
        if (mockMode) return mock(frame, multi);

        List<MainActivity.Det> out = new ArrayList<>();
        if (det != null) out.addAll(run(det, detInName, detOutName, frame, multi));
        if (pose != null) {
            List<MainActivity.Det> pd = run(pose, poseInName, poseOutName, frame, multi);
            if (det == null) {
                // 没有检测模型时，姿态模型的结果经形状校验后才用
                for (MainActivity.Det d : pd) if (plausiblePerson(d)) out.add(d);
            } else {
                // 只把关键点挂到检测框上，不把姿态模型的框并入候选：
                // 姿态模型对床单/衣物/杂物误检率很高，并进来会多出假人
                attachPose(out, pd);
            }
        }
        out = nms(out);

        java.util.Set<Integer> allow = enabledCls;
        if (allow != null && !allow.isEmpty()) {
            List<MainActivity.Det> kept = new ArrayList<>();
            for (MainActivity.Det d : out) {
                if (allow.contains(d.clsId)) kept.add(d);
            }
            out = kept;
        }
        return suppressAnimalOverlap(out);
    }

    /** 把 pose 的真实关键点挂到最近的检测框上 */
    private void attachPose(List<MainActivity.Det> dets, List<MainActivity.Det> poses) {
        for (MainActivity.Det d : dets) {
            if (d.clsId != 0) continue;
            float best = 0f;
            MainActivity.Det bp = null;
            for (MainActivity.Det p : poses) {
                float v = iou(d, p);
                if (v > best) { best = v; bp = p; }
            }
            if (bp != null && best > 0.4f) d.kps = bp.kps;
        }
    }

    private List<MainActivity.Det> run(OrtSession s, String inName, String outName,
                                       Bitmap frame, boolean multi) {
        int ow = frame.getWidth(), oh = frame.getHeight();
        Bitmap in = letterbox(frame, IN);
        int[] px = new int[IN * IN];
        in.getPixels(px, 0, IN, 0, 0, IN, IN);

        // YOLOv8 ONNX 输入是 NCHW float：先整片 R，再 G，再 B
        int plane = IN * IN;
        java.nio.FloatBuffer buf = java.nio.ByteBuffer
                .allocateDirect(plane * 3 * 4)
                .order(java.nio.ByteOrder.nativeOrder())
                .asFloatBuffer();
        for (int ch = 0; ch < 3; ch++) {
            int shift = 16 - ch * 8;    // R=16 G=8 B=0
            for (int i = 0; i < plane; i++) {
                buf.put(((px[i] >> shift) & 0xFF) / 255f);
            }
        }
        buf.rewind();

        List<MainActivity.Det> out = new ArrayList<>();
        OnnxTensor tensor = null;
        OrtSession.Result res = null;
        try {
            tensor = OnnxTensor.createTensor(env, buf, new long[]{1, 3, IN, IN});
            res = s.run(Collections.singletonMap(inName, tensor));

            // 用索引取，规避 res.get(String) 在不同版本返回 Optional 的差异
            OnnxValue ov = res.get(0);
            if (ov instanceof OnnxTensor) {
                Object v = ((OnnxTensor) ov).getValue();
                decode(v, out, ow, oh, multi);
            } else {
                lastError = "输出不是 OnnxTensor";
            }
            lastError = "-";
        } catch (Throwable e) {
            Log.e(TAG, "run failed", e);
            lastError = "run:" + e;
        } finally {
            try { if (res != null) res.close(); } catch (Throwable ignored) { }
            try { if (tensor != null) tensor.close(); } catch (Throwable ignored) { }
        }
        return out;
    }

    /** 解析 [1,C,N]（也可能是 [C,N]）输出 */
    private void decode(Object v, List<MainActivity.Det> out,
                        int ow, int oh, boolean multi) {
        float[] data;
        int C, N;
        if (v instanceof float[][][]) {
            float[][][] a = (float[][][]) v;
            if (a.length == 0) return;
            C = a[0].length;
            N = a[0][0].length;
            data = new float[C * N];
            for (int c = 0; c < C; c++) System.arraycopy(a[0][c], 0, data, c * N, N);
        } else if (v instanceof float[][]) {
            float[][] a = (float[][]) v;
            C = a.length;
            N = a[0].length;
            data = new float[C * N];
            for (int c = 0; c < C; c++) System.arraycopy(a[c], 0, data, c * N, N);
        } else {
            lastError = "未知输出:" + (v == null ? "null" : v.getClass().getName());
            return;
        }

        // 检测=84(4+80类)，姿态=56(4+1+51)
        boolean isPose = (C == 56);
        shapeInfo = C + "x" + N + " in" + IN + (isPose ? " POSE" : " DET");

        float best = 0f;
        int raw = 0;
        String fb = "-";

        for (int i = 0; i < N; i++) {
            float bx = data[0 * N + i];
            float by = data[1 * N + i];
            float bw = data[2 * N + i];
            float bh = data[3 * N + i];

            int clsId = 0;
            float score;
            if (isPose) {
                score = data[4 * N + i];
            } else {
                float bestV = -1f;
                for (int c = 4; c < C; c++) {
                    float s = data[c * N + i];
                    if (s > bestV) { bestV = s; clsId = c - 4; }
                }
                score = bestV;
            }
            if (score > best) best = score;
            if (score < 0.01f) continue;
            raw++;
            if ("-".equals(fb)) {
                fb = String.format("%.0f,%.0f,%.0f,%.0f s=%.2f c=%d", bx, by, bw, bh, score, clsId);
            }

            // 非人（动物/物体）误检率高，要求更高分数
            float thr = (clsId == 0) ? confThr : confThr + 0.18f;
            if (score < thr) continue;
            if (!multi && clsId != 0) continue;

            float x1 = (bx - bw / 2f - padX) / scale;
            float y1 = (by - bh / 2f - padY) / scale;
            float x2 = (bx + bw / 2f - padX) / scale;
            float y2 = (by + bh / 2f - padY) / scale;
            x1 = clamp(x1, 0, ow); x2 = clamp(x2, 0, ow);
            y1 = clamp(y1, 0, oh); y2 = clamp(y2, 0, oh);
            if (x2 - x1 < 4 || y2 - y1 < 4) continue;

            // 行人形状校验：滤掉床单/衣物/纸箱这类被误判成人的扁平物
            if (clsId == 0 && !plausiblePerson(
                    new MainActivity.Det(x1, y1, x2, y2, score, clsId, ""))) continue;

            MainActivity.Det d = new MainActivity.Det(x1, y1, x2, y2, score, clsId, zh(clsId));
            if (isPose) {
                d.kps = new float[51];
                for (int k = 0; k < 17; k++) {
                    d.kps[k * 3]     = (data[(5 + k * 3) * N + i] - padX) / scale;
                    d.kps[k * 3 + 1] = (data[(6 + k * 3) * N + i] - padY) / scale;
                    d.kps[k * 3 + 2] = data[(7 + k * 3) * N + i];
                }
            }
            out.add(d);
        }
        rawCount = raw;
        maxScore = best;
        firstBox = fb;
    }

    /**
     * 行人形状校验：小模型常把床单、衣物、纸箱认成人。
     * 用三点约束滤掉明显不是人的框：
     *   - 高宽比：站/坐的人通常 h/w >= 0.9（横躺的放宽到 0.45）
     *   - 面积占比：不能占满整屏（那多半是背景/大件杂物）
     */
    private boolean plausiblePerson(MainActivity.Det d) {
        float w = d.w(), h = d.h();
        if (w <= 0 || h <= 0) return false;
        float ratio = h / w;
        if (ratio < 0.45f) return false;          // 太扁，不像人
        if (ratio > 12f) return false;            // 太细长，多半是杆子/电线
        return true;
    }

    /** 人优先：动物/物体框若与行人框高度重叠则丢弃（小模型常把人认成动物） */
    private List<MainActivity.Det> suppressAnimalOverlap(List<MainActivity.Det> dets) {
        boolean hasHuman = false;
        for (MainActivity.Det d : dets) {
            if (d.clsId == 0) { hasHuman = true; break; }
        }
        if (!hasHuman) return dets;
        List<MainActivity.Det> out = new ArrayList<>();
        for (MainActivity.Det d : dets) {
            if (d.clsId == 0) { out.add(d); continue; }
            boolean covered = false;
            for (MainActivity.Det h : dets) {
                if (h.clsId != 0) continue;
                if (iou(d, h) > 0.5f) { covered = true; break; }
            }
            if (!covered) out.add(d);
        }
        return out;
    }

    private Bitmap letterbox(Bitmap src, int size) {
        int ow = src.getWidth(), oh = src.getHeight();
        scale = Math.min((float) size / ow, (float) size / oh);
        int nw = Math.round(ow * scale), nh = Math.round(oh * scale);
        padX = (size - nw) / 2f;
        padY = (size - nh) / 2f;
        Bitmap s = Bitmap.createScaledBitmap(src, nw, nh, true);
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.rgb(114, 114, 114));
        c.drawBitmap(s, padX, padY, null);
        return b;
    }

    private List<MainActivity.Det> nms(List<MainActivity.Det> dets) {
        dets.sort((a, b) -> Float.compare(b.conf, a.conf));
        List<MainActivity.Det> keep = new ArrayList<>();
        boolean[] dead = new boolean[dets.size()];
        for (int i = 0; i < dets.size(); i++) {
            if (dead[i]) continue;
            keep.add(dets.get(i));
            for (int j = i + 1; j < dets.size(); j++) {
                if (dead[j]) continue;
                if (dets.get(i).clsId != dets.get(j).clsId) continue;  // per-class
                if (iou(dets.get(i), dets.get(j)) > nmsThr) dead[j] = true;
            }
        }
        return keep;
    }

    static float iou(MainActivity.Det a, MainActivity.Det b) {
        float ix1 = Math.max(a.x1, b.x1), iy1 = Math.max(a.y1, b.y1);
        float ix2 = Math.min(a.x2, b.x2), iy2 = Math.min(a.y2, b.y2);
        float iw = Math.max(0f, ix2 - ix1), ih = Math.max(0f, iy2 - iy1);
        float inter = iw * ih;
        if (inter <= 0) return 0f;
        float sa = a.w() * a.h(), sb = b.w() * b.h();
        return inter / (sa + sb - inter + 1e-6f);
    }

    /** 无模型时的合成目标（界面会明确提示 MOCK） */
    private List<MainActivity.Det> mock(Bitmap frame, boolean multi) {
        mockFrame++;
        int W = frame.getWidth(), H = frame.getHeight();
        List<MainActivity.Det> out = new ArrayList<>();
        float t = mockFrame / 60f;
        float hA = H * (0.30f + 0.10f * (float) Math.sin(t * 0.7));
        float xA = W * (0.30f + 0.22f * (float) Math.sin(t * 0.5));
        out.add(new MainActivity.Det(xA - hA * 0.17f, H * 0.82f - hA,
                xA + hA * 0.17f, H * 0.82f, 0.86f, 0, "行人"));
        float hB = H * (0.24f + 0.08f * (float) Math.cos(t * 0.9));
        float xB = W * (0.68f + 0.18f * (float) Math.cos(t * 0.6));
        out.add(new MainActivity.Det(xB - hB * 0.17f, H * 0.80f - hB,
                xB + hB * 0.17f, H * 0.80f, 0.82f, 0, "行人"));
        if (multi) {
            float hC = H * 0.20f;
            float xC = W * (0.50f + 0.30f * (float) Math.sin(t * 0.35 + 1.2));
            out.add(new MainActivity.Det(xC - hC * 0.38f, H * 0.88f - hC,
                    xC + hC * 0.38f, H * 0.88f, 0.80f, 3, "电动车"));
        }
        return out;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    static String zh(int id) {
        switch (id) {
            case 0: return "行人";
            case 1: return "自行车";
            case 2: return "汽车";
            case 3: return "摩托车";
            case 4: return "飞机";
            case 5: return "公交车";
            case 6: return "火车";
            case 7: return "卡车";
            case 8: return "船";
            case 14: return "鸟";
            case 15: return "猫";
            case 16: return "狗";
            case 17: return "马";
            case 18: return "羊";
            case 19: return "牛";
            case 20: return "大象";
            case 21: return "熊";
            case 22: return "斑马";
            case 23: return "长颈鹿";
            case 24: return "背包";
            case 25: return "雨伞";
            case 26: return "手提包";
            case 27: return "领带";
            case 28: return "行李箱";
            case 31: return "飞盘";
            case 32: return "滑雪板";
            case 35: return "冲浪板";
            case 38: return "网球拍";
            case 39: return "瓶子";
            case 40: return "酒杯";
            case 41: return "杯子";
            case 42: return "叉子";
            case 43: return "刀";
            case 44: return "勺子";
            case 45: return "碗";
            case 46: return "香蕉";
            case 47: return "苹果";
            case 48: return "三明治";
            case 49: return "橙子";
            case 50: return "西兰花";
            case 51: return "胡萝卜";
            case 52: return "热狗";
            case 53: return "披萨";
            case 54: return "甜甜圈";
            case 55: return "蛋糕";
            case 56: return "椅子";
            case 57: return "沙发";
            case 58: return "盆栽";
            case 59: return "床";
            case 60: return "餐桌";
            case 61: return "马桶";
            case 62: return "电视";
            case 63: return "笔记本";
            case 64: return "鼠标";
            case 65: return "遥控器";
            case 66: return "键盘";
            case 67: return "手机";
            case 68: return "微波炉";
            case 69: return "烤箱";
            case 70: return "烤面包机";
            case 71: return "水槽";
            case 72: return "冰箱";
            case 73: return "书";
            case 74: return "时钟";
            case 75: return "花瓶";
            case 76: return "剪刀";
            case 77: return "泰迪熊";
            case 78: return "吹风机";
            case 79: return "牙刷";
            default: return "目标" + id;
        }
    }

    /** 显示真实加载的模型文件名 + 体积 */
    public String modelName() {
        if (mockMode) return "MOCK 无模型";
        StringBuilder s = new StringBuilder();
        if (detName != null) {
            s.append(detName.replace(".onnx", ""));
            if (detBytes > 0) s.append(" ").append(detBytes / 1024 / 1024).append("MB");
        }
        if (poseName != null) s.append("+pose");
        return s.length() == 0 ? "ONNX" : s.toString();
    }

    public String diagLine() {
        if (mockMode) return "MOCK 演示：无模型";
        return "阈值前" + rawCount + " 最高" + String.format("%.2f", maxScore)
                + " | " + shapeInfo + " | " + firstBox
                + ("-".equals(lastError) ? "" : " | " + lastError);
    }

    public void close() {
        try { if (det != null) det.close(); } catch (Throwable ignored) { }
        try { if (pose != null) pose.close(); } catch (Throwable ignored) { }
    }
}
