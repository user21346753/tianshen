package com.angel.hud;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;

import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.nnapi.NnApiDelegate;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * YOLOv8 / YOLOv8-pose 的 TFLite 封装（高准确率优先）。
 *
 * assets/yolov8*.tflite       -> 目标检测
 * assets/yolov8n-pose.tflite  -> 姿态（真实骨骼关键点）
 *
 * 准确率优先策略：
 *   1. 输入尺寸 640（与导出一致），不做降采样
 *   2. 优先 NNAPI / GPU 硬件加速 delegate，失败回退 CPU 多线程
 *   3. 检测 + 姿态双模型并用：pose 模型同时输出框和关键点
 *   4. 保留完整 NMS，置信度阈值可由滑块细调
 */
public class Detector {

    private static final String TAG = "Detector";

    /** 必须与 CI 导出时的 imgsz 一致 */
    private static final int IN = 640;

    private Interpreter net = null;      // 检测
    private Interpreter netPose = null;  // 姿态
    private final List<NnApiDelegate> delegates = new ArrayList<>();

    volatile boolean mockMode = true;
    volatile float confThr = 0.45f;
    private final float nmsThr = 0.55f;

    private float scale = 1f, padX = 0f, padY = 0f;
    private int mockFrame = 0;

    /** 类别过滤：true=全部类别，false=只保留 person */
    volatile boolean multiObject = true;

    public Detector(Context ctx) {
        try {
            AssetManager am = ctx.getAssets();
            String[] fs = am.list("");
            String detFile = null, poseFile = null;
            if (fs != null) {
                for (String f : fs) {
                    if (!f.endsWith(".tflite")) continue;
                    if (f.contains("pose")) { poseFile = f; }
                    else if (detFile == null) { detFile = f; }
                }
            }
            Log.i(TAG, "det=" + detFile + " pose=" + poseFile);

            Interpreter.Options opt = makeOptions();
            if (detFile != null) {
                net = new Interpreter(load(am, detFile), opt);
            }
            if (poseFile != null) {
                netPose = new Interpreter(load(am, poseFile), makeOptions());
            }
            mockMode = (net == null && netPose == null);
            Log.i(TAG, "mockMode=" + mockMode);
        } catch (Exception e) {
            Log.e(TAG, "初始化失败", e);
            mockMode = true;
        }
    }

    /** 硬件加速优先：NNAPI -> GPU -> CPU 多线程 */
    private Interpreter.Options makeOptions() {
        Interpreter.Options o = new Interpreter.Options();
        o.setNumThreads(4);
        try {
            NnApiDelegate d = new NnApiDelegate();
            o.addDelegate(d);
            delegates.add(d);
            Log.i(TAG, "NNAPI delegate enabled");
            return o;
        } catch (Throwable t) {
            Log.w(TAG, "NNAPI unavailable: " + t);
        }
        Log.i(TAG, "fallback to CPU xNNPACK 4 threads");
        return o;
    }

    private static ByteBuffer load(AssetManager am, String path) throws Exception {
        InputStream is = am.open(path);
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        byte[] bytes = bos.toByteArray();
        ByteBuffer bb = ByteBuffer.allocateDirect(bytes.length);
        bb.order(ByteOrder.nativeOrder());
        bb.put(bytes);
        return bb;
    }

    /** 输入原图，输出检测结果（坐标已还原到原图尺寸） */
    public List<MainActivity.Det> detect(Bitmap frame, boolean multi) {
        if (mockMode) return mock(frame, multi);
        this.multiObject = multi;

        List<MainActivity.Det> out = new ArrayList<>();
        // 检测模型出框（类别更全、更准）
        if (net != null) out.addAll(run(net, frame, multi, false));
        // pose 模型补充关键点：把关键点关联到最近的检测框
        if (netPose != null) {
            List<MainActivity.Det> pd = run(netPose, frame, multi, true);
            if (net == null) {
                out.addAll(pd);
            } else {
                // 1) 把真实关键点挂到对应检测框上
                attachPose(out, pd);
                // 2) pose 结果也并入候选：NMS 会保留检测模型漏掉、pose 却抓到的人
                out.addAll(pd);
            }
        }
        return nms(out);
    }

    /** 把 pose 结果的关键点挂到最近的检测框上 */
    private void attachPose(List<MainActivity.Det> dets, List<MainActivity.Det> poses) {
        for (MainActivity.Det d : dets) {
            if (d.clsId != 0) continue;          // 只给行人挂骨骼
            float best = 0f;
            MainActivity.Det bp = null;
            for (MainActivity.Det p : poses) {
                float v = iou(d, p);
                if (v > best) { best = v; bp = p; }
            }
            if (bp != null && best > 0.4f) d.kps = bp.kps;
        }
    }

    private List<MainActivity.Det> run(Interpreter use, Bitmap frame,
                                       boolean multi, boolean isPoseModel) {
        int ow = frame.getWidth(), oh = frame.getHeight();
        Bitmap in = letterbox(frame);

        ByteBuffer buf = ByteBuffer.allocateDirect(4 * IN * IN * 3);
        buf.order(ByteOrder.nativeOrder());
        int[] px = new int[IN * IN];
        in.getPixels(px, 0, IN, 0, 0, IN, IN);
        for (int p : px) {
            buf.putFloat(((p >> 16) & 0xFF) / 255f);
            buf.putFloat(((p >> 8) & 0xFF) / 255f);
            buf.putFloat((p & 0xFF) / 255f);
        }

        int[] sh = use.getOutputTensor(0).shape();      // [1,C,N] 或 [1,N,C]
        int C = sh[1], N = sh[2];
        boolean tp = C < N;
        if (!tp) { C = sh[2]; N = sh[1]; }
        boolean isPose = (C >= 56);

        float[][][] res = new float[1][sh[1]][sh[2]];
        use.run(buf, res);

        List<MainActivity.Det> out = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            float bx = g(res, tp, 0, i), by = g(res, tp, 1, i);
            float bw = g(res, tp, 2, i), bh = g(res, tp, 3, i);
            int clsId = 0;
            float score;
            if (isPose) {
                score = g(res, tp, 4, i);
            } else {
                float best = -1f;
                for (int c = 4; c < C; c++) {
                    float v = g(res, tp, c, i);
                    if (v > best) { best = v; clsId = c - 4; }
                }
                score = best;
            }
            if (score < confThr) continue;
            if (!multi && clsId != 0) continue;

            float x1 = (bx - bw / 2f - padX) / scale;
            float y1 = (by - bh / 2f - padY) / scale;
            float x2 = (bx + bw / 2f - padX) / scale;
            float y2 = (by + bh / 2f - padY) / scale;
            x1 = clamp(x1, 0, ow); x2 = clamp(x2, 0, ow);
            y1 = clamp(y1, 0, oh); y2 = clamp(y2, 0, oh);
            if (x2 - x1 < 4 || y2 - y1 < 4) continue;

            MainActivity.Det d = new MainActivity.Det(x1, y1, x2, y2, score, clsId, zh(clsId));
            if (isPose) {
                d.kps = new float[51];
                for (int k = 0; k < 17; k++) {
                    d.kps[k * 3]     = (g(res, tp, 5 + k * 3, i) - padX) / scale;
                    d.kps[k * 3 + 1] = (g(res, tp, 6 + k * 3, i) - padY) / scale;
                    d.kps[k * 3 + 2] = g(res, tp, 7 + k * 3, i);
                }
            }
            out.add(d);
        }
        return out;
    }

    private static float g(float[][][] r, boolean tp, int c, int i) {
        return tp ? r[0][c][i] : r[0][i][c];
    }

    private Bitmap letterbox(Bitmap src) {
        int ow = src.getWidth(), oh = src.getHeight();
        scale = Math.min((float) IN / ow, (float) IN / oh);
        int nw = Math.round(ow * scale), nh = Math.round(oh * scale);
        padX = (IN - nw) / 2f;
        padY = (IN - nh) / 2f;
        Bitmap s = Bitmap.createScaledBitmap(src, nw, nh, true);
        Bitmap b = Bitmap.createBitmap(IN, IN, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.rgb(114, 114, 114));
        c.drawBitmap(s, padX, padY, null);
        return b;
    }

    private List<MainActivity.Det> nms(List<MainActivity.Det> dets) {
        dets.sort((a, b) -> Float.compare(b.conf, a.conf));
        List<MainActivity.Det> keep = new ArrayList<>();
        boolean[] dead = new boolean[dets.size()];
        for (int i = 0; i < dets.size(); i++) {
            if (dead[i]) continue;
            keep.add(dets.get(i));
            for (int j = i + 1; j < dets.size(); j++) {
                if (dead[j]) continue;
                if (iou(dets.get(i), dets.get(j)) > nmsThr) dead[j] = true;
            }
        }
        return keep;
    }

    static float iou(MainActivity.Det a, MainActivity.Det b) {
        float ix1 = Math.max(a.x1, b.x1), iy1 = Math.max(a.y1, b.y1);
        float ix2 = Math.min(a.x2, b.x2), iy2 = Math.min(a.y2, b.y2);
        float iw = Math.max(0f, ix2 - ix1), ih = Math.max(0f, iy2 - iy1);
        float inter = iw * ih;
        if (inter <= 0) return 0f;
        float sa = a.w() * a.h(), sb = b.w() * b.h();
        return inter / (sa + sb - inter + 1e-6f);
    }

    /** 无模型时的合成目标（仅演示，界面会明确提示 MOCK） */
    private List<MainActivity.Det> mock(Bitmap frame, boolean multi) {
        mockFrame++;
        int W = frame.getWidth(), H = frame.getHeight();
        List<MainActivity.Det> out = new ArrayList<>();
        float t = mockFrame / 60f;
        float hA = H * (0.30f + 0.10f * (float) Math.sin(t * 0.7));
        float xA = W * (0.30f + 0.22f * (float) Math.sin(t * 0.5));
        out.add(new MainActivity.Det(xA - hA * 0.17f, H * 0.82f - hA,
                xA + hA * 0.17f, H * 0.82f, 0.86f, 0, "行人"));
        float hB = H * (0.24f + 0.08f * (float) Math.cos(t * 0.9));
        float xB = W * (0.68f + 0.18f * (float) Math.cos(t * 0.6));
        out.add(new MainActivity.Det(xB - hB * 0.17f, H * 0.80f - hB,
                xB + hB * 0.17f, H * 0.80f, 0.82f, 0, "行人"));
        if (multi) {
            float hC = H * 0.20f;
            float xC = W * (0.50f + 0.30f * (float) Math.sin(t * 0.35 + 1.2));
            out.add(new MainActivity.Det(xC - hC * 0.38f, H * 0.88f - hC,
                    xC + hC * 0.38f, H * 0.88f, 0.80f, 3, "电动车"));
        }
        return out;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    static String zh(int id) {
        switch (id) {
            case 0: return "行人";
            case 1: return "自行车";
            case 2: return "汽车";
            case 3: return "电动车";
            case 5: return "客车";
            case 7: return "货车";
            case 15: return "猫";
            case 16: return "狗";
            default: return "目标" + id;
        }
    }

    public String modelName() {
        if (mockMode) return "MOCK";
        StringBuilder s = new StringBuilder();
        s.append(net != null ? "YOLOv8" : "");
        if (netPose != null) s.append(s.length() > 0 ? "+pose" : "pose");
        return s.length() == 0 ? "YOLOv8" : s.toString();
    }

    public void close() {
        try { if (net != null) net.close(); } catch (Throwable ignored) { }
        try { if (netPose != null) netPose.close(); } catch (Throwable ignored) { }
        for (NnApiDelegate d : delegates) {
            try { d.close(); } catch (Throwable ignored) { }
        }
        delegates.clear();
    }
}
