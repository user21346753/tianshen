package com.angel.hud;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;

import ai.onnxruntime.NodeInfo;
import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * YOLOv8 检测 / 姿态 的 ONNX Runtime 封装。
 *
 * 为什么用 ONNX Runtime 而不是 TFLite：
 *   1) CPU 推理明显更快（XNNPACK/MLAS），同模型帧率可差数倍
 *   2) 导出 ONNX 不需要 tensorflow，避开了 TFLite 导出的一堆坑
 *   3) YOLOv8 的 ONNX 输出是标准的 [1,84,8400] / [1,56,8400]，
 *      不像 tflite 有 NCHW/NHWC/量化/紧凑格式那么多分支
 *
 * assets:
 *   *.onnx        -> 检测模型（yolov8n.onnx）
 *   *pose*.onnx   -> 姿态模型（yolov8n-pose.onnx），输出真实 17 关键点
 */
public class Detector {

    private static final String TAG = "Detector";

    /** 读不到模型输入尺寸时的兜底值 */
    private static final int IN = 320;

    private OrtEnvironment env = null;
    private OrtSession det = null;      // 检测
    private OrtSession pose = null;     // 姿态

    private int detSize = IN;
    private int poseSize = IN;
    private String detInName = "images";
    private String poseInName = "images";

    volatile boolean mockMode = true;
    volatile String detName = null;
    volatile String poseName = null;
    volatile long detBytes = 0;
    volatile float confThr = 0.45f;
    private final float nmsThr = 0.48f;

    // 诊断
    volatile int rawCount = 0;
    volatile float maxScore = 0f;
    volatile String shapeInfo = "-";
    volatile String firstBox = "-";
    volatile String lastError = "-";

    private float scale = 1f, padX = 0f, padY = 0f;
    private int mockFrame = 0;

    public Detector(Context ctx) {
        try {
            env = OrtEnvironment.getEnvironment();
            AssetManager am = ctx.getAssets();
            String[] fs = am.list("");
            String detFile = null, poseFile = null;
            // 构建脚本已把选中的模型统一命名为 det.onnx / pose.onnx。
            // 这里按固定名优先取，避免 assets 里同时存在多个 onnx 时挑到弱的那个。
            java.util.List<String> names = new ArrayList<>();
            if (fs != null) names.addAll(java.util.Arrays.asList(fs));
            if (names.contains("det.onnx")) {
                detFile = "det.onnx";
            } else {
                // 兜底：没有固定名就按 yolov8s > yolov8n 的精度顺序挑
                for (String pref : new String[]{"yolov8s", "yolov8m", "yolov8n"}) {
                    for (String f : names) {
                        if (f.endsWith(".onnx") && f.startsWith(pref) && !f.contains("pose")) {
                            detFile = f; break;
                        }
                    }
                    if (detFile != null) break;
                }
            }
            if (names.contains("pose.onnx")) {
                poseFile = "pose.onnx";
            } else {
                for (String f : names) {
                    if (f.endsWith(".onnx") && f.contains("pose")) { poseFile = f; break; }
                }
            }
            Log.i(TAG, "det=" + detFile + " pose=" + poseFile);
            detName = detFile;
            poseName = poseFile;

            OrtSession.SessionOptions o = new OrtSession.SessionOptions();
            o.setIntraOpNumThreads(4);
            try {
                o.setInterOpNumThreads(1);
            } catch (Throwable ignored) { }

            if (detFile != null) {
                det = env.createSession(readAll(am, detFile), o);
                detInName = firstInputName(det);
                detSize = inputSize(det, detInName);
                detBytes = sizeOf(am, detFile);
                Log.i(TAG, "det ready in=" + detInName + " size=" + detSize);
            }
            if (poseFile != null) {
                pose = env.createSession(readAll(am, poseFile), o);
                poseInName = firstInputName(pose);
                poseSize = inputSize(pose, poseInName);
                Log.i(TAG, "pose ready in=" + poseInName + " size=" + poseSize);
            }
            mockMode = (det == null && pose == null);
            Log.i(TAG, "mockMode=" + mockMode);
        } catch (Exception e) {
            Log.e(TAG, "初始化失败", e);
            lastError = "init:" + e.getMessage();
            mockMode = true;
        }
    }

    private static byte[] readAll(AssetManager am, String path) throws Exception {
        InputStream is = am.open(path);
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        return bos.toByteArray();
    }

    private static long sizeOf(AssetManager am, String path) {
        try {
            return am.openFd(path).getLength();
        } catch (Throwable t) {
            return 0;
        }
    }

    /** 取模型第一个输入的名字，避免写死 "images" */
    private static String firstInputName(OrtSession s) {
        try {
            for (String n : s.getInputNames()) return n;
        } catch (Throwable t) {
            Log.w(TAG, "getInputNames failed", t);
        }
        return "images";
    }

    /** 从 TensorInfo 读输入尺寸，形如 [1,3,H,W] */
    private static int inputSize(OrtSession s, String inName) {
        try {
            NodeInfo ni = s.getInputInfo().get(inName);
            if (ni instanceof TensorInfo) {
                long[] sh = ((TensorInfo) ni).getShape();
                if (sh != null && sh.length >= 4) return (int) sh[3];  // NHWC? ONNX 是 NCHW
                if (sh != null && sh.length >= 3) return (int) sh[2];
            }
        } catch (Throwable t) {
            Log.w(TAG, "inputSize failed", t);
        }
        return IN;
    }

    /** 输入原图，输出检测结果（坐标已还原到原图尺寸） */
    public List<MainActivity.Det> detect(Bitmap frame, boolean multi) {
        if (mockMode) return mock(frame, multi);

        List<MainActivity.Det> out = new ArrayList<>();
        if (det != null) out.addAll(run(det, detInName, detSize, frame, multi, false));
        if (pose != null) {
            List<MainActivity.Det> pd = run(pose, poseInName, poseSize, frame, multi, true);
            if (det == null) {
                out.addAll(pd);
            } else {
                attachPose(out, pd);
                out.addAll(pd);   // pose 抓到、检测漏掉的人也补进来
            }
        }
        out = nms(out);

        java.util.Set<Integer> allow = enabledCls;
        if (allow != null && !allow.isEmpty()) {
            List<MainActivity.Det> kept = new ArrayList<>();
            for (MainActivity.Det d : out) {
                if (allow.contains(d.clsId)) kept.add(d);
            }
            out = kept;
        }
        return suppressAnimalOverlap(out);
    }

    /** 把 pose 的真实关键点挂到最近的检测框上 */
    private void attachPose(List<MainActivity.Det> dets, List<MainActivity.Det> poses) {
        for (MainActivity.Det d : dets) {
            if (d.clsId != 0) continue;
            float best = 0f;
            MainActivity.Det bp = null;
            for (MainActivity.Det p : poses) {
                float v = iou(d, p);
                if (v > best) { best = v; bp = p; }
            }
            if (bp != null && best > 0.4f) d.kps = bp.kps;
        }
    }

    private List<MainActivity.Det> run(OrtSession s, String inName, int size,
                                       Bitmap frame, boolean multi, boolean isPoseModel) {
        int ow = frame.getWidth(), oh = frame.getHeight();
        Bitmap in = letterbox(frame, size);
        int[] px = new int[size * size];
        in.getPixels(px, 0, size, 0, 0, size, size);

        // ONNX 版 YOLOv8 是 NCHW：先整片 R，再 G，再 B
        int plane = size * size;
        FloatBuffer fb = FloatBuffer.allocate(plane * 3);
        for (int ch = 0; ch < 3; ch++) {
            int shift = 16 - ch * 8;    // R=16 G=8 B=0
            for (int p : px) fb.put(((p >> shift) & 0xFF) / 255f);
        }
        fb.rewind();

        List<MainActivity.Det> out = new ArrayList<>();
        try {
            OnnxTensor t = OnnxTensor.createTensor(env, fb, new long[]{1, 3, size, size});
            OrtSession.Result res = s.run(Collections.singletonMap(inName, t));
            Object v = res.get(0).getValue();
            decode(v, out, size, ow, oh, multi);
            res.close();
            t.close();
            lastError = "-";
        } catch (Throwable e) {
            Log.e(TAG, "run failed", e);
            lastError = "run:" + e.getMessage();
        }
        return out;
    }

    /** 解析 [1,C,N] 输出 */
    private void decode(Object v, List<MainActivity.Det> out,
                        int size, int ow, int oh, boolean multi) {
        float[] data;
        int C, N;
        if (v instanceof float[][][]) {
            float[][][] a = (float[][][]) v;
            if (a.length == 0) return;
            C = a[0].length;
            N = a[0][0].length;
            data = new float[C * N];
            for (int c = 0; c < C; c++) System.arraycopy(a[0][c], 0, data, c * N, N);
        } else if (v instanceof float[][]) {
            float[][] a = (float[][]) v;
            C = a.length;
            N = a[0].length;
            data = new float[C * N];
            for (int c = 0; c < C; c++) System.arraycopy(a[c], 0, data, c * N, N);
        } else {
            lastError = "未知输出类型:" + (v == null ? "null" : v.getClass().getName());
            return;
        }

        // 检测=84(4+80类)，姿态=56(4+1+51)
        boolean isPose = (C == 56);
        shapeInfo = C + "x" + N + " in" + size + (isPose ? " POSE" : " DET");

        float best = 0f;
        int raw = 0;
        String fb = "-";

        for (int i = 0; i < N; i++) {
            float bx = data[0 * N + i];
            float by = data[1 * N + i];
            float bw = data[2 * N + i];
            float bh = data[3 * N + i];

            int clsId = 0;
            float score;
            if (isPose) {
                score = data[4 * N + i];
            } else {
                float bestV = -1f;
                for (int c = 4; c < C; c++) {
                    float s = data[c * N + i];
                    if (s > bestV) { bestV = s; clsId = c - 4; }
                }
                score = bestV;
            }
            if (score > best) best = score;
            if (score < 0.01f) continue;
            raw++;
            if ("-".equals(fb)) {
                fb = String.format("%.0f,%.0f,%.0f,%.0f s=%.2f c=%d", bx, by, bw, bh, score, clsId);
            }

            // 非人（动物/物体）误检率高，要求更高分数
            float thr = (clsId == 0) ? confThr : confThr + 0.18f;
            if (score < thr) continue;
            if (!multi && clsId != 0) continue;

            float x1 = (bx - bw / 2f - padX) / scale;
            float y1 = (by - bh / 2f - padY) / scale;
            float x2 = (bx + bw / 2f - padX) / scale;
            float y2 = (by + bh / 2f - padY) / scale;
            x1 = clamp(x1, 0, ow); x2 = clamp(x2, 0, ow);
            y1 = clamp(y1, 0, oh); y2 = clamp(y2, 0, oh);
            if (x2 - x1 < 4 || y2 - y1 < 4) continue;

            MainActivity.Det d = new MainActivity.Det(x1, y1, x2, y2, score, clsId, zh(clsId));
            if (isPose) {
                d.kps = new float[51];
                for (int k = 0; k < 17; k++) {
                    d.kps[k * 3]     = (data[(5 + k * 3) * N + i] - padX) / scale;
                    d.kps[k * 3 + 1] = (data[(6 + k * 3) * N + i] - padY) / scale;
                    d.kps[k * 3 + 2] = data[(7 + k * 3) * N + i];
                }
            }
            out.add(d);
        }
        rawCount = raw;
        maxScore = best;
        firstBox = fb;
    }

    /** 人优先：动物/物体框若与行人框高度重叠则丢弃（小模型常把人认成动物） */
    private List<MainActivity.Det> suppressAnimalOverlap(List<MainActivity.Det> dets) {
        boolean hasHuman = false;
        for (MainActivity.Det d : dets) {
            if (d.clsId == 0) { hasHuman = true; break; }
        }
        if (!hasHuman) return dets;
        List<MainActivity.Det> out = new ArrayList<>();
        for (MainActivity.Det d : dets) {
            if (d.clsId == 0) { out.add(d); continue; }
            boolean covered = false;
            for (MainActivity.Det h : dets) {
                if (h.clsId != 0) continue;
                if (iou(d, h) > 0.5f) { covered = true; break; }
            }
            if (!covered) out.add(d);
        }
        return out;
    }

    private Bitmap letterbox(Bitmap src, int size) {
        int ow = src.getWidth(), oh = src.getHeight();
        scale = Math.min((float) size / ow, (float) size / oh);
        int nw = Math.round(ow * scale), nh = Math.round(oh * scale);
        padX = (size - nw) / 2f;
        padY = (size - nh) / 2f;
        Bitmap s = Bitmap.createScaledBitmap(src, nw, nh, true);
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.rgb(114, 114, 114));
        c.drawBitmap(s, padX, padY, null);
        return b;
    }

    private List<MainActivity.Det> nms(List<MainActivity.Det> dets) {
        dets.sort((a, b) -> Float.compare(b.conf, a.conf));
        List<MainActivity.Det> keep = new ArrayList<>();
        boolean[] dead = new boolean[dets.size()];
        for (int i = 0; i < dets.size(); i++) {
            if (dead[i]) continue;
            keep.add(dets.get(i));
            for (int j = i + 1; j < dets.size(); j++) {
                if (dead[j]) continue;
                if (dets.get(i).clsId != dets.get(j).clsId) continue;  // per-class
                if (iou(dets.get(i), dets.get(j)) > nmsThr) dead[j] = true;
            }
        }
        return keep;
    }

    static float iou(MainActivity.Det a, MainActivity.Det b) {
        float ix1 = Math.max(a.x1, b.x1), iy1 = Math.max(a.y1, b.y1);
        float ix2 = Math.min(a.x2, b.x2), iy2 = Math.min(a.y2, b.y2);
        float iw = Math.max(0f, ix2 - ix1), ih = Math.max(0f, iy2 - iy1);
        float inter = iw * ih;
        if (inter <= 0) return 0f;
        float sa = a.w() * a.h(), sb = b.w() * b.h();
        return inter / (sa + sb - inter + 1e-6f);
    }

    /** 无模型时的合成目标（界面会明确提示 MOCK） */
    private List<MainActivity.Det> mock(Bitmap frame, boolean multi) {
        mockFrame++;
        int W = frame.getWidth(), H = frame.getHeight();
        List<MainActivity.Det> out = new ArrayList<>();
        float t = mockFrame / 60f;
        float hA = H * (0.30f + 0.10f * (float) Math.sin(t * 0.7));
        float xA = W * (0.30f + 0.22f * (float) Math.sin(t * 0.5));
        out.add(new MainActivity.Det(xA - hA * 0.17f, H * 0.82f - hA,
                xA + hA * 0.17f, H * 0.82f, 0.86f, 0, "行人"));
        float hB = H * (0.24f + 0.08f * (float) Math.cos(t * 0.9));
        float xB = W * (0.68f + 0.18f * (float) Math.cos(t * 0.6));
        out.add(new MainActivity.Det(xB - hB * 0.17f, H * 0.80f - hB,
                xB + hB * 0.17f, H * 0.80f, 0.82f, 0, "行人"));
        if (multi) {
            float hC = H * 0.20f;
            float xC = W * (0.50f + 0.30f * (float) Math.sin(t * 0.35 + 1.2));
            out.add(new MainActivity.Det(xC - hC * 0.38f, H * 0.88f - hC,
                    xC + hC * 0.38f, H * 0.88f, 0.80f, 3, "电动车"));
        }
        return out;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    static String zh(int id) {
        switch (id) {
            case 0: return "行人";
            case 1: return "自行车";
            case 2: return "汽车";
            case 3: return "摩托车";
            case 4: return "飞机";
            case 5: return "公交车";
            case 6: return "火车";
            case 7: return "卡车";
            case 8: return "船";
            case 14: return "鸟";
            case 15: return "猫";
            case 16: return "狗";
            case 17: return "马";
            case 18: return "羊";
            case 19: return "牛";
            case 20: return "大象";
            case 21: return "熊";
            case 22: return "斑马";
            case 23: return "长颈鹿";
            case 24: return "背包";
            case 25: return "雨伞";
            case 26: return "手提包";
            case 27: return "领带";
            case 28: return "行李箱";
            case 31: return "飞盘";
            case 32: return "滑雪板";
            case 35: return "冲浪板";
            case 38: return "网球拍";
            case 39: return "瓶子";
            case 40: return "酒杯";
            case 41: return "杯子";
            case 42: return "叉子";
            case 43: return "刀";
            case 44: return "勺子";
            case 45: return "碗";
            case 46: return "香蕉";
            case 47: return "苹果";
            case 48: return "三明治";
            case 49: return "橙子";
            case 50: return "西兰花";
            case 51: return "胡萝卜";
            case 52: return "热狗";
            case 53: return "披萨";
            case 54: return "甜甜圈";
            case 55: return "蛋糕";
            case 56: return "椅子";
            case 57: return "沙发";
            case 58: return "盆栽";
            case 59: return "床";
            case 60: return "餐桌";
            case 61: return "马桶";
            case 62: return "电视";
            case 63: return "笔记本";
            case 64: return "鼠标";
            case 65: return "遥控器";
            case 66: return "键盘";
            case 67: return "手机";
            case 68: return "微波炉";
            case 69: return "烤箱";
            case 70: return "烤面包机";
            case 71: return "水槽";
            case 72: return "冰箱";
            case 73: return "书";
            case 74: return "时钟";
            case 75: return "花瓶";
            case 76: return "剪刀";
            case 77: return "泰迪熊";
            case 78: return "吹风机";
            case 79: return "牙刷";
            default: return "目标" + id;
        }
    }

    /** 显示真实加载的模型文件名 + 体积 */
    public String modelName() {
        if (mockMode) return "MOCK 无模型";
        StringBuilder s = new StringBuilder();
        if (detName != null) {
            s.append(detName.replace(".onnx", ""));
            if (detBytes > 0) s.append(" ").append(detBytes / 1024 / 1024).append("MB");
        }
        if (poseName != null) s.append("+pose");
        return s.length() == 0 ? "ONNX" : s.toString();
    }

    public String diagLine() {
        if (mockMode) return "MOCK 演示：无模型";
        return "阈值前" + rawCount + " 最高" + String.format("%.2f", maxScore)
                + " | " + shapeInfo + " | " + firstBox
                + ("-".equals(lastError) ? "" : " | " + lastError);
    }

    public void close() {
        try { if (det != null) det.close(); } catch (Throwable ignored) { }
        try { if (pose != null) pose.close(); } catch (Throwable ignored) { }
        try { if (env != null) env.close(); } catch (Throwable ignored) { }
    }
}
