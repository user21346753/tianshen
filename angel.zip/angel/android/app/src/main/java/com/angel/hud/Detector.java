package com.angel.hud;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;

import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.Tensor;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.nnapi.NnApiDelegate;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * YOLOv8 / YOLOv8-pose 的 TFLite 封装（高准确率优先）。
 *
 * 关键：按「模型自己声明的输入/输出类型」来填数据和解数据。
 * 现成的 tflite 常见的组合有：
 *   - float32 输入 + float32 输出
 *   - uint8/int8 量化输入 + uint8/int8 量化输出
 * 如果一律按 float32 填，量化模型会在 run() 直接抛异常，
 * 表现为「模型加载成功但一个目标也识别不到、FPS 恒为 0」。
 * 这里两种都支持。
 */
public class Detector {

    private static final String TAG = "Detector";

    /** 只有在读不到模型输入尺寸时才用的兜底值。320 兼顾精度与速度 */
    private static final int IN = 320;

    private Interpreter net = null;      // 检测
    private Interpreter netPose = null;  // 姿态
    private final List<NnApiDelegate> delegates = new ArrayList<>();

    volatile boolean mockMode = true;
    volatile float confThr = 0.45f;
    private final float nmsThr = 0.55f;

    // ---- 诊断信息：直接显示在界面上，用来定位"识别不到"的原因 ----
    volatile int rawCount = 0;      // 阈值过滤前的候选框数
    volatile float maxScore = 0f;   // 本帧最高置信度
    volatile String shapeInfo = "-";
    volatile String firstBox = "-";
    volatile String lastError = "-";

    private float scale = 1f, padX = 0f, padY = 0f;
    private int mockFrame = 0;

    public Detector(Context ctx) {
        try {
            AssetManager am = ctx.getAssets();
            String[] fs = am.list("");
            String detFile = null, poseFile = null;
            if (fs != null) {
                for (String f : fs) {
                    if (!f.endsWith(".tflite")) continue;
                    if (f.contains("pose")) { poseFile = f; }
                    else if (detFile == null) { detFile = f; }
                }
            }
            Log.i(TAG, "det=" + detFile + " pose=" + poseFile);

            if (detFile != null) {
                net = new Interpreter(load(am, detFile), makeOptions());
                dumpTensor("DET", net);
            }
            if (poseFile != null) {
                netPose = new Interpreter(load(am, poseFile), makeOptions());
                dumpTensor("POSE", netPose);
            }
            mockMode = (net == null && netPose == null);
            Log.i(TAG, "mockMode=" + mockMode);
        } catch (Exception e) {
            Log.e(TAG, "初始化失败", e);
            mockMode = true;
        }
    }

    /** 把模型的输入输出规格打到日志，方便定位「识别不到」的原因 */
    private static void dumpTensor(String tag, Interpreter it) {
        try {
            Tensor in = it.getInputTensor(0);
            Tensor out = it.getOutputTensor(0);
            StringBuilder sb = new StringBuilder();
            sb.append(tag).append(" in dtype=").append(in.dataType())
              .append(" shape=").append(arr(in.shape()))
              .append(" | out dtype=").append(out.dataType())
              .append(" shape=").append(arr(out.shape()))
              .append(" inQ=").append(qScale(in)).append("/").append(qZero(in))
              .append(" outQ=").append(qScale(out)).append("/").append(qZero(out));
            Log.i(TAG, sb.toString());
            android.util.Log.i("TianShenSpec", sb.toString());
        } catch (Throwable t) {
            Log.w(TAG, "dumpTensor failed", t);
        }
    }

    private static String arr(int[] a) {
        if (a == null) return "null";
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < a.length; i++) { if (i > 0) s.append(","); s.append(a[i]); }
        return s.append("]").toString();
    }

    /**
     * 只用 CPU 多线程。
     * 之前用 NNAPI 时，部分设备的 NPU 对 YOLOv8 算子支持不全，
     * 会返回全 0 或垃圾数据 —— 表现为「模型加载成功但一个目标也识别不到」。
     */
    private Interpreter.Options makeOptions() {
        Interpreter.Options o = new Interpreter.Options();
        o.setNumThreads(4);
        Log.i(TAG, "CPU 4 threads");
        return o;
    }

    private static ByteBuffer load(AssetManager am, String path) throws Exception {
        InputStream is = am.open(path);
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        byte[] bytes = bos.toByteArray();
        ByteBuffer bb = ByteBuffer.allocateDirect(bytes.length);
        bb.order(ByteOrder.nativeOrder());
        bb.put(bytes);
        return bb;
    }

    /** 输入原图，输出检测结果（坐标已还原到原图尺寸） */
    public List<MainActivity.Det> detect(Bitmap frame, boolean multi) {
        if (mockMode) return mock(frame, multi);

        List<MainActivity.Det> out = new ArrayList<>();
        if (net != null) out.addAll(run(net, frame, multi));
        if (netPose != null) {
            List<MainActivity.Det> pd = run(netPose, frame, multi);
            if (net == null) {
                out.addAll(pd);
            } else {
                attachPose(out, pd);
                out.addAll(pd);   // pose 抓到、检测漏掉的人也补进来
            }
        }
        return nms(out);
    }

    /** 把 pose 结果的关键点挂到最近的检测框上 */
    private void attachPose(List<MainActivity.Det> dets, List<MainActivity.Det> poses) {
        for (MainActivity.Det d : dets) {
            if (d.clsId != 0) continue;          // 只给行人挂骨骼
            float best = 0f;
            MainActivity.Det bp = null;
            for (MainActivity.Det p : poses) {
                float v = iou(d, p);
                if (v > best) { best = v; bp = p; }
            }
            if (bp != null && best > 0.4f) d.kps = bp.kps;
        }
    }

    private List<MainActivity.Det> run(Interpreter use, Bitmap frame, boolean multi) {
        int ow = frame.getWidth(), oh = frame.getHeight();

        Tensor inT = use.getInputTensor(0);
        Tensor outT = use.getOutputTensor(0);

        // 以模型自身声明的输入尺寸为准
        int size = IN;
        int[] ish = inT.shape();
        if (ish != null && ish.length >= 3) {
            size = (ish[1] == 3) ? ish[2] : ish[1];   // NCHW / NHWC 都兼容
        }
        if (size <= 0) size = IN;

        Bitmap in = letterbox(frame, size);
        int[] px = new int[size * size];
        in.getPixels(px, 0, size, 0, 0, size, size);

        // ---- 按模型输入类型填缓冲 ----
        ByteBuffer buf;
        if (inT.dataType() == DataType.FLOAT32) {
            buf = ByteBuffer.allocateDirect(4 * size * size * 3);
            buf.order(ByteOrder.nativeOrder());
            for (int p : px) {
                buf.putFloat(((p >> 16) & 0xFF) / 255f);
                buf.putFloat(((p >> 8) & 0xFF) / 255f);
                buf.putFloat((p & 0xFF) / 255f);
            }
        } else {
            buf = ByteBuffer.allocateDirect(size * size * 3);
            buf.order(ByteOrder.nativeOrder());
            float sc = qScale(inT);
            long zp = qZero(inT);
            if (sc <= 0f) sc = 1f / 255f;
            for (int p : px) {
                buf.put((byte) quant(((p >> 16) & 0xFF) / 255f, sc, zp));
                buf.put((byte) quant(((p >> 8) & 0xFF) / 255f, sc, zp));
                buf.put((byte) quant(((p & 0xFF) / 255f), sc, zp));
            }
        }
        buf.rewind();

        // ---- 输出形状：[1,C,N] 或 [1,N,C] ----
        int[] osh = outT.shape();
        int C, N;
        boolean tp;
        if (osh != null && osh.length >= 3) {
            int a = osh[1], b = osh[2];
            tp = a < b;
            C = tp ? a : b;
            N = tp ? b : a;
        } else {
            C = (osh == null) ? 84 : osh[osh.length - 1];
            N = (osh == null) ? 1 : osh[1];
            tp = false;
        }

        // ---- 按模型输出类型读数据 ----
        ByteBuffer outBuf = ByteBuffer.allocateDirect(outT.numBytes());
        outBuf.order(ByteOrder.nativeOrder());
        try {
            use.run(buf, outBuf);
        } catch (Throwable t) {
            lastError = "run失败:" + t;
            Log.e(TAG, "run failed", t);
            return new ArrayList<>();
        }
        outBuf.rewind();

        int elems = outT.numBytes() / 4;
        float[] data = new float[Math.min(elems, C * N)];
        if (outT.dataType() == DataType.FLOAT32) {
            outBuf.asFloatBuffer().get(data);
        } else {
            float sc = qScale(outT);
            long zp = qZero(outT);
            byte[] raw = new byte[outT.numBytes()];
            outBuf.get(raw);
            for (int i = 0; i < data.length && i < raw.length; i++) {
                data[i] = ((raw[i] & 0xFF) - zp) * sc;
            }
        }

        // 精确通道数判断：检测=84，姿态=56（用 C>=56 会把 84 的检测模型误判成姿态）
        boolean isPose = (C == 56);

        // ---- 自动判断坐标空间：归一化(0~1) 还是像素值 ----
        // 有的导出版本输出已归一化，有的输出的是相对输入尺寸的像素坐标。
        // 判断错了就会「模型在跑但框全跑到画面外」。
        boolean normalized = true;
        for (int i = 0; i < N; i++) {
            float bx = g(data, tp, C, N, 0, i);
            float by = g(data, tp, C, N, 1, i);
            float bw = g(data, tp, C, N, 2, i);
            float bh = g(data, tp, C, N, 3, i);
            if (bx > 2f || by > 2f || bw > 2f || bh > 2f) { normalized = false; break; }
        }

        shapeInfo = C + "x" + N + (normalized ? " 归一" : " 像素")
                + (inT.dataType() == DataType.FLOAT32 ? " f32" : " 量化")
                + " in" + size;

        List<MainActivity.Det> out = new ArrayList<>();
        float best = 0f;
        int raw = 0;
        String fb = "-";

        for (int i = 0; i < N; i++) {
            float bx = g(data, tp, C, N, 0, i);
            float by = g(data, tp, C, N, 1, i);
            float bw = g(data, tp, C, N, 2, i);
            float bh = g(data, tp, C, N, 3, i);

            int clsId = 0;
            float score;
            if (isPose) {
                score = g(data, tp, C, N, 4, i);
            } else {
                float b2 = -1f;
                for (int c = 4; c < C; c++) {
                    float v = g(data, tp, C, N, c, i);
                    if (v > b2) { b2 = v; clsId = c - 4; }
                }
                score = b2;
            }
            if (score > best) best = score;
            if (score < 0.01f) continue;      // 几乎不可能的框，跳过
            raw++;
            if ("-".equals(fb)) {
                fb = String.format("%.1f,%.1f,%.1f,%.1f s=%.2f", bx, by, bw, bh, score);
            }
            if (score < confThr) continue;
            if (!multi && clsId != 0) continue;

            // 归一化 -> 还原到 letterbox 像素坐标
            float lbx = normalized ? bx * size : bx;
            float lby = normalized ? by * size : by;
            float lbw = normalized ? bw * size : bw;
            float lbh = normalized ? bh * size : bh;

            float x1 = (lbx - lbw / 2f - padX) / scale;
            float y1 = (lby - lbh / 2f - padY) / scale;
            float x2 = (lbx + lbw / 2f - padX) / scale;
            float y2 = (lby + lbh / 2f - padY) / scale;
            x1 = clamp(x1, 0, ow); x2 = clamp(x2, 0, ow);
            y1 = clamp(y1, 0, oh); y2 = clamp(y2, 0, oh);
            if (x2 - x1 < 4 || y2 - y1 < 4) continue;

            MainActivity.Det d = new MainActivity.Det(x1, y1, x2, y2, score, clsId, zh(clsId));
            if (isPose) {
                d.kps = new float[51];
                for (int k = 0; k < 17; k++) {
                    d.kps[k * 3]     = (g(data, tp, C, N, 5 + k * 3, i) - padX) / scale;
                    d.kps[k * 3 + 1] = (g(data, tp, C, N, 6 + k * 3, i) - padY) / scale;
                    d.kps[k * 3 + 2] = g(data, tp, C, N, 7 + k * 3, i);
                }
            }
            out.add(d);
        }

        rawCount = raw;
        maxScore = best;
        firstBox = fb;
        lastError = "-";
        return out;
    }

    private static float g(float[] data, boolean tp, int C, int N, int c, int i) {
        return tp ? data[c * N + i] : data[i * C + c];
    }

    private static int quant(float real, float scale, long zeroPoint) {
        long q = Math.round(real / scale + zeroPoint);
        return (int) Math.max(0, Math.min(255, q));
    }

    /** 反射读取量化参数，避免不同 TFLite 版本 API 差异导致编译失败 */
    private static float qScale(Tensor t) {
        try {
            Object q = t.getClass().getMethod("quantizationParams").invoke(t);
            Object v = q.getClass().getMethod("getScale").invoke(q);
            return ((Number) v).floatValue();
        } catch (Throwable e) {
            return 0f;
        }
    }

    private static long qZero(Tensor t) {
        try {
            Object q = t.getClass().getMethod("quantizationParams").invoke(t);
            Object v = q.getClass().getMethod("getZeroPoint").invoke(q);
            return ((Number) v).longValue();
        } catch (Throwable e) {
            return 0L;
        }
    }

    private Bitmap letterbox(Bitmap src, int size) {
        int ow = src.getWidth(), oh = src.getHeight();
        scale = Math.min((float) size / ow, (float) size / oh);
        int nw = Math.round(ow * scale), nh = Math.round(oh * scale);
        padX = (size - nw) / 2f;
        padY = (size - nh) / 2f;
        Bitmap s = Bitmap.createScaledBitmap(src, nw, nh, true);
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.rgb(114, 114, 114));
        c.drawBitmap(s, padX, padY, null);
        return b;
    }

    private List<MainActivity.Det> nms(List<MainActivity.Det> dets) {
        dets.sort((a, b) -> Float.compare(b.conf, a.conf));
        List<MainActivity.Det> keep = new ArrayList<>();
        boolean[] dead = new boolean[dets.size()];
        for (int i = 0; i < dets.size(); i++) {
            if (dead[i]) continue;
            keep.add(dets.get(i));
            for (int j = i + 1; j < dets.size(); j++) {
                if (dead[j]) continue;
                if (iou(dets.get(i), dets.get(j)) > nmsThr) dead[j] = true;
            }
        }
        return keep;
    }

    static float iou(MainActivity.Det a, MainActivity.Det b) {
        float ix1 = Math.max(a.x1, b.x1), iy1 = Math.max(a.y1, b.y1);
        float ix2 = Math.min(a.x2, b.x2), iy2 = Math.min(a.y2, b.y2);
        float iw = Math.max(0f, ix2 - ix1), ih = Math.max(0f, iy2 - iy1);
        float inter = iw * ih;
        if (inter <= 0) return 0f;
        float sa = a.w() * a.h(), sb = b.w() * b.h();
        return inter / (sa + sb - inter + 1e-6f);
    }

    /** 无模型时的合成目标（仅演示，界面会明确提示 MOCK） */
    private List<MainActivity.Det> mock(Bitmap frame, boolean multi) {
        mockFrame++;
        int W = frame.getWidth(), H = frame.getHeight();
        List<MainActivity.Det> out = new ArrayList<>();
        float t = mockFrame / 60f;
        float hA = H * (0.30f + 0.10f * (float) Math.sin(t * 0.7));
        float xA = W * (0.30f + 0.22f * (float) Math.sin(t * 0.5));
        out.add(new MainActivity.Det(xA - hA * 0.17f, H * 0.82f - hA,
                xA + hA * 0.17f, H * 0.82f, 0.86f, 0, "行人"));
        float hB = H * (0.24f + 0.08f * (float) Math.cos(t * 0.9));
        float xB = W * (0.68f + 0.18f * (float) Math.cos(t * 0.6));
        out.add(new MainActivity.Det(xB - hB * 0.17f, H * 0.80f - hB,
                xB + hB * 0.17f, H * 0.80f, 0.82f, 0, "行人"));
        if (multi) {
            float hC = H * 0.20f;
            float xC = W * (0.50f + 0.30f * (float) Math.sin(t * 0.35 + 1.2));
            out.add(new MainActivity.Det(xC - hC * 0.38f, H * 0.88f - hC,
                    xC + hC * 0.38f, H * 0.88f, 0.80f, 3, "电动车"));
        }
        return out;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    static String zh(int id) {
        switch (id) {
            case 0: return "行人";
            case 1: return "自行车";
            case 2: return "汽车";
            case 3: return "电动车";
            case 5: return "客车";
            case 7: return "货车";
            case 15: return "猫";
            case 16: return "狗";
            default: return "目标" + id;
        }
    }

    /** 界面底部显示的诊断行，用来定位识别不到的原因 */
    public String diagLine() {
        if (mockMode) return "MOCK 演示：无模型";
        return "阈值前" + rawCount + " 最高" + String.format("%.2f", maxScore)
                + " | " + shapeInfo + " | " + firstBox
                + ("-".equals(lastError) ? "" : " | " + lastError);
    }

    public String modelName() {
        if (mockMode) return "MOCK";
        StringBuilder s = new StringBuilder();
        s.append(net != null ? "YOLOv8" : "");
        if (netPose != null) s.append(s.length() > 0 ? "+pose" : "pose");
        return s.length() == 0 ? "YOLOv8" : s.toString();
    }

    public void close() {
        try { if (net != null) net.close(); } catch (Throwable ignored) { }
        try { if (netPose != null) netPose.close(); } catch (Throwable ignored) { }
        for (NnApiDelegate d : delegates) {
            try { d.close(); } catch (Throwable ignored) { }
        }
        delegates.clear();
    }
}
