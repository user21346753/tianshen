package com.angel.hud;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;

import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.Tensor;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.nnapi.NnApiDelegate;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * YOLOv8 / YOLOv8-pose 的 TFLite 封装（高准确率优先）。
 *
 * 关键：按「模型自己声明的输入/输出类型」来填数据和解数据。
 * 现成的 tflite 常见的组合有：
 *   - float32 输入 + float32 输出
 *   - uint8/int8 量化输入 + uint8/int8 量化输出
 * 如果一律按 float32 填，量化模型会在 run() 直接抛异常，
 * 表现为「模型加载成功但一个目标也识别不到、FPS 恒为 0」。
 * 这里两种都支持。
 */
public class Detector {

    private static final String TAG = "Detector";

    /** 只有在读不到模型输入尺寸时才用的兜底值。320 兼顾精度与速度 */
    private static final int IN = 320;

    private Interpreter net = null;      // 检测
    private Interpreter netPose = null;  // 姿态
    private final List<NnApiDelegate> delegates = new ArrayList<>();

    volatile boolean mockMode = true;
    volatile String detName = null;    // assets 里实际的检测模型文件名
    volatile String poseName = null;   // assets 里实际的姿态模型文件名
    volatile long detBytes = 0;
    volatile float confThr = 0.45f;
    private final float nmsThr = 0.55f;

    // ---- 诊断信息：直接显示在界面上，用来定位"识别不到"的原因 ----
    volatile int rawCount = 0;      // 阈值过滤前的候选框数
    volatile float maxScore = 0f;   // 本帧最高置信度
    volatile String shapeInfo = "-";
    volatile String firstBox = "-";
    volatile String lastError = "-";

    /** 界面上的「识别类别过滤」。为 null 或空时不过滤（多物体绘制模式） */
    volatile java.util.Set<Integer> enabledCls = null;

    private float scale = 1f, padX = 0f, padY = 0f;
    private int mockFrame = 0;

    public Detector(Context ctx) {
        try {
            AssetManager am = ctx.getAssets();
            String[] fs = am.list("");
            String detFile = null, poseFile = null;
            if (fs != null) {
                for (String f : fs) {
                    if (!f.endsWith(".tflite")) continue;
                    if (f.contains("pose")) { poseFile = f; }
                    else if (detFile == null) { detFile = f; }
                }
            }
            Log.i(TAG, "det=" + detFile + " pose=" + poseFile);
            detName = detFile;
            poseName = poseFile;

            if (detFile != null) {
                net = new Interpreter(load(am, detFile), makeOptions());
                try { detBytes = am.openFd(detFile).getLength(); } catch (Throwable ignored) { }
                dumpTensor("DET", net);
            }
            if (poseFile != null) {
                netPose = new Interpreter(load(am, poseFile), makeOptions());
                dumpTensor("POSE", netPose);
            }
            mockMode = (net == null && netPose == null);
            Log.i(TAG, "mockMode=" + mockMode);
        } catch (Exception e) {
            Log.e(TAG, "初始化失败", e);
            mockMode = true;
        }
    }

    /** 把模型的输入输出规格打到日志，方便定位「识别不到」的原因 */
    private static void dumpTensor(String tag, Interpreter it) {
        try {
            Tensor in = it.getInputTensor(0);
            Tensor out = it.getOutputTensor(0);
            StringBuilder sb = new StringBuilder();
            sb.append(tag).append(" in dtype=").append(in.dataType())
              .append(" shape=").append(arr(in.shape()))
              .append(" | out dtype=").append(out.dataType())
              .append(" shape=").append(arr(out.shape()))
              .append(" inQ=").append(qScale(in)).append("/").append(qZero(in))
              .append(" outQ=").append(qScale(out)).append("/").append(qZero(out));
            Log.i(TAG, sb.toString());
            android.util.Log.i("TianShenSpec", sb.toString());
        } catch (Throwable t) {
            Log.w(TAG, "dumpTensor failed", t);
        }
    }

    private static String arr(int[] a) {
        if (a == null) return "null";
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < a.length; i++) { if (i > 0) s.append(","); s.append(a[i]); }
        return s.append("]").toString();
    }

    /**
     * 只用 CPU 多线程。
     * 之前用 NNAPI 时，部分设备的 NPU 对 YOLOv8 算子支持不全，
     * 会返回全 0 或垃圾数据 —— 表现为「模型加载成功但一个目标也识别不到」。
     */
    private Interpreter.Options makeOptions() {
        Interpreter.Options o = new Interpreter.Options();
        o.setNumThreads(4);
        Log.i(TAG, "CPU 4 threads");
        return o;
    }

    private static ByteBuffer load(AssetManager am, String path) throws Exception {
        InputStream is = am.open(path);
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        byte[] bytes = bos.toByteArray();
        ByteBuffer bb = ByteBuffer.allocateDirect(bytes.length);
        bb.order(ByteOrder.nativeOrder());
        bb.put(bytes);
        return bb;
    }

    /** 输入原图，输出检测结果（坐标已还原到原图尺寸） */
    public List<MainActivity.Det> detect(Bitmap frame, boolean multi) {
        if (mockMode) return mock(frame, multi);

        List<MainActivity.Det> out = new ArrayList<>();
        if (net != null) out.addAll(run(net, frame, multi));
        if (netPose != null) {
            List<MainActivity.Det> pd = run(netPose, frame, multi);
            if (net == null) {
                out.addAll(pd);
            } else {
                attachPose(out, pd);
                out.addAll(pd);   // pose 抓到、检测漏掉的人也补进来
            }
        }
        out = nms(out);

        // 界面上的「识别类别过滤」：不在这个集合里的类别直接丢掉
        java.util.Set<Integer> allow = enabledCls;
        if (allow != null && !allow.isEmpty() && !multi) {
            List<MainActivity.Det> kept = new ArrayList<>();
            for (MainActivity.Det d : out) {
                if (allow.contains(d.clsId)) kept.add(d);
            }
            return kept;
        }
        return out;
    }

    /** 把 pose 结果的关键点挂到最近的检测框上 */
    private void attachPose(List<MainActivity.Det> dets, List<MainActivity.Det> poses) {
        for (MainActivity.Det d : dets) {
            if (d.clsId != 0) continue;          // 只给行人挂骨骼
            float best = 0f;
            MainActivity.Det bp = null;
            for (MainActivity.Det p : poses) {
                float v = iou(d, p);
                if (v > best) { best = v; bp = p; }
            }
            if (bp != null && best > 0.4f) d.kps = bp.kps;
        }
    }

    private List<MainActivity.Det> run(Interpreter use, Bitmap frame, boolean multi) {
        int ow = frame.getWidth(), oh = frame.getHeight();

        Tensor inT = use.getInputTensor(0);
        Tensor outT = use.getOutputTensor(0);

        // 以模型自身声明的输入尺寸为准
        int size = IN;
        int[] ish = inT.shape();
        if (ish != null && ish.length >= 3) {
            size = (ish[1] == 3) ? ish[2] : ish[1];   // NCHW / NHWC 都兼容
        }
        if (size <= 0) size = IN;

        Bitmap in = letterbox(frame, size);
        int[] px = new int[size * size];
        in.getPixels(px, 0, size, 0, 0, size, size);

        // ---- 按模型输入类型 + 布局 填缓冲 ----
        // 布局很关键：NCHW([1,3,H,W]) 要把 R 通道整片先写满，再写 G、B；
        // 如果仍按 NHWC 的逐像素 RGB 顺序写，通道就全乱了 ——
        // 模型等于在吃噪声，表现就是「模型加载成功但一个都识别不到」。
        boolean nchw = (ish != null && ish.length >= 3 && ish[1] == 3);

        ByteBuffer buf;
        if (inT.dataType() == DataType.FLOAT32) {
            buf = ByteBuffer.allocateDirect(4 * size * size * 3);
            buf.order(ByteOrder.nativeOrder());
            if (nchw) {
                for (int ch = 0; ch < 3; ch++) {
                    int shift = 16 - ch * 8;    // R=16, G=8, B=0
                    for (int p : px) buf.putFloat(((p >> shift) & 0xFF) / 255f);
                }
            } else {
                for (int p : px) {
                    buf.putFloat(((p >> 16) & 0xFF) / 255f);
                    buf.putFloat(((p >> 8) & 0xFF) / 255f);
                    buf.putFloat((p & 0xFF) / 255f);
                }
            }
        } else if (isFloat16(inT)) {
            buf = ByteBuffer.allocateDirect(2 * size * size * 3);
            buf.order(ByteOrder.nativeOrder());
            if (nchw) {
                for (int ch = 0; ch < 3; ch++) {
                    int shift = 16 - ch * 8;
                    for (int p : px) buf.putShort(half(((p >> shift) & 0xFF) / 255f));
                }
            } else {
                for (int p : px) {
                    buf.putShort(half(((p >> 16) & 0xFF) / 255f));
                    buf.putShort(half(((p >> 8) & 0xFF) / 255f));
                    buf.putShort(half((p & 0xFF) / 255f));
                }
            }
        } else {
            buf = ByteBuffer.allocateDirect(size * size * 3);
            buf.order(ByteOrder.nativeOrder());
            float sc = qScale(inT);
            long zp = qZero(inT);
            if (sc <= 0f) sc = 1f / 255f;
            if (nchw) {
                for (int ch = 0; ch < 3; ch++) {
                    int shift = 16 - ch * 8;
                    for (int p : px) buf.put((byte) quant(((p >> shift) & 0xFF) / 255f, sc, zp));
                }
            } else {
                for (int p : px) {
                    buf.put((byte) quant(((p >> 16) & 0xFF) / 255f, sc, zp));
                    buf.put((byte) quant(((p >> 8) & 0xFF) / 255f, sc, zp));
                    buf.put((byte) quant(((p & 0xFF) / 255f), sc, zp));
                }
            }
        }
        buf.rewind();

        // ---- 输出形状：[1,C,N] 或 [1,N,C] ----
        int[] osh = outT.shape();
        int C, N;
        boolean tp;
        if (osh != null && osh.length >= 3) {
            int a = osh[1], b = osh[2];
            // 通道数远小于候选框数才是 [1,C,N]；相等时默认按 [1,N,C]（YOLOv8 常见）
            tp = a < b;
            C = tp ? a : b;
            N = tp ? b : a;
        } else {
            C = (osh == null) ? 84 : osh[osh.length - 1];
            N = (osh == null) ? 1 : osh[1];
            tp = false;
        }

        // ---- 按模型输出类型读数据 ----
        ByteBuffer outBuf = ByteBuffer.allocateDirect(outT.numBytes());
        outBuf.order(ByteOrder.nativeOrder());
        try {
            use.run(buf, outBuf);
        } catch (Throwable t) {
            lastError = "run失败:" + t;
            Log.e(TAG, "run failed", t);
            return new ArrayList<>();
        }
        outBuf.rewind();

        int elems = outT.numBytes() / 4;
        float[] data = new float[Math.min(elems, C * N)];
        if (outT.dataType() == DataType.FLOAT32) {
            outBuf.asFloatBuffer().get(data);
        } else {
            float sc = qScale(outT);
            long zp = qZero(outT);
            byte[] raw = new byte[outT.numBytes()];
            outBuf.get(raw);
            for (int i = 0; i < data.length && i < raw.length; i++) {
                data[i] = ((raw[i] & 0xFF) - zp) * sc;
            }
        }

        // 精确通道数判断：检测=84，姿态=56（用 C>=56 会把 84 的检测模型误判成姿态）
        boolean isPose = (C == 56);

        // 紧凑格式（OpenCV zoo 之类的导出）：每行只有 6~10 个数，
        // 形如 [x1,y1,x2,y2, score, classId]。
        // 按 84 通道的方式解析会得到垃圾分数 —— 表现就是“模型在跑但一个都识别不到”。
        boolean compact = (!isPose && C >= 6 && C <= 10);

        // ---- 自动判断坐标空间：归一化(0~1) 还是像素值 ----
        // 有的导出版本输出已归一化，有的输出的是相对输入尺寸的像素坐标。
        // 判断错了就会「模型在跑但框全跑到画面外」。
        boolean normalized = true;
        for (int i = 0; i < N; i++) {
            float bx = g(data, tp, C, N, 0, i);
            float by = g(data, tp, C, N, 1, i);
            float bw = g(data, tp, C, N, 2, i);
            float bh = g(data, tp, C, N, 3, i);
            if (bx > 2f || by > 2f || bw > 2f || bh > 2f) { normalized = false; break; }
        }

        shapeInfo = C + "x" + N + (normalized ? " 归一" : " 像素")
                + " in" + size
                + (nchw ? " NCHW" : " NHWC")
                + " " + inT.dataType()
                + " out" + outT.dataType();

        List<MainActivity.Det> out = new ArrayList<>();
        float best = 0f;
        int raw = 0;
        String fb = "-";

        if (compact) {
            for (int i = 0; i < N; i++) {
                float a0 = g(data, tp, C, N, 0, i);
                float a1 = g(data, tp, C, N, 1, i);
                float a2 = g(data, tp, C, N, 2, i);
                float a3 = g(data, tp, C, N, 3, i);
                float score = g(data, tp, C, N, 4, i);
                int clsId = Math.round(g(data, tp, C, N, 5, i));

                if (score > best) best = score;
                if (score < 0.01f) continue;
                raw++;
                if ("-".equals(fb)) {
                    fb = String.format("[紧凑] %.1f,%.1f,%.1f,%.1f s=%.2f c=%d",
                            a0, a1, a2, a3, score, clsId);
                }
                if (score < confThr) continue;
                if (!multi && clsId != 0) continue;

                float q0 = a0, q1 = a1, q2 = a2, q3 = a3;
                boolean corners = (a2 > a0 && a3 > a1);
                float px1, py1, px2, py2;
                if (corners) {
                    px1 = q0; py1 = q1; px2 = q2; py2 = q3;
                } else {
                    px1 = q0 - q2 / 2f; py1 = q1 - q3 / 2f;
                    px2 = q0 + q2 / 2f; py2 = q1 + q3 / 2f;
                }
                if (px2 <= 1.5f && py2 <= 1.5f) {   // 归一化
                    px1 *= size; px2 *= size; py1 *= size; py2 *= size;
                }
                float x1 = clamp((px1 - padX) / scale, 0, ow);
                float y1 = clamp((py1 - padY) / scale, 0, oh);
                float x2 = clamp((px2 - padX) / scale, 0, ow);
                float y2 = clamp((py2 - padY) / scale, 0, oh);
                if (x2 - x1 < 4 || y2 - y1 < 4) continue;

                out.add(new MainActivity.Det(x1, y1, x2, y2, score, clsId, zh(clsId)));
            }
            rawCount = raw;
            maxScore = best;
            firstBox = fb;
            lastError = "-";
            return out;
        }

        for (int i = 0; i < N; i++) {
            float bx = g(data, tp, C, N, 0, i);
            float by = g(data, tp, C, N, 1, i);
            float bw = g(data, tp, C, N, 2, i);
            float bh = g(data, tp, C, N, 3, i);

            int clsId = 0;
            float score;
            if (isPose) {
                score = g(data, tp, C, N, 4, i);
            } else {
                float b2 = -1f;
                for (int c = 4; c < C; c++) {
                    float v = g(data, tp, C, N, c, i);
                    if (v > b2) { b2 = v; clsId = c - 4; }
                }
                score = b2;
            }
            if (score > best) best = score;
            if (score < 0.01f) continue;      // 几乎不可能的框，跳过
            raw++;
            if ("-".equals(fb)) {
                fb = String.format("%.1f,%.1f,%.1f,%.1f s=%.2f", bx, by, bw, bh, score);
            }
            if (score < confThr) continue;
            if (!multi && clsId != 0) continue;

            // 归一化 -> 还原到 letterbox 像素坐标
            float lbx = normalized ? bx * size : bx;
            float lby = normalized ? by * size : by;
            float lbw = normalized ? bw * size : bw;
            float lbh = normalized ? bh * size : bh;

            float x1 = (lbx - lbw / 2f - padX) / scale;
            float y1 = (lby - lbh / 2f - padY) / scale;
            float x2 = (lbx + lbw / 2f - padX) / scale;
            float y2 = (lby + lbh / 2f - padY) / scale;
            x1 = clamp(x1, 0, ow); x2 = clamp(x2, 0, ow);
            y1 = clamp(y1, 0, oh); y2 = clamp(y2, 0, oh);
            if (x2 - x1 < 4 || y2 - y1 < 4) continue;

            MainActivity.Det d = new MainActivity.Det(x1, y1, x2, y2, score, clsId, zh(clsId));
            if (isPose) {
                d.kps = new float[51];
                for (int k = 0; k < 17; k++) {
                    d.kps[k * 3]     = (g(data, tp, C, N, 5 + k * 3, i) - padX) / scale;
                    d.kps[k * 3 + 1] = (g(data, tp, C, N, 6 + k * 3, i) - padY) / scale;
                    d.kps[k * 3 + 2] = g(data, tp, C, N, 7 + k * 3, i);
                }
            }
            out.add(d);
        }

        rawCount = raw;
        maxScore = best;
        firstBox = fb;
        lastError = "-";
        return out;
    }

    private static float g(float[] data, boolean tp, int C, int N, int c, int i) {
        return tp ? data[c * N + i] : data[i * C + c];
    }

    /**
     * TFLite 2.14 的 DataType 枚举里没有 FLOAT16，
     * 直接写 DataType.FLOAT16 会编译失败（cannot find symbol），
     * 所以用名字比较来判断。
     */
    private static boolean isFloat16(Tensor t) {
        try {
            return "FLOAT16".equalsIgnoreCase(t.dataType().name());
        } catch (Throwable e) {
            return false;
        }
    }

    /** float -> IEEE 754 half precision */
    private static short half(float f) {
        int bits = Float.floatToIntBits(f);
        int sign = (bits >>> 16) & 0x8000;
        int exp = ((bits >>> 23) & 0xFF) - 112;
        int mant = bits & 0x7FFFFF;
        if (exp <= 0) return (short) sign;
        if (exp >= 31) return (short) (sign | 0x7C00);
        return (short) (sign | (exp << 10) | (mant >> 13));
    }

    private static int quant(float real, float scale, long zeroPoint) {
        long q = Math.round(real / scale + zeroPoint);
        return (int) Math.max(0, Math.min(255, q));
    }

    /** 反射读取量化参数，避免不同 TFLite 版本 API 差异导致编译失败 */
    private static float qScale(Tensor t) {
        try {
            Object q = t.getClass().getMethod("quantizationParams").invoke(t);
            Object v = q.getClass().getMethod("getScale").invoke(q);
            return ((Number) v).floatValue();
        } catch (Throwable e) {
            return 0f;
        }
    }

    private static long qZero(Tensor t) {
        try {
            Object q = t.getClass().getMethod("quantizationParams").invoke(t);
            Object v = q.getClass().getMethod("getZeroPoint").invoke(q);
            return ((Number) v).longValue();
        } catch (Throwable e) {
            return 0L;
        }
    }

    private Bitmap letterbox(Bitmap src, int size) {
        int ow = src.getWidth(), oh = src.getHeight();
        scale = Math.min((float) size / ow, (float) size / oh);
        int nw = Math.round(ow * scale), nh = Math.round(oh * scale);
        padX = (size - nw) / 2f;
        padY = (size - nh) / 2f;
        Bitmap s = Bitmap.createScaledBitmap(src, nw, nh, true);
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.rgb(114, 114, 114));
        c.drawBitmap(s, padX, padY, null);
        return b;
    }

    private List<MainActivity.Det> nms(List<MainActivity.Det> dets) {
        dets.sort((a, b) -> Float.compare(b.conf, a.conf));
        List<MainActivity.Det> keep = new ArrayList<>();
        boolean[] dead = new boolean[dets.size()];
        for (int i = 0; i < dets.size(); i++) {
            if (dead[i]) continue;
            keep.add(dets.get(i));
            for (int j = i + 1; j < dets.size(); j++) {
                if (dead[j]) continue;
                if (iou(dets.get(i), dets.get(j)) > nmsThr) dead[j] = true;
            }
        }
        return keep;
    }

    static float iou(MainActivity.Det a, MainActivity.Det b) {
        float ix1 = Math.max(a.x1, b.x1), iy1 = Math.max(a.y1, b.y1);
        float ix2 = Math.min(a.x2, b.x2), iy2 = Math.min(a.y2, b.y2);
        float iw = Math.max(0f, ix2 - ix1), ih = Math.max(0f, iy2 - iy1);
        float inter = iw * ih;
        if (inter <= 0) return 0f;
        float sa = a.w() * a.h(), sb = b.w() * b.h();
        return inter / (sa + sb - inter + 1e-6f);
    }

    /** 无模型时的合成目标（仅演示，界面会明确提示 MOCK） */
    private List<MainActivity.Det> mock(Bitmap frame, boolean multi) {
        mockFrame++;
        int W = frame.getWidth(), H = frame.getHeight();
        List<MainActivity.Det> out = new ArrayList<>();
        float t = mockFrame / 60f;
        float hA = H * (0.30f + 0.10f * (float) Math.sin(t * 0.7));
        float xA = W * (0.30f + 0.22f * (float) Math.sin(t * 0.5));
        out.add(new MainActivity.Det(xA - hA * 0.17f, H * 0.82f - hA,
                xA + hA * 0.17f, H * 0.82f, 0.86f, 0, "行人"));
        float hB = H * (0.24f + 0.08f * (float) Math.cos(t * 0.9));
        float xB = W * (0.68f + 0.18f * (float) Math.cos(t * 0.6));
        out.add(new MainActivity.Det(xB - hB * 0.17f, H * 0.80f - hB,
                xB + hB * 0.17f, H * 0.80f, 0.82f, 0, "行人"));
        if (multi) {
            float hC = H * 0.20f;
            float xC = W * (0.50f + 0.30f * (float) Math.sin(t * 0.35 + 1.2));
            out.add(new MainActivity.Det(xC - hC * 0.38f, H * 0.88f - hC,
                    xC + hC * 0.38f, H * 0.88f, 0.80f, 3, "电动车"));
        }
        return out;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    static String zh(int id) {
        switch (id) {
            // 人
            case 0: return "行人";
            // 交通工具
            case 1: return "自行车";
            case 2: return "汽车";
            case 3: return "摩托车";
            case 4: return "飞机";
            case 5: return "公交车";
            case 6: return "火车";
            case 7: return "卡车";
            case 8: return "船";
            // 动物
            case 14: return "鸟";
            case 15: return "猫";
            case 16: return "狗";
            case 17: return "马";
            case 18: return "羊";
            case 19: return "牛";
            case 20: return "大象";
            case 21: return "熊";
            case 22: return "斑马";
            case 23: return "长颈鹿";
            // 常见物品
            case 24: return "背包";
            case 25: return "雨伞";
            case 26: return "手提包";
            case 27: return "领带";
            case 28: return "行李箱";
            case 31: return "飞盘";
            case 32: return "滑雪板";
            case 35: return "冲浪板";
            case 38: return "网球拍";
            case 39: return "瓶子";
            case 40: return "酒杯";
            case 41: return "杯子";
            case 42: return "叉子";
            case 43: return "刀";
            case 44: return "勺子";
            case 45: return "碗";
            case 46: return "香蕉";
            case 47: return "苹果";
            case 48: return "三明治";
            case 49: return "橙子";
            case 50: return "西兰花";
            case 51: return "胡萝卜";
            case 52: return "热狗";
            case 53: return "披萨";
            case 54: return "甜甜圈";
            case 55: return "蛋糕";
            case 56: return "椅子";
            case 57: return "沙发";
            case 58: return "盆栽";
            case 59: return "床";
            case 60: return "餐桌";
            case 61: return "马桶";
            case 62: return "电视";
            case 63: return "笔记本";
            case 64: return "鼠标";
            case 65: return "遥控器";
            case 66: return "键盘";
            case 67: return "手机";
            case 68: return "微波炉";
            case 69: return "烤箱";
            case 70: return "烤面包机";
            case 71: return "水槽";
            case 72: return "冰箱";
            case 73: return "书";
            case 74: return "时钟";
            case 75: return "花瓶";
            case 76: return "剪刀";
            case 77: return "泰迪熊";
            case 78: return "吹风机";
            case 79: return "牙刷";
            default: return "目标" + id;
        }
    }

    /** 界面底部显示的诊断行，用来定位识别不到的原因 */
    public String diagLine() {
        if (mockMode) return "MOCK 演示：无模型";
        return "阈值前" + rawCount + " 最高" + String.format("%.2f", maxScore)
                + " | " + shapeInfo + " | " + firstBox
                + ("-".equals(lastError) ? "" : " | " + lastError);
    }

    /** 显示 assets 里真实加载的模型文件名 + 体积，不再写死 "YOLOv8" */
    public String modelName() {
        if (mockMode) return "MOCK 无模型";
        StringBuilder s = new StringBuilder();
        if (detName != null) {
            String n = detName.replace(".tflite", "").replace("_float32", "");
            s.append(n);
            if (detBytes > 0) s.append(" ").append(detBytes / 1024 / 1024).append("MB");
        }
        if (poseName != null) s.append("+pose");
        return s.length() == 0 ? "YOLOv8" : s.toString();
    }

    public void close() {
        try { if (net != null) net.close(); } catch (Throwable ignored) { }
        try { if (netPose != null) netPose.close(); } catch (Throwable ignored) { }
        for (NnApiDelegate d : delegates) {
            try { d.close(); } catch (Throwable ignored) { }
        }
        delegates.clear();
    }
}
