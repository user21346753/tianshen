package com.angel.hud;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * HUD 叠加层 —— 外观对齐"天使辅助"外挂面板：
 *   左上  天使辅助 / FPS / TARGETS
 *   左中  圆形雷达（扫描扇形 + 光点）+ "目标N 近"
 *   中心  准星
 *   目标  绿色方框（四角加粗）+ #ID 类别 距离
 *   左下  目标列表
 *   右下  模型名（YOLOv8n / MOCK）
 */
public class HudView extends View {

    volatile boolean showBox = true;
    volatile boolean showSkeleton = false;
    volatile boolean showRadar = true;
    volatile boolean showRay = true;
    volatile String modelName = "YOLOv8n";
    volatile boolean mock = false;
    volatile float fps = 0f;

    private List<MainActivity.Target> targets = null;
    /** 平滑后供绘制使用的列表，各 draw 方法都读它 */
    private volatile List<MainActivity.Target> smoothView = null;
    private int srcW = 1, srcH = 1, curCount = 0, totalCount = 0;

    /**
     * 平滑插值：推理只有 3~5 FPS，但屏幕 60 FPS。
     * 结果一秒才更新几次，框就会一跳一跳的。
     * 这里在每次 onDraw 时把框往最新位置插值一点，
     * 渲染保持 60 FPS，视觉上就顺滑了 —— 这是流畅度提升最明显的一项。
     */
    private static final float SMOOTH = 0.28f;
    private final java.util.Map<Integer, float[]> smoothBox = new java.util.HashMap<>();
    private final java.util.Map<Integer, float[]> smoothKps = new java.util.HashMap<>();
    private float sx = 1f, sy = 1f, offX = 0f, offY = 0f;
    private int frames = 0;
    private long winStart = 0;

    private static final int GREEN = 0xFF4CE07A;
    private static final int CYAN = 0xFF4CD8FF;
    private static final int BLUE = 0xFF3DA5FF;


    private final Paint pGreen, pThin, pText;
    // 复用 Paint：onDraw 里每次 new 会产生大量临时对象，触发频繁 GC 导致卡顿
    private final Paint pBone, pDot, pRing, pRay, pSweep, pBlip;

    public HudView(Context c) {
        super(c);
        pBone = new Paint(Paint.ANTI_ALIAS_FLAG);
        pBone.setColor(CYAN);
        pBone.setStrokeWidth(3.5f);

        pDot = new Paint(Paint.ANTI_ALIAS_FLAG);
        pDot.setColor(0xFFFFB040);

        pRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        pRing.setColor(0x994CE07A);
        pRing.setStyle(Paint.Style.STROKE);
        pRing.setStrokeWidth(1.5f);

        pRay = new Paint(Paint.ANTI_ALIAS_FLAG);
        pRay.setColor(0xBF4CE07A);
        pRay.setStrokeWidth(1.4f);

        pSweep = new Paint(Paint.ANTI_ALIAS_FLAG);
        pSweep.setColor(0x554CE07A);
        pSweep.setStyle(Paint.Style.FILL);

        pBlip = new Paint(Paint.ANTI_ALIAS_FLAG);
        pBlip.setColor(GREEN);
        pGreen = new Paint(Paint.ANTI_ALIAS_FLAG);
        pGreen.setColor(GREEN);
        pGreen.setStyle(Paint.Style.STROKE);
        pGreen.setStrokeWidth(2.5f);

        pThin = new Paint(Paint.ANTI_ALIAS_FLAG);
        pThin.setColor(0xB03DA5A0);
        pThin.setStyle(Paint.Style.STROKE);
        pThin.setStrokeWidth(1.4f);

        pText = new Paint(Paint.ANTI_ALIAS_FLAG);
        pText.setColor(0xFFDCEEE3);
        pText.setTextSize(22f);
        pText.setTypeface(Typeface.MONOSPACE);
    }

    /** 返回平滑后的目标副本（不改 tracker 里的原始数据） */
    private List<MainActivity.Target> drawTargets() {
        if (targets == null || targets.isEmpty()) {
            smoothBox.clear();
            smoothKps.clear();
            return targets;
        }
        java.util.Set<Integer> seen = new java.util.HashSet<>();
        List<MainActivity.Target> out = new java.util.ArrayList<>(targets.size());
        for (MainActivity.Target t : targets) {
            seen.add(t.id);

            float[] sb = smoothBox.get(t.id);
            if (sb == null) {
                sb = new float[]{t.x1, t.y1, t.x2, t.y2};
                smoothBox.put(t.id, sb);
            } else {
                sb[0] += (t.x1 - sb[0]) * SMOOTH;
                sb[1] += (t.y1 - sb[1]) * SMOOTH;
                sb[2] += (t.x2 - sb[2]) * SMOOTH;
                sb[3] += (t.y2 - sb[3]) * SMOOTH;
            }

            MainActivity.Target c = new MainActivity.Target();
            c.id = t.id; c.conf = t.conf; c.distM = t.distM;
            c.clsId = t.clsId; c.label = t.label; c.age = t.age; c.lost = t.lost;
            c.x1 = sb[0]; c.y1 = sb[1]; c.x2 = sb[2]; c.y2 = sb[3];

            if (t.kps != null && t.kps.length >= 51) {
                float[] sk = smoothKps.get(t.id);
                if (sk == null) {
                    sk = t.kps.clone();
                    smoothKps.put(t.id, sk);
                } else {
                    for (int i = 0; i < sk.length; i++) {
                        if (t.kps[i] >= 0) sk[i] += (t.kps[i] - sk[i]) * SMOOTH;
                    }
                }
                c.kps = sk;
            } else {
                c.kps = t.kps;
            }
            out.add(c);
        }
        // 清理已消失的目标，避免 Map 无限增长
        smoothBox.keySet().retainAll(seen);
        smoothKps.keySet().retainAll(seen);
        return out;
    }

    public synchronized void setTargets(List<MainActivity.Target> list, int w, int h, int total) {
        targets = list;
        srcW = Math.max(1, w);
        srcH = Math.max(1, h);
        curCount = (list == null) ? 0 : list.size();
        totalCount = total;

        long now = System.currentTimeMillis();
        frames++;
        if (winStart == 0) winStart = now;
        else {
            long dt = now - winStart;
            if (dt >= 500) { fps = frames * 1000f / dt; frames = 0; winStart = now; }
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (targets == null) return;
        smoothView = drawTargets();
        List<MainActivity.Target> ts = drawTargets();
        // 统一 fit-center 变换：和 PreviewView 的 FIT_CENTER 完全一致，
        // 否则画面被裁剪/拉伸而框按另一种算法算，框就会偏、会被拉歪。
        // cover 变换：与 PreviewView 的 FILL_CENTER 一致（填满屏幕、裁掉多余部分）
        float s = Math.max(getWidth() / (float) srcW, getHeight() / (float) srcH);
        offX = (getWidth() - srcW * s) * 0.5f;
        offY = (getHeight() - srcH * s) * 0.5f;
        sx = s;
        sy = s;

        if (showRay) drawRays(c, sx, sy);
        drawCrosshair(c);
        if (showBox) drawBoxes(c, sx, sy);
        if (showSkeleton) drawSkeletons(c, sx, sy);
        if (showRadar) drawRadar(c, sx, sy);
        drawTopLeft(c);
        drawTargetList(c);
        drawModelName(c);
        if (mock) drawMockWarning(c);
    }

    /** 左上：天使辅助 / FPS / TARGETS —— 对齐外挂面板的标题区 */
    private void drawTopLeft(Canvas c) {
        Paint bg = new Paint();
        // 贴在真正的左上角（之前为了避让按钮被压到屏幕中间，不对）
        float top = 12f;
        bg.setColor(0xC40A0F14);
        c.drawRoundRect(14f, top, 250f, top + 82f, 8f, 8f, bg);

        Paint t = new Paint(pText);
        t.setColor(GREEN);
        t.setTextSize(26f);
        t.setFakeBoldText(true);
        c.drawText("天使辅助", 26f, top + 30f, t);

        Paint s = new Paint(pText);
        s.setTextSize(20f);
        s.setColor(0xFFBFE8CE);
        c.drawText("FPS " + String.format("%.0f", fps) + "  TARGETS " + curCount,
                26f, top + 58f, s);
        c.drawText("累计 " + totalCount, 26f, top + 78f, s);
    }

    private void drawBoxes(Canvas c, float sx, float sy) {
        for (MainActivity.Target t : smoothView) {
            float x1 = t.x1 * sx + offX, y1 = t.y1 * sy + offY,
                  x2 = t.x2 * sx + offX, y2 = t.y2 * sy + offY;
            c.drawRect(x1, y1, x2, y2, pGreen);

            // 四角加粗 —— 外挂味
            float L = Math.min(20f, Math.min(x2 - x1, y2 - y1) / 3f);
            Paint th = new Paint(pGreen);
            th.setStrokeWidth(5f);
            c.drawLine(x1, y1, x1 + L, y1, th);
            c.drawLine(x1, y1, x1, y1 + L, th);
            c.drawLine(x2, y1, x2 - L, y1, th);
            c.drawLine(x2, y1, x2, y1 + L, th);
            c.drawLine(x1, y2, x1 + L, y2, th);
            c.drawLine(x1, y2, x1, y2 - L, th);
            c.drawLine(x2, y2, x2 - L, y2, th);
            c.drawLine(x2, y2, x2, y2 - L, th);

            String tag = "#" + t.id + " " + t.label + " " + String.format("%.1f", t.distM) + "m";
            Paint tp = new Paint(pText);
            tp.setTextSize(20f);
            float tw = tp.measureText(tag) + 14f;
            float ty = (y1 - 32f < 0) ? y2 : y1 - 32f;
            Paint bg = new Paint();
            bg.setColor(0xD0081A0E);
            c.drawRect(x1, ty, x1 + tw, ty + 28f, bg);
            Paint g = new Paint(tp);
            g.setColor(GREEN);
            c.drawText(tag, x1 + 7f, ty + 20f, g);
        }
    }

    private static final int[][] LIMBS = {
            {0, 5}, {0, 6}, {5, 6}, {5, 7}, {7, 9}, {6, 8}, {8, 10},
            {5, 11}, {6, 12}, {11, 12}, {11, 13}, {13, 15}, {12, 14}, {14, 16}
    };

    private void drawSkeletons(Canvas c, float sx, float sy) {
        for (MainActivity.Target t : smoothView) {
            // 只有行人才画骨骼 —— 书、车、猫这些不能套人体骨架
            if (t.clsId != 0) continue;

            // 框占了大半屏幕，多半是床单/被子/大件杂物被误判成人，
            // 这时画骨骼一定是对不上的全身骨架，直接跳过。
            float bw = t.x2 - t.x1, bh = t.y2 - t.y1;
            // 同理：近距离自拍时框会占满屏幕，无条件跳过会导致贴脸无骨骼。
            // 只在占屏极大且置信度不高时才跳过。
            float areaRatio = (bw * bh) / (float) (getWidth() * getHeight());
            if (areaRatio > 0.95f && t.conf < 0.55f) continue;

            // 有姿态模型就用真实关键点；没有就回退到老版按框绘制的骨架。
            // 老版骨架按检测框比例套一套人体，动作剧烈时会有偏差，
            // 但任何时候都能看到骨骼 —— 你要的就是这个效果。
            boolean realKps = (t.kps != null && t.kps.length >= 51);
            float[] p = realKps ? real(t, sx, sy, true) : guess(t, sx, sy);
            int vis = 0;
            float minY = Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            float minX = Float.MAX_VALUE, maxX = -Float.MAX_VALUE;
            boolean hasTorso = false;
            for (int k = 0; k < 17; k++) {
                if (p[k * 2] < 0) continue;
                vis++;
                minX = Math.min(minX, p[k * 2]);  maxX = Math.max(maxX, p[k * 2]);
                minY = Math.min(minY, p[k * 2 + 1]); maxY = Math.max(maxY, p[k * 2 + 1]);
                // 5/6=肩，11/12=胯：至少有一个躯干点可见才说明看到了身体而非只有脸
                if (k == 5 || k == 6 || k == 11 || k == 12) hasTorso = true;
            }
            // 老版 guess 骨架是完整一套，直接画；只有真实关键点才做严格校验
            if (realKps && (vis < 6 || !hasTorso)) continue;
            // 关键点必须真的散开：只露出一张脸时，点全挤在小范围内，
            // 画出来就是在脸上糊一副骨架。
            float spreadY = maxY - minY, spreadX = maxX - minX;
            float boxH = (t.y2 - t.y1) * sy, boxW = (t.x2 - t.x1) * sx;
            if (realKps && boxH > 0 && spreadY < boxH * 0.22f) continue;
            if (realKps && boxW > 0 && spreadX < boxW * 0.10f) continue;

            Paint bone = pBone;
            for (int[] l : LIMBS) {
                float ax = p[l[0] * 2], ay = p[l[0] * 2 + 1];
                float bx = p[l[1] * 2], by = p[l[1] * 2 + 1];
                if (ax < 0 || ay < 0 || bx < 0 || by < 0) continue;
                c.drawLine(ax, ay, bx, by, bone);
            }
            Paint dot = pDot;
            for (int k = 0; k < 17; k++) {
                if (p[k * 2] < 0 || p[k * 2 + 1] < 0) continue;
                c.drawCircle(p[k * 2], p[k * 2 + 1], 4.5f, dot);
            }
        }
    }

    /**
     * 真实关键点。做两道过滤，解决「只露上半身却画出整副骨架」：
     *   1) 可见度低于阈值的点视为无效（模型自己认为不可见）
     *   2) 落在检测框外的点置为无效（人只露一半时，另一半不该凭空长出来）
     */
    private float[] real(MainActivity.Target t, float sx, float sy, boolean clip) {
        float[] p = new float[34];
        float bx1 = t.x1, by1 = t.y1, bx2 = t.x2, by2 = t.y2;
        float m = (bx2 - bx1) * 0.25f;   // 手臂伸出框外一点也要保留，否则骨骼跟不上动作
        for (int k = 0; k < 17; k++) {
            float vis = t.kps[k * 3 + 2];
            if (vis < 0.25f) { p[k * 2] = -1; p[k * 2 + 1] = -1; continue; }
            float x = t.kps[k * 3], y = t.kps[k * 3 + 1];
            if (clip && (x < bx1 - m || x > bx2 + m || y < by1 - m || y > by2 + m)) {
                p[k * 2] = -1; p[k * 2 + 1] = -1; continue;
            }
            p[k * 2] = x * sx + offX;
            p[k * 2 + 1] = y * sy + offY;
        }
        return p;
    }

    private float[] guess(MainActivity.Target t, float sx, float sy) {
        float x1 = t.x1 * sx + offX, y1 = t.y1 * sy + offY;
        float w = (t.x2 - t.x1) * sx, h = (t.y2 - t.y1) * sy;
        float[] p = new float[34];
        put(p, 0, x1 + .50f * w, y1 + .09f * h);
        put(p, 1, x1 + .44f * w, y1 + .075f * h);
        put(p, 2, x1 + .56f * w, y1 + .075f * h);
        put(p, 3, x1 + .38f * w, y1 + .085f * h);
        put(p, 4, x1 + .62f * w, y1 + .085f * h);
        put(p, 5, x1 + .34f * w, y1 + .26f * h);
        put(p, 6, x1 + .66f * w, y1 + .26f * h);
        put(p, 7, x1 + .25f * w, y1 + .42f * h);
        put(p, 8, x1 + .75f * w, y1 + .42f * h);
        put(p, 9, x1 + .19f * w, y1 + .56f * h);
        put(p, 10, x1 + .81f * w, y1 + .56f * h);
        put(p, 11, x1 + .41f * w, y1 + .56f * h);
        put(p, 12, x1 + .59f * w, y1 + .56f * h);
        put(p, 13, x1 + .40f * w, y1 + .75f * h);
        put(p, 14, x1 + .60f * w, y1 + .75f * h);
        put(p, 15, x1 + .39f * w, y1 + .95f * h);
        put(p, 16, x1 + .61f * w, y1 + .95f * h);
        return p;
    }

    private static void put(float[] p, int i, float x, float y) {
        p[i * 2] = x;
        p[i * 2 + 1] = y;
    }

    private void drawRays(Canvas c, float sx, float sy) {
        float cx = getWidth() / 2f, cy = getHeight() * 0.52f;
        Paint rp = pRay;
        rp.setColor(0xBF4CE07A);
        rp.setStrokeWidth(1.4f);
        for (MainActivity.Target t : smoothView) {
            c.drawLine(cx, cy, t.cx() * sx + offX, t.cy() * sy + offY, rp);
            c.drawCircle(t.cx() * sx + offX, t.cy() * sy + offY, 5f, rp);
        }
    }

    private void drawCrosshair(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() * 0.52f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(GREEN);
        p.setStrokeWidth(2.5f);
        c.drawLine(cx - 24, cy, cx - 9, cy, p);
        c.drawLine(cx + 9, cy, cx + 24, cy, p);
        c.drawLine(cx, cy - 24, cx, cy - 9, p);
        c.drawLine(cx, cy + 9, cx, cy + 24, p);
        c.drawCircle(cx, cy, 3.5f, p);
    }

    /** 左侧圆形雷达：同心圆 + 十字 + 扫描扇形 + 光点，下方标 "目标N 近" */
    private void drawRadar(Canvas c, float sx, float sy) {
        float R = Math.min(96f, getHeight() * 0.20f);
        float cx = R + 34f;
        float cy = getHeight() * 0.52f;

        Paint bg = new Paint();
        bg.setColor(0x550A1A12);
        bg.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, R, bg);

        c.drawCircle(cx, cy, R, pThin);
        c.drawCircle(cx, cy, R * 2f / 3f, pThin);
        c.drawCircle(cx, cy, R / 3f, pThin);
        c.drawLine(cx - R, cy, cx + R, cy, pThin);
        c.drawLine(cx, cy - R, cx, cy + R, pThin);

        Paint sweep = pSweep;
        sweep.setColor(0x554CE07A);
        sweep.setStyle(Paint.Style.FILL);
        float ang = (System.currentTimeMillis() / 14) % 360;
        c.drawArc(new RectF(cx - R, cy - R, cx + R, cy + R), ang - 32, 64, true, sweep);

        Paint blip = new Paint(Paint.ANTI_ALIAS_FLAG);
        blip.setColor(GREEN);
        for (MainActivity.Target t : smoothView) {
            double a = ((t.cx() * sx - getWidth() / 2f) / (getWidth() / 2f)) * (Math.PI / 4);
            float rr = R * Math.min(t.distM / 40f, 1f);
            float px = (float) (cx + rr * Math.sin(a));
            float py = (float) (cy - rr * Math.cos(a));
            c.drawCircle(px, py, 5.5f, blip);
            c.drawCircle(px, py, 11f, pRing);
        }

        // 目标N 近 / 远
        String near = "目标" + curCount + (curCount > 0 && nearest() < 8f ? " 近" : " 远");
        Paint lp = new Paint(pText);
        lp.setTextSize(21f);
        lp.setColor(GREEN);
        lp.setFakeBoldText(true);
        c.drawText(near, cx - 40f, cy + R + 30f, lp);

        Paint sub = new Paint(pText);
        sub.setTextSize(17f);
        sub.setColor(0xFF8FBFA4);
        c.drawText("RADAR 40m", cx - 38f, cy + R + 52f, sub);
    }

    private float nearest() {
        float m = Float.MAX_VALUE;
        for (MainActivity.Target t : targets) m = Math.min(m, t.distM);
        return m;
    }

    private void drawTargetList(Canvas c) {
        float ly = getHeight() - 26f;
        Paint t = new Paint(pText);
        t.setTextSize(20f);
        t.setColor(0xFF9CFFC0);
        int n = 0;
        for (MainActivity.Target x : smoothView) {
            if (n++ >= 4) break;
            c.drawText("目标" + x.id + " " + x.label + " " + String.format("%.1f", x.distM) + "m",
                    18f, ly, t);
            ly -= 24f;
        }
    }

    /** 右下角模型名，对齐外挂面板的 "YOLOv8n" 标识 */
    private void drawModelName(Canvas c) {
        String s = modelName;
        Paint t = new Paint(pText);
        t.setTextSize(22f);
        t.setColor(mock ? 0xFFFF5555 : BLUE);
        t.setFakeBoldText(true);
        float w = t.measureText(s);
        c.drawText(s, getWidth() - w - 22f, getHeight() - 24f, t);
    }

    private void drawMockWarning(Canvas c) {
        String s = "MOCK 模式：未加载模型，画面中的框是演示目标，不是真实识别";
        Paint bg = new Paint();
        bg.setColor(0xDC8C0A0A);
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(Color.WHITE);
        t.setTextSize(21f);
        t.setFakeBoldText(true);
        float w = Math.min(t.measureText(s) + 24f, getWidth() - 20f);
        float y0 = getHeight() - 74f;
        c.drawRect(10f, y0, 10f + w, y0 + 34f, bg);
        c.drawText(s, 22f, y0 + 24f, t);
    }
}
