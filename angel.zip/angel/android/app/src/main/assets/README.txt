Put yolov8n.tflite here for real detection.
Without it the app runs in MOCK mode.
