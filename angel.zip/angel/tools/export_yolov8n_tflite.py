#!/usr/bin/env python3
"""
导出 YOLOv8n / YOLOv8n-pose 为 TFLite（int8 或 fp32），供天使辅助 APP 使用。

用法：
    pip install ultralytics
    python export_yolov8n_tflite.py            # 输出到 assets 目录
    python export_yolov8n_tflite.py --fp16     # 半精度，体积减半、速度更快
"""

import argparse
import os
import shutil

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.normpath(os.path.join(
    HERE, "..", "android", "app", "src", "main", "assets"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fp16", action="store_true", help="导出 fp16 版本（更小更快）")
    ap.add_argument("--int8", action="store_true", help="导出 int8 量化版本（最快，精度略降）")
    args = ap.parse_args()

    from ultralytics import YOLO

    os.makedirs(ASSETS, exist_ok=True)
    jobs = [("yolov8n.pt", "yolov8n.tflite"),
            ("yolov8n-pose.pt", "yolov8n-pose.tflite")]

    for pt, out_name in jobs:
        print(f"\n=== 导出 {pt} -> {out_name} ===")
        try:
            model = YOLO(pt)
            kwargs = dict(format="tflite")
            if args.int8:
                kwargs["int8"] = True
            elif args.fp16:
                kwargs["half"] = True
            path = model.export(**kwargs)          # 返回导出文件路径
            dst = os.path.join(ASSETS, out_name)
            shutil.copy(path, dst)
            size = os.path.getsize(dst) / 1024 / 1024
            print(f"已写入 {dst}  ({size:.1f} MB)")
        except Exception as e:
            print(f"{pt} 导出失败：{e}")
            print("可手动下载官方 tflite 权重放到 assets 目录。")

    print("\n完成。重新 ./gradlew assembleDebug 打包即可。")


if __name__ == "__main__":
    main()
